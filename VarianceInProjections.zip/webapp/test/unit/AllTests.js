sap.ui.define([
	"com/tatasteel/VarianceInProjections/test/unit/controller/home.controller"
], function () {
	"use strict";
});