sap.ui.define([], function () {
	return {
		initPageSettings: function (oView, settingsPanel, chartFixFlex, idVizFrame, that, chartType) {
			// Hide Settings Panel for phone
			if (sap.ui.Device.system.phone) {
				//var oSettingsPanel = oView.byId('settingsPanel');
				var oSettingsPanel = oView.byId(settingsPanel);
				if (oSettingsPanel) {
					oSettingsPanel.setExpanded(false);
				}
			}

			// try to load sap.suite.ui.commons for using ChartContainer
			// sap.suite.ui.commons is available in sapui5-sdk-dist but not in demokit
			var libraries = sap.ui.getVersionInfo().libraries || [];
			var bSuiteAvailable = libraries.some(function (lib) {
				return lib.name.indexOf("sap.suite.ui.commons") > -1;
			});
			if (bSuiteAvailable) {
				jQuery.sap.require("sap/suite/ui/commons/ChartContainer");
				//var vizframe = oView.byId("idVizFrame");
				var vizframe = oView.byId(idVizFrame);

				var oChartContainerContent = " ";

				if (chartType === " ") {
					oChartContainerContent = new sap.suite.ui.commons.ChartContainerContent({
						icon: "sap-icon://line-chart",
						title: "vizFrame Line Chart Sample",
						content: [vizframe]
					});
				} else {
					oChartContainerContent = new sap.suite.ui.commons.ChartContainerContent({
						icon: "sap-icon://vertical-bar-chart",
						title: "vizFrame Column Chart Sample",
						content: [vizframe]
					});
				}
				// var oChartContainerContent = new sap.suite.ui.commons.ChartContainerContent({
				// 	icon: "sap-icon://vertical-bar-chart",
				// 	title: "vizFrame Column Chart Sample",
				// 	content: [vizframe]
				// });

				// var oChartContainer = new sap.suite.ui.commons.ChartContainer({
				// 	content: [oChartContainerContent],
				// });

				var oChartContainer = " ";

				if (chartFixFlex !== "chartFixFlex5") {
					oChartContainer = new sap.suite.ui.commons.ChartContainer({
						content: [oChartContainerContent]
					});
				} else {
					oChartContainer = new sap.suite.ui.commons.ChartContainer({
						content: [oChartContainerContent],
						customIcons: new sap.ui.core.Icon({
							src: "sap-icon://step",
							size: "32px",
							color: "#333333",
							activeColor: "white",
							alt: "More",
							activeBackgroundColor: "#333333",
							hoverColor: "#eeeeee",
							hoverBackgroundColor: "#666666",
							width: "60px",
							press: function () {
								//alert('pressed');
								return that.navigateFundPosition();
							}
						})
					});
				}

				oChartContainer.setShowFullScreen(true);
				oChartContainer.setAutoAdjustHeight(true);
				//oView.byId('chartFixFlex').setFlexContent(oChartContainer); 
				oView.byId(chartFixFlex).setFlexContent(oChartContainer);
			}
		}
	};
});