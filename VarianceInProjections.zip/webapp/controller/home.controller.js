sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"./InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, InitPageUtil) {
	"use strict";

	return Controller.extend("com.tatasteel.VarianceInProjections.controller.home", {
		onInit: function () {
			var test = "testing variable";
		},
		onBeforeRendering: function () {
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData(jQuery.sap.getModulePath("com.tatasteel.VarianceInProjections.model", "/month.json"), null, false);
			var currentMonth = new Date().getMonth() + 1;
			currentMonth = currentMonth < 10 ? "0" + currentMonth : currentMonth;
			
			var monthID = this.getView().byId("month");
			oModel.setData({
				MonthsModel: oModel.oData.Months,
				currentMonth: currentMonth
			});
			monthID.setModel(oModel);

			var currentYear = new Date().getFullYear();
			var array = [];
			for (var i = 0; i < 10; i++) {
				array.push({
					"id": currentYear,
					"year": currentYear
				});
				currentYear = currentYear - 1;
			}
			var oModel2 = new sap.ui.model.json.JSONModel();
			var yearID = this.getView().byId("year");
			oModel2.setData({
				YearsModel: array,
				currentYear: new Date().getFullYear()
			});
			yearID.setModel(oModel2);

			var syDatum = new Date().getFullYear() + currentMonth + "01";

			var filters = [];
			filters.push(new sap.ui.model.Filter({
				path: "Day",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: syDatum
			}));

			this.passDate(filters);
		},

		passDate: function (filters) {
			sap.ui.core.BusyIndicator.show();
			this.varianceOfCollection(filters);
			this.varianceOfPayments(filters);
			this.fundTransferHO(filters);
			this.closingCash(filters);
			this.collectionSixMonths();
			this.paymentsSixMonths();
		},

		onSearch: function () {
			var month = this.getView().byId("month").getSelectedKey();
			var year = this.getView().byId("year").getSelectedKey();
			var syDatum = year + month + "01";

			var filters = [];
			filters.push(new sap.ui.model.Filter({
				path: "Day",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: syDatum
			}));

			this.passDate(filters);
		},

		onAfterRendering: function () {
			this.getView().byId("page").scrollTo(0, 0);
		},

		varianceOfCollection: function (filters) {
			var that = this;
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPS_FI_CASH_TRACK_SRV/");
			oModel.read("/CollectionsDailyVariationSet", {
				filters: filters,
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					sap.ui.getCore().setModel(oData.results, "totalActualCollection");
					dataModel.setData({
						collectionsDailyVariationModel: oData.results
					});
					//globalData = dataModel;
					that.renderChartCollection(dataModel, that);
					sap.ui.core.BusyIndicator.hide();
					that.diffOfCollPay();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		renderChartCollection: function (dataModel, that) {
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample

			var oVizFrame = this.getView().byId("idVizFrame2");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT,
						visible: true
					}
				},
				legend: {
					visible: true,
					isScrollable: true
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: "Projections Vs Actuals(Collection)"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver2");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel2", "chartFixFlex2", "idVizFrame2", that, " ");

		},

		varianceOfPayments: function (filters) {
			var that = this;
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPS_FI_CASH_TRACK_SRV/");
			oModel.read("/PaymentsDailyVariationSet", {
				filters: filters,
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					sap.ui.getCore().setModel(oData.results, "totalActualPayments");
					dataModel.setData({
						paymentsDailyVariationModel: oData.results
					});
					//globalData = dataModel;
					that.renderChartPayments(dataModel, that);
					sap.ui.core.BusyIndicator.hide();
					that.diffOfCollPay();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		renderChartPayments: function (dataModel, that) {
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample

			var oVizFrame = this.getView().byId("idVizFrame3");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT,
						visible: true
					}
				},
				legend: {
					visible: true,
					isScrollable: true
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: "Projections Vs Actuals(Payments)"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver3");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel3", "chartFixFlex3", "idVizFrame3", that, " ");
		},

		diffOfCollPay: function () {
			if (sap.ui.getCore().getModel("totalActualCollection") !== "undefined" && sap.ui.getCore().getModel("totalActualPayments") !==
				"undefined") {
				var totalActualCollection = sap.ui.getCore().getModel("totalActualCollection");
				var totalActualPayments = sap.ui.getCore().getModel("totalActualPayments");
				var differnce = [];
				var i = 0;
				var j = 0;

				for (i = 0, j = 0; i < totalActualCollection.length; i++, j++) {
					var data = {
						"Collection": totalActualCollection[i].Actuals,
						"Payments": totalActualPayments[j].Actuals,
						"Variance": (totalActualCollection[i].Actuals - totalActualPayments[j].Actuals).toFixed(2),
						"Day": totalActualCollection[i].Day
					};
					differnce.push(data);
				}

				var dataModel = new sap.ui.model.json.JSONModel();
				dataModel.setData({
					diffOfCollPayModel: differnce
				});

				this.renderdifference(dataModel);
			}
			sap.ui.core.BusyIndicator.hide();
		},

		renderdifference: function (dataModel) {
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample

			var oVizFrame = this.getView().byId("idVizFrame4");
			var oVizFrame2 = this.getView().byId("idVizFrame5");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.STANDARDINTEGER,
						visible: true
					}
				},
				legend: {
					visible: true,
					isScrollable: true
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: "Total Actual Collection and Total Actual Payment"
				}
			});
			oVizFrame2.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.STANDARDINTEGER,
						visible: true
					}
				},
				legend: {
					visible: true,
					isScrollable: true
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: "Variance"
				}
			});
			oVizFrame.setModel(dataModel);
			oVizFrame2.setModel(dataModel);
			var oPopOver = this.getView().byId("idPopOver4");
			var oPopOver2 = this.getView().byId("idPopOver5");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			oPopOver2.connect(oVizFrame.getVizUid());
			oPopOver2.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel4", "chartFixFlex4", "idVizFrame4", this, " ");
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel5", "chartFixFlex5", "idVizFrame5", this, " ");

		},

		navigateFundPosition: function (event) {
			//console.log(event);
			var xnavservice = sap.ushell.Container.getService("CrossApplicationNavigation");
			var href = (xnavservice && xnavservice.hrefForExternal({
				target: {
					semanticObject: "ZTSLS_FI_CashDsp",
					action: "display"
				},
				params: {
					// "ProductID": "102343333"
				}
			})) || "";

			var url = window.location.href.split("#")[0] + href;
			//Navigate to second app
			sap.m.URLHelper.redirect(url, true);

		},

		collectionSixMonths: function () {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_Collection_DisplaySet", {
				success: function (oData, response) {
					//var results = oData.results; 

					var dataModel = new sap.ui.model.json.JSONModel();

					dataModel.setData({
						jsonModel: oData.results
					});
					Format.numericFormatter(ChartFormatter.getInstance());
					var formatPattern = ChartFormatter.DefaultPattern;

					var oVizFrame = that.getView().byId("idVizFrame6");
					oVizFrame.setVizProperties({
						plotArea: {
							dataLabel: {
								formatString: formatPattern.SHORTFLOAT_MFD2,
								visible: true
							}
						},
						valueAxis: {
							label: {
								formatString: formatPattern.SHORTFLOAT
							},
							title: {
								visible: false
							}
						},
						categoryAxis: {
							title: {
								visible: false
							}
						},
						title: {
							visible: true,
							text: "Monthly Projection, Daily Projection and Monthly Actuals by Month"
						}
					});

					oVizFrame.setModel(dataModel);

					var oPopOver = that.getView().byId("idPopOver6");
					oPopOver.connect(oVizFrame.getVizUid());
					oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

					InitPageUtil.initPageSettings(that.getView(), "settingsPanel6", "chartFixFlex6", "idVizFrame6", that, "barChart");

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		fundTransferHO: function (filters) {
			var that = this;
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPS_FI_CASH_TRACK_SRV/");
			oModel.read("/FundTransferHOSet", {
				filters: filters,
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						fundTransferHOModel: oData.results
					});
					//globalData = dataModel;
					that.renderChartfundTransferHO(dataModel, that);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		renderChartfundTransferHO: function (dataModel, that) {
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample

			var oVizFrame = this.getView().byId("idVizFrame7");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT,
						visible: true
					}
				},
				legend: {
					visible: true,
					isScrollable: true
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: ""
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver7");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel7", "chartFixFlex7", "idVizFrame7", that, " ");

		},

		closingCash: function (filters) {
			var that = this;
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPS_FI_CASH_TRACK_SRV/");
			oModel.read("/ClosingCashSet", {
				filters: filters,
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						closingCashSetModel: oData.results
					});
					//globalData = dataModel;
					that.renderChartclosingCash(dataModel, that);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		renderChartclosingCash: function (dataModel, that) {
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample

			var oVizFrame = this.getView().byId("idVizFrame8");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT,
						visible: true
					}
				},
				legend: {
					visible: true,
					isScrollable: true
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: false,
					text: ""
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver8");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel8", "chartFixFlex8", "idVizFrame8", that, " ");

		},

		paymentsSixMonths: function () {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_MonthlyProjVsActualPaymentsSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						monthlyProjVsActualPaymentsModel: oData.results
					});
					Format.numericFormatter(ChartFormatter.getInstance());
					var formatPattern = ChartFormatter.DefaultPattern;
					// set explored app's demo model on this sample

					var oVizFrame = that.getView().byId("idVizFrame9");
					oVizFrame.setVizProperties({
						plotArea: {
							dataLabel: {
								formatString: formatPattern.STANDARDINTEGER,
								visible: true
							}
						},
						valueAxis: {
							label: {
								formatString: formatPattern.SHORTFLOAT
							},
							title: {
								visible: false
							}
						},
						categoryAxis: {
							title: {
								visible: false
							}
						},
						title: {
							visible: true,
							text: "Monthly Projection Vs Monthly Actuals"
						}
					});

					oVizFrame.setModel(dataModel);

					var oPopOver = that.getView().byId("idPopOver9");
					oPopOver.connect(oVizFrame.getVizUid());
					oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

					//InitPageUtil.initPageSettings(this.getView());
					InitPageUtil.initPageSettings(that.getView(), "settingsPanel9", "chartFixFlex9", "idVizFrame9", that, "barChart");

				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		}
	});
});