sap.ui.define([
	"com/tatasteel/ZTSLFI_CT02/test/unit/controller/Card.controller"
], function () {
	"use strict";
});