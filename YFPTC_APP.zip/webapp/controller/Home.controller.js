sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/HTML"
], function(Controller, MessageBox, MessageToast, JSONModel, HTML) {
	"use strict";

	var backEndResponse = null;
	var canvas = null;
	var totalPageNumber = 1;
	var pageNumber = 1;
	var zoomIn = 1.0;

	return Controller.extend("YFPTC_APP.controller.Home", {

		onInit: function() {
			console.log('asdasdas');
			var imported = document.createElement("script");
			// imported.src = "//mozilla.github.io/pdf.js/build/pdf.js";
			imported.src = "js/pdf.js";
			document.head.appendChild(imported);
		},

		radiobuttonselect: function(oEvent) {
			var oSelectedIndex = oEvent.getParameter("selectedIndex");
			var delivery = this.getView().byId("delivery_label");
			var invoice = this.getView().byId("invoice_label");
			var coilid = this.getView().byId("coil_id_label");
			if (oSelectedIndex === 0) {
				this.getView().byId("invoice_label").setVisible(false);
				this.getView().byId("coil_id_label").setVisible(false);
				this.getView().byId("delivery_label").setVisible(true);
			}
			if (oSelectedIndex === 1) {
				this.getView().byId("invoice_label").setVisible(true);
				this.getView().byId("coil_id_label").setVisible(false);
				this.getView().byId("delivery_label").setVisible(false);
			}
			if (oSelectedIndex === 2) {
				this.getView().byId("invoice_label").setVisible(false);
				this.getView().byId("coil_id_label").setVisible(true);
				this.getView().byId("delivery_label").setVisible(false);
			}
		},

		showSmartform: function(oEvent) {
			//	sap.ui.core.BusyIndicator.show(0);
			 if(sap.ui.Device.system.desktop == true ){
			 	this.getView().byId("download").setVisible(true);
			 }
			 if(sap.ui.Device.system.phone == true ){
			 	this.getView().byId("download").setVisible(false);
			 }
			console.log(sap.ui.Device.system);
			var delivery = this.getView().byId("RB1").mProperties.selected;
			var invoice = this.getView().byId("RB2").mProperties.selected;
			var coilid = this.getView().byId("RB3").mProperties.selected;
			var that = this;
			var deliveryno = this.getView().byId("deliveryno").getValue();
			if(deliveryno == '')
			{
				sap.m.MessageToast.show("Please enter mandatory field");
				return false;
			}

			var boilertc = this.getView().byId("boilertc").getSelected();
			var type = '';
			var boilertcflag = '';

			var that = this;

			if (delivery === true) {
				type = 'D';

			}
			if (invoice === true) {
				type = 'I';
			}
			if (coilid === true) {
				type = 'C';
			}
			if (boilertc === true) {
				boilertcflag = 'X';
			}

			var filters = new Array();
			var filterval1 = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, deliveryno);
			filters.push(filterval1);
			var filterval2 = new sap.ui.model.Filter("Type", sap.ui.model.FilterOperator.EQ, type);
			filters.push(filterval2);
			var filterval3 = new sap.ui.model.Filter("Boilertc", sap.ui.model.FilterOperator.EQ, boilertcflag);
			filters.push(filterval3);

			var oModel2 = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YQ01O_YFPTC_SRV/");
			sap.ui.core.BusyIndicator.show(0);
			oModel2.read("/ET_PDFSet", {
				filters: filters,
				success: function(oData, response) {

					//window.open(response.data.results[0].E_url);
					// var oHtml = sap.ui.getCore().byId("htmlControl");
					var oHtml = that.getView().byId("htmlControl");
					//	var html = new sap.ui.core.HTML({});
					if (!oHtml) {
						var sId = that.createId("htmlControl");
						oHtml = new HTML(sId, {
							//content: "<embed src='data:application/pdf;base64,"+response.data.results[0].Base64str+"' width='1300' height='1000' />",
							//content: "<embed src='data:application/pdf;#toolbar=0&navpanes=0&scrollbar=0&;base64,"+response.data.results[0].Base64str+"' width='1300' height='1000' />",
							content: "<div style='width:100%;height:100%;overflow-:scroll;'><canvas id='the-canvas'></canvas></div>",
							preferDOM: false
						});
						that.getView().byId("prevnextbtn").setVisible(true);
						var oLayout = that.getView().byId("tblcontainer");

						//that.getView().byId("nr1").addContent(oHtml);
						oLayout.addContent(oHtml);
					}

					var pdfData = atob(response.data.results[0].Base64str);

					var pdfjsLib = window['pdfjs-dist/build/pdf'];

					// The workerSrc property shall be specified.
				//	pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';
					pdfjsLib.GlobalWorkerOptions.workerSrc = 'js/worker.js';

					// Using DocumentInitParameters object to load binary data.
					var loadingTask = pdfjsLib.getDocument({
						data: pdfData
					});

					backEndResponse = loadingTask;
					that.rendperImgPdf(backEndResponse, 1, 1.0);

				},
				error: function(oError) { //read error}
					sap.m.MessageToast.show(JSON.parse(oError.response.body).error.message.value);
				}
			});

			// sap.ui.core.BusyIndicator.show();

			// var sURI = "/sap/opu/odata/sap/YQ01O_YFPTC_SRV";
			// var oModel = new sap.ui.model.odata.ODataModel(sURI, true);
			// 	oModel.read(
			// 		// "/InvoPdfSet(Vbeln='2132002202',Printtype='Rpeat')/$value",
			// 		"/ET_INPUTSETSet(Vbeln='" + deliveryno + "',Type='" + type + "',BoilerTc='" + boilertcflag + "')/$value",
			// 		null, null, false,
			// 		function(odata, response) {

			// 			if (response === null) {
			// 			} else {
			// 				var pdfURL = response.requestUri;
			// 				sap.ui.core.BusyIndicator.hide();
			// 				var html = new sap.ui.core.HTML({});
			//	pdfURL = "sapfioriqa.tatasteel.co.in:8000/sap/opu/odata/sap/YQ01O_YFPTC_SRV/ET_INPUTSETSet(Vbeln='894991504',Type='D',BoilerTc='X')/$value";
			// html.setContent("<iframe  id='iframe" + deliveryno + "' src=" + pdfURL +
			// 	" width='2000' height='1200'></iframe>");
			//	html.placeAt("content");

			//	var html = new sap.ui.core.HTML({});
			// 	 			var oHtml = sap.ui.getCore().byId("htmlControl");
			// if (!oHtml) {
			// 	var sId = that.createId("htmlControl");

			// 	var url = "sapfioriqa.tatasteel.co.in:8000/sap/opu/odata/sap/YQ01O_YFPTC_SRV/ET_INPUTSETSet(Vbeln='894991504',Type='D',BoilerTc='X')/$value";

			// 	oHtml = new HTML(sId, {
			// the static content as a long string literal
			// content: "<iframe src="+response.data.results[0].E_url+" height='600' width='1000'></iframe>",
			//content: "<iframe src='https://assets.cdn.sap.com/sapcom/docs/2015/07/c06ac591-5b7c-0010-82c7-eda71af511fa.pdf' height='600' width='500' scrolling='yes'></iframe>",
			//content: "<iframe src='https://stackoverflow.com/' scrolling='yes'></iframe><embed src='https://assets.cdn.sap.com/sapcom/docs/2015/07/c06ac591-5b7c-0010-82c7-eda71af511fa.pdf' type='application/pdf'/>",
			//content: "<embed src='https://docs.google.com/gview?url=https://assets.cdn.sap.com/sapcom/docs/2015/07/c06ac591-5b7c-0010-82c7-eda71af511fa.pdf&embedded=true'/>",
			//content: "<iframe src=" + url +	"></iframe>",
			//preferDOM: false
			// use the afterRendering event for 2 purposes
			// afterRendering: function(oEvent) {
			// 	if (!oEvent.getParameters()["isPreservedDOM"]) {
			// 		var $DomRef = oEvent.getSource().$();
			// 		$DomRef.click(function(oEvent) {
			// 			that.addColorBlockAtCursor($DomRef, oEvent, 64, 8);
			// 		}.bind(that));
			// 	}
			// }.bind(that)
			// 	});
			// 	var oLayout = that.byId("staticContentLayout1");
			// 	oLayout.addContent(oHtml);
			// }

			// 	window.open("sapfioriqa.tatasteel.co.in:8000/sap/opu/odata/sap/YQ01O_YFPTC_SRV/ET_INPUTSETSet(Vbeln='894991504',Type='D',BoilerTc='X')/$value");

			// 	that._oModel = new JSONModel({
			// 	Source: that._sValidPath,
			// 	Title: "My Custom Title",
			// 	Height: "600px"
			// });
			// that.getView().setModel(that._oModel);

			// var winlogicalname = "detailPDF";
			// var winparams = 'dependent=yes,locationbar=no,scrollbars=yes,download=yes,menubar=yes,'+
			//         'resizable,screenX=50,screenY=50,width=850,height=1050';
			// var htmlText = '<embed width=100% height=100%'
			//                  + ' type="application/pdf"'
			//                  //+ 'src="data:application/pdf;base64"'
			//                  + ' src="data:application/pdf,'
			//                  + escape(response.body)
			//                  + '"></embed>'; 

			//  var html = new sap.ui.core.HTML();
			// html.setContent("<iframe src=" + pdfURL + " width='700' height='700'></iframe>");

			// 		var windows = window.open("", "My PDF", " width='700' height='700'");

			// 		windows.document.write(html);

			// 		windows.print();

			// 		windows.close();

			//  that.getView().byId("nr1").setContent(htmlText);
			//Open PDF in new browser window
			// var detailWindow = window.open ("", winlogicalname, winparams);
			//  detailWindow.document.write(htmlText);
			// detailWindow.document.close();

			// window.open ("data:application/pdf;base64,"+atob(response.body));

			// var tab = window.open('about:blank', '_blank', winlogicalname, winparams);
			// tab.document.write(htmlText);
			//tab.document.write("data:application/pdf"+response.body); // this could be any data URI
			//	tab.document.close(); // to finish loading the page

			//             var tab = window.open('about:blank', '_blank');
			// tab.document.write("data:text/html,<script>alert('hi');</script>"); // this could be any data URI
			// tab.document.close(); // to finish loading the page

			//}
			//},
			// function fnError(e) {
			// 	// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
			// 	var errorBody = e.response.body;
			// 	var errorMessage = JSON.parse(errorBody).error.message.value;
			// });
		},
		rendperImgPdf: function(backEndResponse, pageNum, pdfzoom) {
			backEndResponse.promise.then(function(pdf) {
				//console.log('PDF loaded');

				// Fetch the first page
				var pageNumber2 = pageNum;
				pdf.getPage(pageNumber2).then(function(page) {
					//console.log('Page loaded');

					totalPageNumber = pdf.numPages;
					var scale = pdfzoom;
					var viewport = page.getViewport(scale);

					// Prepare canvas using PDF page dimensions
					canvas = document.getElementById('the-canvas');

					while (canvas.hasChildNodes()) {
						canvas.removeChild(canvas.lastChild);
					}

					var context = canvas.getContext("2d");
					canvas.height = viewport.height;
					canvas.width = viewport.width;
					
					sap.ui.core.BusyIndicator.hide();

					// Render PDF page into canvas context
					var renderContext = {
						canvasContext: context,
						viewport: viewport
					};
					var renderTask = page.render(renderContext);
					renderTask.then(function() {
						//console.log('Page rendered');
					});
				});
			}, function(reason) {
				// PDF loading error
				//console.error(reason);
			});
		},

		onNext: function() {
			if (pageNumber < totalPageNumber) {
				pageNumber++;
				this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
				if (pageNumber === totalPageNumber) {
					this.getView().byId("next").setVisible(false);
				} else {
					this.getView().byId("next").setVisible(true);
				}
				if (pageNumber == 1) {
					this.getView().byId("prev").setVisible(false);
				}else{
					this.getView().byId("prev").setVisible(true);
				}
			}
		},

		onPrev: function() {
			if (pageNumber > 1) {
				pageNumber--;
				this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
			}
			if (pageNumber == 1) {
				this.getView().byId("prev").setVisible(false);
			}else{
				this.getView().byId("prev").setVisible(true);
			}
			if (pageNumber === totalPageNumber) {
				this.getView().byId("next").setVisible(false);
			} else {
				this.getView().byId("next").setVisible(true);
			}
		},

		onZoomin: function() {
			zoomIn = zoomIn + 0.5;
			this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
		},
		onZoomout: function() {

			if (zoomIn >= 1) {
				zoomIn = zoomIn - 0.5;
				this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
			}
		},
		downloadSmartform: function() {
			var delivery = this.getView().byId("RB1").mProperties.selected;
			var invoice = this.getView().byId("RB2").mProperties.selected;
			var coilid = this.getView().byId("RB3").mProperties.selected;
			var that = this;
			var deliveryno = this.getView().byId("deliveryno").getValue();

			var boilertc = this.getView().byId("boilertc").getSelected();
			var type = '';
			var boilertcflag = '';

			var that = this;

			if (delivery === true) {
				type = 'D';

			}
			if (invoice === true) {
				type = 'I';
			}
			if (coilid === true) {
				type = 'C';
			}
			if (boilertc === true) {
				boilertcflag = 'X';
			}

			var sURI = "/sap/opu/odata/sap/YQ01O_YFPTC_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sURI, true);
			sap.ui.core.BusyIndicator.show(0);
			oModel.read(
				// "/InvoPdfSet(Vbeln='2132002202',Printtype='Rpeat')/$value",
				"/ET_INPUTSETSet(Vbeln='" + deliveryno + "',Type='" + type + "',BoilerTc='" + boilertcflag + "')/$value",
				null, null, false,
				function(odata, response) {

					if (response === null) {} else {
						var pdfURL = response.requestUri;
						sap.ui.core.BusyIndicator.hide();
						var html = new sap.ui.core.HTML({});
						sap.ui.core.BusyIndicator.hide();
						html.setContent("<iframe  id='iframe" + deliveryno + "' src=" + pdfURL +
							" style='display:none'></iframe>");
						html.placeAt("__xmlview0--staticContentLayout1");

					}
				});
		}

	});
});