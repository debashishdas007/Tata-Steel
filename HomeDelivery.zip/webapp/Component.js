sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/sap/tatasteelHomeDeliveryHomeDelivery/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.sap.tatasteelHomeDeliveryHomeDelivery.Component", {

		metadata: {
			manifest: "json",
			rootView : {
				"viewName": "com.sap.tatasteelHomeDeliveryHomeDelivery.view.home_dlv",
				"type": "XML",
				"async": true
			},
			includes : [ "resources/sample.css" ],
			dependencies : {
				libs : [
					"sap.m",
					"sap.ui.layout"
				]
			}
		},config : {
				sample : {
					files : [
						"home_dlv.view.xml",
						"home_dlvs.controller.js"
					]
				}
			},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
		}
	});
});