sap.ui.define(["jquery.sap.global"],
	function(jQuery) {
		"use strict";
		var HOMEPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "demoApp-Homedlv-resvno",
					order: 0,
					text: "RSNUM",
					visible: true
				 } ,
				 {
					id: "demoApp-Homedlv-resvitm",
					order: 1,
					text: "RSPOS",
					visible: true
				}, {
					id: "demoApp-Homedlv-issuedate",
					order: 2,
					text: "BUDAT",
					visible: true
				}, {
					id: "demoApp-Homedlv-issueqty",
					order: 3,
					text: "ENMNG",
					visible: true
				}, {
					id: "demoApp-Homedlv-route",
					order: 4,
					text: "ROUTE",
					visible: true
				},
				 {
					id: "demoApp-Homedlv-dlvpoint",
					order: 5,
					text: "WEMPF",
					visible: true
				},
				{
					id: "demoApp-Homedlv-material",
					order: 6,
					text: "MATNR",
					visible: true
				},
				
				{
					id: "demoApp-Homedlv-maktx",
					order: 6,
					text: "MAKTX",
					visible: true
				},
				{
					id: "demoApp-Homedlv-plant",
					order: 7,
					text: "WERKS",
					visible: true
				},
				{
					id: "demoApp-Homedlv-sloc",
					order: 8,
					text: "LGORT",
					visible: true
				},
				{
					id: "demoApp-Homedlv-handoverqty",
					order: 9,
					text: "HANDOVR_QTY",
					visible: true
				},
				{
					id: "demoApp-Homedlv-handoverqtycom",
					order: 10,
					text: "HANDOVR_QTY_COMPL",
					visible: true
				},
				{
					id: "demoApp-Homedlv-handoverqtyrem",
					order: 11,
					text: "HANDOVR_QTY_REMAIN",
					visible: true
				},
				{
					id: "demoApp-Homedlv-finalstatus",
					order: 12,
					text: "FINALSTATUS",
					visible: true
				},
				{
					id: "demoApp-Deptdlv-COMB",
					order: 13,
					text: "COMB",
					visible: true
				},
				{
					id: "demoApp-Deptdlv-COMB1",
					order: 14,
					text: "COMB1",
					visible: true
				}
				
				]
			
			},
			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			}
			

			//resetPersData: function() {}

		};

		return HOMEPersoService;


	}, /* bExport= */ true);