sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/m/MessageToast",
		"sap/m/TablePersoController",
		"sap/m/MessageBox",
		"sap/ui/model/Filter",
		"sap/m/TablePersoController",
		"./HOMEPersoService",
		"sap/ndc/BarcodeScanner",
		"sap/m/Dialog",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV"
	],
	//avi
	// function(Controller, MessageToast, JSONModel, message, TablePersoController, HOMEPersoService, Filter, Sorter, MessageBox) {
	function(Controller, MessageToast,JSONModel, MessageBox,message, TablePersoController, HOMEPersoService, Filter, BarcodeScanner, Dialog , Export, ExportTypeCSV) {
		"use strict";
		var that = this;

		var oValueHelpDialog = null;
		var aTokens = [];
		var oModel = null;
		var allErrorMsg = "";
		var allErrorMsg1 = "";
		var Fixmsg = "Issue Qty can't be less than Handover Qty for";
		var Fixmsg1 = "HandOver Qty can't be greater than Remaining Qty";
		return Controller.extend("com.sap.tatasteelHomeDeliveryHomeDelivery.controller.home_dlv", {
			onInit: function() {
					var filters = new Array();
				
					var selectedRoute;
				
				selectedRoute = this.getView().byId("Route");
						var sURI1 = "/sap/opu/odata/sap/YMPI_HOME_DELIVERY_SRV/";
					var oModelR = new sap.ui.model.odata.ODataModel(sURI1, true);
					oModelR.read("/RouteSet", {
					filters: filters,
					success: function(oData, resonse) {

						var value = [];
						value = oData.results;
						var oModelR = new sap.ui.model.json.JSONModel();
						oModelR.setData({
							RouteSet: value
						});
						selectedRoute.setModel(oModelR);
						// this.getId("idPlan_PlantCode").getView.setData(oModel1);
					},
					error: function(oError) { //read error}
					}
				});
				
				// create any data and a model and set it to the view
				// var oData = {
				// 	checkBox1Text : "CheckBox",
				// 	checkBox2Text : "CheckBox - focused"
				// };
				this.getView().byId("DP1").setDateValue(new Date());

				this.getView().byId("DP2").setDateValue(new Date());

				this._oTPC = new TablePersoController({
					table: this.getView().byId("Homedlv"),
					//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
					componentName: "dempapp",
					persoService: HOMEPersoService
				}).activate();

				this.bGrouped = false;
				this.bDescending = false;

				that.DRIVERNAME1 = "";
				that.DRIVERCONTACTNO1 = "";
				that.VEHICLENO1 = "";
				that.VEHICLEDETAILS1 = "";
				that.FLAG = "";
				that.HLD = "";
				that.bck = "";

			},
			// ENTDET: function(oEVENT){
			// 	that.HLD ="X";
			// 	this.getView().byId("filterBa").setVisible(false);
			// this.getView().byId("filterBarB").setVisible(true);

			// },
			onExport: function() {
	/*******************************for excel column heading**************************************/		
				var	acolumns = [
				{
				name: "Reservation No/Item",
				template: {
				content: {
				path: "COMB"
				}
				}
				},
				{
				name: "Plant/Storageloc",
				template: {
				content: {
				path: "COMB1"
				}
				}
				},
				{
				name: "Material Document",
				template: {
				content: {
				path: "MBLNR"
				}
				}
				},
				{
				name: "Material Document Year",
				template: {
				content: {
				path: "MJAHR"
				}
				}
				},
				{
				name: "Item in Material Document",
				template: {
				content: {
				path: "ZEILE"
				}
				}
				},
				{
				name: "Issue Date",
				template: {
				content: {
				path: "BUDAT"
				}
				}
				},
				{
				name: "Route",
				template: {
				content: {
				path: "ROUTE"
				}
				}
				},
				{
				name: "Issue Qty",
				template: {
				content: {
				path: "ENMNG"
				}
				}
				},
				// {
				// name: "Handover Qty",
				// template: {
				// content: {
				// path: "HANDOVR_QTY"
				// }
				// }
				// },
				{
				name: "Handover Qty Compl",
				template: {
				content: {
				path: "HANDOVR_QTY_COMPL"
				}
				}
				},
				{
				name: "Handovr Qty Remaining",
				template: {
				content: {
				path: "HANDOVR_QTY_REMAIN"
				}
				}
				},
				{
				name: "Delivery Point",
				template: {
				content: {
				path: "WEMPF"
				}
				}
				},
					{
				name: "Material No",
				template: {
				content: {
				path: "MATNR"
				}
				}
				},
					{
				name: "Material Description",
				template: {
				content: {
				path: "MAKTX"
				}
				}
				},
					{
				name: "Status",
				template: {
				content: {
				path: "FINALSTATUS",
					formatter: function(v) {
													if(v === 'A'){
														return 'Active';
													}else if (v === 'P'){
														return 'Partial';
													}
														
												}
				}
				}
				},
				];
				
				
				
			var getAuthorityModel = sap.ui.getCore().getModel("oAuthorityModel");
		//	console.log(getAuthorityModel);
			var oExport = new sap.ui.core.util.Export({
				exportType: new  sap.ui.core.util.ExportTypeCSV({
				separatorChar: "\t",
				
				mimeType: "application/vnd.ms-excel" ,
				charset: "utf-8" ,
				fileExtension: "xls"
				
				}),
				models: getAuthorityModel,
				rows: {
				path: "/" 
				},
				
				// column definitions with column name and binding info for the content
				columns: acolumns
				
			});
			oExport.saveFile().catch(function(oError) {
			//Handle your error
			}).then(function() {
			oExport.destroy();
			});
			},
			onChangeRoute: function(evt) {
				var selectedRoute;
			
				
				var filters = new Array();
				// var filterPP = new sap.ui.model.Filter(
				// 	"Katalogart",
				// 	sap.ui.model.FilterOperator.EQ, "B"
				// );
				// filters.push(filterPP);
				var selectedRoute = this.getView().byId("Route").getSelectedKey();
				var filterPG = new sap.ui.model.Filter(
					"ROUTE",
					sap.ui.model.FilterOperator.EQ, selectedRoute
				);
				filters.push(filterPG);
				var oTableScore = this.getView().byId("Delv");
				var sURI = "/sap/opu/odata/sap/YMPI_HOME_DELIVERY_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(sURI, true);
				oModel.read("/DELIVERYPOINTSet", {
					filters: filters,
					success: function(oData, resonse) {

						var value = [];
						value = oData.results;
						var oModel1 = new sap.ui.model.json.JSONModel();
						oModel1.setData({
							DELIVERYPOINTSet: value
						});
						oTableScore.setModel(oModel1);
						// this.getId("idPlan_PlantCode").getView.setData(oModel1);
					},
					error: function(oError) { //read error}
					}
				});
			},

			scancode: function(oEvent) {
				// this.getView().byId("btnENTDET").setVisible(false);
				// this.getView().byId("det").setVisible(false);

				sap.ndc.BarcodeScanner.scan(
					jQuery.proxy(function(mResult) {
						that.FLAG = "X";
						var scandtls = mResult.text;
						var vechdtls = mResult.text.split("/");
						if (  vechdtls.length === 1 ){
						that.VEHICLENO1 = vechdtls[0];
						 this.getView().byId("VEHICLENO").setValue(vechdtls[0]);
						} else if (  vechdtls.length === 2 ){
							that.DRIVERNAME1 = vechdtls[0];
							 that.DRIVERCONTACTNO1 = vechdtls[1];		
							  this.getView().byId("DRIVERNAME").setValue(vechdtls[0]);
						 this.getView().byId("DRIVERCONTACTNO").setValue(vechdtls[1]);
						}
						//alert(Drivername);
						// that.DRIVERNAME1 = vechdtls[0];
						// that.DRIVERCONTACTNO1 = vechdtls[1];
						//that.VEHICLENO1 = vechdtls[0];
						// this.getView().byId("DRIVERNAME").setValue(vechdtls[0]);
						// this.getView().byId("DRIVERCONTACTNO").setValue(vechdtls[1]);
						 //this.getView().byId("VEHICLENO").setValue(vechdtls[0]);
						// alert("We got a bar code\n" +
						// 	"Result: " + mResult.text + "\n" +
						// 	"Format: " + mResult.format + "\n" +
						// 	"Cancelled: " + mResult.cancelled);

					}, this),
					function(Error) {
						this.showAlertMessage2(Error);
					}
				);
			},

			onFilter: function(oEvent) {
				this.sSearchQuery = oEvent.getSource().getValue();
				this.fnApplyFiltersAndOrdering();
			},

			onSort: function(oEvent) {
				this.bDescending = !this.bDescending;
				this.fnApplyFiltersAndOrdering();
			},
			/**************************show alert message*************************/
			showAlertMessage: function(val) {
				sap.m.MessageBox.error(val, {
					title: "Information",
					onClose: null,
					styleClass: "",
					initialFocus: null,
					actions: sap.m.MessageBox.Action.OK,
					textDirection: sap.ui.core.TextDirection.Inherit
				});

			},

			showAlertMessage1: function(val) {
				sap.m.MessageBox.error(val, {
					title: "Error",
					styleClass: "",
					initialFocus: null,
					actions: sap.m.MessageBox.Action.OK,
					textDirection: sap.ui.core.TextDirection.Inherit,
					onClose: jQuery.proxy(function(oAction) {
						if (oAction === "OK") {
							// setTimeout(function() {
							// 	//this.byId("Homedlv").hide();
							// 	this.onSearch();
							// }.bind(this),2000);
						}
					}, this)
				});

			},
			
				showAlertMessage2: function(val) {
				sap.m.MessageBox.error(val, {
					title: "SUCCESS",
					styleClass: "",
					initialFocus: null,
					actions: sap.m.MessageBox.Action.OK,
					textDirection: sap.ui.core.TextDirection.Inherit,
					onClose: jQuery.proxy(function(oAction) {
						if (oAction === "OK") {
							setTimeout(function() {
						
								this.onSearch();
							}.bind(this), 2000);
						}
					}, this)
				});

			},
			
				handleConfirmationMessageBoxPress: function (val) {
				var that2 = this;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.confirm(
					val, {
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "CANCEL") {
								return false;

							} else {
								//that.post = "X";
								that2.submitData();
							}
						}
					}
				);
			},
	
			
			submitData:function (){
				
						
				allErrorMsg = '';
				allErrorMsg1 = '';
				var c = 0;
				var h = 0;
				var oTable = this.getView().byId("Homedlv");
				var oSelectedItem = oTable.getSelectedItems();

				var oSelectedItemcount = oSelectedItem.length;
				
				var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPI_HOME_DELIVERY_SRV/");
				var aDeferredGroup = oModel.getDeferredGroups().concat("updateCreate");
				oModel.setDeferredGroups(aDeferredGroup);
				//	var ModelLength = omodelUpdateBIS.oData.HANDOVERSet.length;
				oModel.setUseBatch(true);
				var mParameters = {
					groupId: "updateCreate"
				};
				var NewData = {};
				// var LastRecInd = 0;
				for (var i = 0; i < oSelectedItemcount; i++) {
					if (i === (oSelectedItemcount - 1)) {
						// LastRecInd = 1;
					}

					//	var item1 = oSelectedItem[i];

					NewData = {
						"ROW": oSelectedItem[i].getBindingContext().getProperty("ROW"),
						"COMB": oSelectedItem[i].getBindingContext().getProperty("COMB"),
						"COMB1": oSelectedItem[i].getBindingContext().getProperty("COMB1"),
						"RSNUM": oSelectedItem[i].getBindingContext().getProperty("RSNUM"),
						"RSPOS": oSelectedItem[i].getBindingContext().getProperty("RSPOS"),
						"MBLNR": oSelectedItem[i].getBindingContext().getProperty("MBLNR"),
						"MJAHR": oSelectedItem[i].getBindingContext().getProperty("MJAHR"),
						"ZEILE": oSelectedItem[i].getBindingContext().getProperty("ZEILE"),
						"COUNTER": oSelectedItem[i].getBindingContext().getProperty("COUNTER"),
						"BUDAT": oSelectedItem[i].getBindingContext().getProperty("BUDAT"),
						"ENMNG": oSelectedItem[i].getBindingContext().getProperty("ENMNG"),
						"ROUTE": oSelectedItem[i].getBindingContext().getProperty("ROUTE"),
						"WEMPF": oSelectedItem[i].getBindingContext().getProperty("WEMPF"),
						"MATNR": oSelectedItem[i].getBindingContext().getProperty("MATNR"),
						"MAKTX": oSelectedItem[i].getBindingContext().getProperty("MAKTX"),
						"WERKS": oSelectedItem[i].getBindingContext().getProperty("WERKS"),
						"LGORT": oSelectedItem[i].getBindingContext().getProperty("LGORT"),
						"HANDOVR_QTY": oSelectedItem[i].getBindingContext().getProperty("HANDOVR_QTY"),
						"HANDOVR_QTY_COMPL": oSelectedItem[i].getBindingContext().getProperty("HANDOVR_QTY_COMPL"),
						"HANDOVR_QTY_REMAIN": oSelectedItem[i].getBindingContext().getProperty("HANDOVR_QTY_REMAIN"),
						"FINALSTATUS": oSelectedItem[i].getBindingContext().getProperty("FINALSTATUS"),
						"DRIVERNAM": oSelectedItem[i].getBindingContext().getProperty("DRIVERNAM"),
						"DRIVERPH": oSelectedItem[i].getBindingContext().getProperty("DRIVERPH"),
						"VECHNO": oSelectedItem[i].getBindingContext().getProperty("VECHNO"),
						"VEHICLEDET": oSelectedItem[i].getBindingContext().getProperty("VEHICLEDET"),
						// "DRIVERNAME1": this.getView().byId("DRIVERNAME").getValue(),
						// "DRIVERCONTACTNO1": this.getView().byId("DRIVERCONTACTNO").getValue(),
						// "VEHICLENO1": this.getView().byId("VEHICLENO").getValue(),
						"VEHICLEDETAILS1": that.VEHICLEDETAILS,
						"DRIVERNAME1": that.DRIVERNAME,
						"DRIVERCONTACTNO1": that.DRIVERCONTACTNO,
						"VEHICLENO1": that.VEHICLENO
							//	"LastRecInd": LastRecInd
							//	"Insert": "N",
							//	"Update": "Y"var DRIVERNAME = "";

					};
					// break;
					// }
					// 	if (parseFloat(NewData.ENMNG.trim()) < parseFloat(NewData.HANDOVR_QTY.trim())) {
					// 		var c = i + 1;
					// 		allErrorMsg += "(" + c + ") MRNo : " + NewData.RSNUM + " and MR ItemNo : " + NewData.RSPOS + ".  ";

					// 		//this.showAlertMessage1("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
					// 		//return false;
					// 		//throw new Error("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
					// 	} else {

					// 		oModel.create("/HANDOVERSet", NewData, mParameters);
					// 	}

					// }
					// var myInteger = (/^-?\d*(\.\d+)?$/);
					// var letters = /[a-zA-Z/!/"/#/$/%/&/'/(/)/*/+/,/-/:/;/</=/>/?/@/\/]/g;
					// var letters1 = /^[0-9]+$/;
					// if ((NewData.HANDOVR_QTY.trim()).match(letters)) {
					// 	this.showAlertMessage2("Please Input Valid Handover Quantity");
					// 	return false;
					// }else 	if ((NewData.HANDOVR_QTY.trim()).match(myInteger)) {
					// 	this.showAlertMessage2("Please Input Valid Handover Quantity");
					// 	return false;
					// }
					// else if (((NewData.HANDOVR_QTY.trim()).match(letters1)) && (NewData.HANDOVR_QTY.trim()).match(letters)) {
					// 	this.showAlertMessage2("Please Input Valid Handover Quantity");
					// 	return false;
					// }
					
					if((NewData.HANDOVR_QTY.trim())=== "" ){
							this.showAlertMessage1("Please Input Valid Handover Quantity");
							return false;
					};
					var str = (NewData.HANDOVR_QTY.trim());
					var avi = (Math.sign(str));
					if(avi <= 0 ){
						this.showAlertMessage1("Please Input Valid Handover Quantity");
							return false;	
					}	else if (avi === "NaN") {
						this.showAlertMessage1("Please Input Valid Handover Quantity");
					}
					if (parseFloat(NewData.ENMNG.trim()) < parseFloat(NewData.HANDOVR_QTY.trim())) {

						c = c + 1;
						allErrorMsg += "(" + c + ") MRNo : " + NewData.RSNUM + " and MR ItemNo : " + NewData.RSPOS + ".  ";

						//this.showAlertMessage1("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
						//return false;
						//throw new Error("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
					} else if ((parseFloat(NewData.HANDOVR_QTY.trim()) > parseFloat(NewData.HANDOVR_QTY_REMAIN.trim())) && (parseFloat(NewData.HANDOVR_QTY_COMPL
							.trim()) !== 0 && parseFloat(NewData.HANDOVR_QTY_REMAIN.trim()) !== 0)) {
						h = h + 1;
						allErrorMsg1 += "(" + h + ") MRNo : " + NewData.RSNUM + " and MR ItemNo : " + NewData.RSPOS + ".  ";
					} else {

						oModel.create("/HANDOVERSet", NewData, mParameters);
					}

				}

				if (allErrorMsg !== '') {
					allErrorMsg = Fixmsg + " " + allErrorMsg;
					this.showAlertMessage1(allErrorMsg);
					// this.getView().byId("editButton").setVisible(false);
					this.getView().byId("saveButton").setVisible(true);
					// this.getView().byId("cancelButton").setVisible(true);
					return false;
				}

				if (allErrorMsg1 !== '') {
					allErrorMsg1 = Fixmsg1 + " " + allErrorMsg1;
					this.showAlertMessage1(allErrorMsg1);
					// this.getView().byId("editButton").setVisible(false);
					this.getView().byId("saveButton").setVisible(true);
					// this.getView().byId("cancelButton").setVisible(true);
					return false;
				}

				//	oModel.create("/HANDOVERSet", NewData, mParameters);
				//}

				//var that = this;

				oModel.submitChanges({
					success: jQuery.proxy(function(oSuccess, response) {
						var value = [];
						var strInfo = "";
						// alert("msg");

						this.showAlertMessage2("DATA UPDATED SUCCESSFULLY");
					}, this),

					//value = response.data.__batchResponses[0].__changeResponses[0]["body"];
					// for (var j = 0; j < oSelectedItemcount; j++) {
					// 	value[j] = jQuery.parseJSON(response.data.__batchResponses[0].__changeResponses[j].body)["d"]["MsgInd"];
					// }
					// sap.m.MessageToast.show("Updated!");
					// 	for (var j = 0; j < oSelectedItemcount; j++) {
					// 		value[j] = jQuery.parseJSON(response.data.__batchResponses[j].__changeResponses[j].data.MSGIND);
					// 	if (value[j] === "S") {
					// 		strInfo = strInfo + "\n Row " + j + "- Data Updated Succesfully";
					// }
					// 	}
					//ERROR HANDLING OF THE EXCEPTION
					// var obj = JSON.parse(response.data.__batchResponses[0].response.body);
					// sap.m.MessageToast.show(obj.error.message["value"]);
					//	that.DisplayMessage(" Workflow successfully created.", "success");
					// 	var oModel1 = new sap.ui.model.json.JSONModel();
					// 	oModel1.setData({
					// 		HANDOVERSet: value

					// 	});

					// },
					error: jQuery.proxy(function(oError) { //read error}
						var err = oError;

						//that.DisplayMessage("Could Not Create Workflow . Please try again later", "error");
						this.showAlertMessage1("Invalid Data!");
						setTimeout(function() {
							//this.byId("Homedlv").hide();
							this.onSearch();
						}.bind(this), 2000);

					}, this),
				});

				var oTemplate = new sap.m.ColumnListItem({
					cells: [
									new sap.m.Text({
									text: "{ROW}"

								}),
						
							new sap.m.Text({
							text: "{COMB}"

						}),
						new sap.m.Text({
							text: "{COMB1}"

						}),
						new sap.m.Text({
							text: "{RSNUM}"

						}),
						new sap.m.Text({
							text: "{RSPOS}"
						}),
						new sap.m.Text({
							text: "{MBLNR}"
						}),
						new sap.m.Text({
							text: "{MJAHR}"
						}),
						new sap.m.Text({
							text: "{ZEILE}"
						}),
						new sap.m.Text({
							text: "{COUNTER}"
						}),
						new sap.m.Text({
							text: "{BUDAT}"
						}),

						new sap.m.Text({
							text: "{ROUTE}"
						}),

						new sap.m.Text({
							text: "{ENMNG}"
						}).addStyleClass("iqty"),
						new sap.m.Text({
							text: "{HANDOVR_QTY}"
						}).addStyleClass("hdqty"),
						new sap.m.Text({
							text: "{HANDOVR_QTY_COMPL}"
						}),
						new sap.m.Text({
							text: "{HANDOVR_QTY_REMAIN}"
						}),
						new sap.m.Text({
							text: "{WEMPF}"
						}),
						new sap.m.Text({
							text: "{MATNR}"
						}),
						new sap.m.Text({
							text: "{MAKTX}"
						}),
						new sap.m.Text({
							text: "{WERKS}"
						}),
						new sap.m.Text({
							text: "{LGORT}"
						}),

						new sap.m.Text({
							text: "{FINALSTATUS}"
						}),
						new sap.m.Text({
							text: "{DRIVERNAM}"
						}),
						new sap.m.Text({
							text: "{DRIVERPH}"
						}),
						new sap.m.Text({
							text: "{VECHNO}"
						}),
						new sap.m.Text({
							text: "{VEHICLEDET}"
						})

					]
				});
				this.rebindTable(oTemplate, "Navigation");

				// this.showAlertMessage2("DATA UPDATED SUCCESSFULLY");

				// setTimeout(function() {
				// 				//this.byId("Homedlv").hide();
				// 				this.onSearch();
				// 			}.bind(this),4000);

				//this.getView().byId("addButton").setVisible(true);
			},
			
			
			handleRefresh: function(evt) {
				setTimeout(function() {
					this.byId("pullToRefresh").hide();
					this.onSearch();
				}.bind(this), 2000);
			},

			onReset: function(oEvent) {
				this.bGrouped = false;
				this.bDescending = false;
				this.sSearchQuery = 0;
				this.byId("maxPrice").setValue("");

				this.fnApplyFiltersAndOrdering();
			},

			// _fnGroup: function(oContext) {
			// 	var ReservationNo = oContext.getProperty("RSNUM");

			// 	return {
			// 		key: ReservationNo,
			// 		text: ReservationNo
			// 	};
			// },

			// fnApplyFiltersAndOrdering: function(oEvent) {
			// 	var aFilters = [],
			// 		aSorters = [];

			// 	if (this.bGrouped) {
			// 		aSorters.push(new Sorter("RSNUM", this.bDescending, this._fnGroup));
			// 	} else {
			// 		aSorters.push(new Sorter("RSNUM", this.bDescending));
			// 	}

			// 	if (this.sSearchQuery) {
			// 		var oFilter = new Filter("RSNUM", sap.ui.model.FilterOperator.Contains, this.sSearchQuery);
			// 		aFilters.push(oFilter);

			// 	}

			// 	this.byId("Homedlv").getBinding("items").filter(aFilters).sort(aSorters);
			// },
			// liveChangeFYInput: function(oEvent) {

			// },

			onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
			},
			createTokens: function(oEvent, obj) {
				//var oView = this.getView();
				//var tokens = obj.getTokens();
				// var _newTokens = [];
				var _newTokens = new sap.m.Token({
					text: oEvent.getParameters().newValue,
					key: oEvent.getParameters().newValue
				});

				// For 1.54 or above version
				// tokens.push(_newTokens);
				// obj.setTokens(tokens);
				// obj.setValue("");

				// 	// For 1.44 or less version
				obj.addToken(_newTokens);
				obj.setValue("");

			},
			changeToken: function(oEvent) {
				var oView = this.getView();
				var oMultiInput1 = oView.byId(oEvent.mParameters.id);
				this.createTokens(oEvent, oMultiInput1);
			},

			/***************************Material search help*************************/
			showValueHelpMaterial: function() {
				oValueHelpDialog = null;
				var multiInputMaterial = this.getView().byId("multiInputMaterial");
				//var that = this;
				if (multiInputMaterial.getTokens().length <= 0) {
					that.materialTableValue = null;
				}
				oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
					supportRanges: true,
					title: "MATERIALS",
					key: "MATNR",
					descriptionKey: "MATNR",
					tokenDisplayBehaviour: "MATNR",
					ok: function(oControlEvent) {
						aTokens = oControlEvent.getParameter("tokens");
						var sTokens = "";
						for (var i = 0; i < aTokens.length; i++) {
							var oToken = aTokens[i];
							sTokens += oToken.getText() + " ";
						}

						multiInputMaterial.setTokens(aTokens);
						if (!that.materialTableValue) {
							that.materialTableValue = oValueHelpDialog.getTable().getModel().getData();
						}
						oValueHelpDialog.close();
						oValueHelpDialog = null;

					},
					cancel: function(oControlEvent) {
						oValueHelpDialog.close();
						oValueHelpDialog = null;
					},
					afterClose: function() {
						this.destroy();
						oValueHelpDialog = null;
					}
				});

				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
							label: "Material",
							template: "MATNR",
							iskey: "true"
						}, {
							label: "Description",
							template: "MAKTX"
						}

					]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

				if (!that.materialTableValue) {
					oValueHelpDialog.setBusy(true);
					// sap.ui.core.BusyIndicator.show();
					var oRowsModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMPI_HOME_DELIVERY_SRV/");
					oRowsModel.read("/MaterialNoSet", {
						//filters: filters,
						success: function(oData, response) {
							//	MessageToast.show(evt.getSource().getId() + " Pressed");
							var value = [];
							value = oData.results;
							var oModelMatnr = new sap.ui.model.json.JSONModel();
							oModelMatnr.setData(value);
							oValueHelpDialog.getTable().setModel(oModelMatnr);
							if (oValueHelpDialog.getTable().bindRows) {
								oValueHelpDialog.getTable().bindRows("/");
							}
							if (multiInputMaterial.getTokens().length > 0) {
								oValueHelpDialog.setTokens(multiInputMaterial.getTokens());
							}
							oValueHelpDialog.setBusy(false);
							oValueHelpDialog.update();

						},
						error: function(oError) { //read error}
							sap.m.MessageToast.show("Error Fetching data");
						},
						beforeOpen: function(oControlEvent) {
							sap.m.MessageToast.show("Selection changed!");
						}
					});
				} else {
					var oModelPlant2 = new sap.ui.model.json.JSONModel();
					oModelPlant2.setData(that.materialTableValue);
					oValueHelpDialog.getTable().setModel(oModelPlant2);
					if (oValueHelpDialog.getTable().bindRows) {
						oValueHelpDialog.getTable().bindRows("/");
					}
					if (multiInputMaterial.getTokens()) {
						oValueHelpDialog.setTokens(multiInputMaterial.getTokens());
					}
					oValueHelpDialog.open();
					oValueHelpDialog.update();
				}

				oValueHelpDialog.setRangeKeyFields([{
					label: "Material",
					key: "MATNR"
				}]);

				var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
					advancedMode: true,
					filterBarExpanded: false,
					searchEnabled: true,
					showGoOnFB: true,
					showClearButton: true
				});

				if (oFilterBar.setBasicSearch) {
					oFilterBar.setBasicSearch(new sap.m.SearchField({
						tooltip: "Search for MATERIAL",
						placeholder: "Search",
						search: function(event) {
							var data = event.mParameters.query;
							var oFilters = new sap.ui.model.Filter({
								and: false,
								filters: [
									new sap.ui.model.Filter({

										filters: [
											new sap.ui.model.Filter("MATNR", sap.ui.model.FilterOperator.Contains, data)
										]
									}),
									new sap.ui.model.Filter({

										filters: [
											new sap.ui.model.Filter("MAKTX", sap.ui.model.FilterOperator.Contains, data)
										]
									})
								]
							});
							// var oElement = sap.ui.getCore().byId("idValueHelpPlant").getTable();
							var oElement = oValueHelpDialog.getTable();
							oElement.getBinding("rows").filter([oFilters]);
						}
					}));
				}
				oValueHelpDialog.setFilterBar(oFilterBar);
				oValueHelpDialog.open();

			},
			/***********************************************************/
			showValueHelpRSNUM: function() {
				var multiInputRSNUM = this.getView().byId("multiInputRSNUM");
				this.getView().byId("multiInputRSNUM").setValueState(sap.ui.core.ValueState.None);
				if (!this._oValueHelpDialogMatno) {
					this._oValueHelpDialogMatno = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("multiInputRSNUM", {
						supportRanges: true,
						supportRangesOnly: true,
						title: "Material Reservation Number",
						key: "RSNUM",
						descriptionKey: "Material Reservation No",
						tokenDisplayBehaviour: "Material Reservation No",
						ok: function(oEvent) {
							var aTokens = oEvent.getParameter("tokens");
							multiInputRSNUM.setTokens(aTokens);
							// var tokens = multiInputMatNo.getTokens();
							// jQuery.each(tokens, function(idx, token) {
							// 	token.setEditable(false);
							// });
							this.close();
						},
						cancel: function() {
							this.close();
						}
					});
				}
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
						label: "Material Reservation No",
						template: "Material Reservation No"

					}]
				});

				this._oValueHelpDialogMatno.setRangeKeyFields([{
					label: "MaterialReservation No",
					key: "RSNUM"
				}]);

				//			this._oValueHelpDialogMatno.setModel(oModelMatno);
				this._oValueHelpDialogMatno.open();
			},
			showValueHelpDlvpnt: function() {
				var multiInputDlvpnt = this.getView().byId("multiInputDlvpnt");
				this.getView().byId("multiInputDlvpnt").setValueState(sap.ui.core.ValueState.None);
				if (!this._oValueHelpDialogDlvpnt) {
					this._oValueHelpDialogDlvpnt = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("multiInputDlvpnt", {
						supportRanges: true,
						supportRangesOnly: true,
						title: "Delivery Point",
						key: "WEMPF",
						descriptionKey: "Delivery Point",
						tokenDisplayBehaviour: "Delivery Point",
						ok: function(oEvent) {
							var aTokens = oEvent.getParameter("tokens");
							multiInputDlvpnt.setTokens(aTokens);
							// var tokens = multiInputMatNo.getTokens();
							// jQuery.each(tokens, function(idx, token) {
							// 	token.setEditable(false);
							// });
							this.close();
						},
						cancel: function() {
							this.close();
						}
					});
				}
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
						label: "Delivery Point",
						template: "Delivery Point"

					}]
				});

				this._oValueHelpDialogDlvpnt.setRangeKeyFields([{
					label: "Delivery Point",
					key: "WEMPF"
				}]);

				//			this._oValueHelpDialogMatno.setModel(oModelMatno);
				this._oValueHelpDialogDlvpnt.open();
			},

			PostFilterDataToBackend: function(filters) {
				var oTable = this.getView().byId("Homedlv");
				var _that2 = this;
				that.bck = "";
				oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPI_HOME_DELIVERY_SRV/");
				sap.ui.core.BusyIndicator.show(0);
				oModel.read("/HANDOVERSet", {
					filters: filters,
					success: function(oData, response) {
						
						var value = [];
						value = oData.results;
						var oModelHANDOVERSet = new sap.ui.model.json.JSONModel();
						oModelHANDOVERSet.setData({
							HANDOVERSet: value
						});
						
							/**********************export****************/
						var oAuthorityData = oModelHANDOVERSet.oData.HANDOVERSet;
						var oAuthorityModel = new sap.ui.model.json.JSONModel(oAuthorityData);
						sap.ui.getCore().setModel(oAuthorityModel, "oAuthorityModel");	
						/**************************end******************/


						var oTemplate = new sap.m.ColumnListItem({
							cells: [
									new sap.m.Text({
									text: "{ROW}"

								}),
								
									new sap.m.Text({
									text: "{COMB}"

								}),
								new sap.m.Text({
									text: "{COMB1}"

								}),
								new sap.m.Text({
									text: "{RSNUM}"

								}),
								new sap.m.Text({
									text: "{RSPOS}"
								}),
								new sap.m.Text({
									text: "{MBLNR}"
								}),
								new sap.m.Text({
									text: "{MJAHR}"
								}),
								new sap.m.Text({
									text: "{ZEILE}"
								}),
								// new sap.m.Text({
								// 	text: "{COUNTER}"
								// }),

								new sap.m.Text({
									text: "{BUDAT}"
								}),

								new sap.m.Text({
									text: "{ROUTE}"
								}),
								new sap.m.Text({
									text: "{ENMNG}"
								}).addStyleClass("iqty"),
								new sap.m.Input({
									value:"{HANDOVR_QTY}",
									type: "Number"
								}).addStyleClass("hdqty"),
								new sap.m.Text({
									text: "{HANDOVR_QTY_COMPL}"
								}),
								new sap.m.Text({
									text: "{HANDOVR_QTY_REMAIN}"
								}),
								new sap.m.Text({
									text: "{WEMPF}"
								}),
								new sap.m.Text({
									text: "{MATNR}"
								}),
								new sap.m.Text({
									text: "{MAKTX}"
								}),
								new sap.m.Text({
									text: "{WERKS}"
								}),
								new sap.m.Text({
									text: "{LGORT}"
								}),
								new sap.m.Text({
									// text:"{FINALSTATUS}"
											text: {
												path: "FINALSTATUS",
												formatter: function(v) {
													if(v === 'A'){
														return 'Active';
													}else if (v === 'P'){
														return 'Partial';
													}
														
												}
											}
											
										}),

								new sap.m.Text({
									text: "{DRIVERNAM}"
								}),
								new sap.m.Text({
									text: "{DRIVERPH}"
								}),
								new sap.m.Text({
									text: "{VECHNO}"
								}),
								new sap.m.Text({
									text: "{VEHICLEDET}"
								})

							]
						});

						oTable.setModel(oModelHANDOVERSet);
						sap.ui.getCore().setModel(oModelHANDOVERSet, "oModelTest");
						oTable.bindAggregation("items", {
							path: "/HANDOVERSet",
							template: oTemplate
						});
						sap.ui.core.BusyIndicator.hide();
					}

				});
			},

			onSearch: function(event) {
				
				that.DRIVERNAME = this.getView().byId("DRIVERNAME").getValue();
				that.DRIVERCONTACTNO = this.getView().byId("DRIVERCONTACTNO").getValue();
				that.VEHICLENO = this.getView().byId("VEHICLENO").getValue();
				that.VEHICLEDETAILS = this.getView().byId("VEHICLEDETAILS1A").getValue();
				var lett = /^[0-9]+$/;
				if ((that.DRIVERNAME).match(lett)) {
					this.showAlertMessage("Name is Invalid");
					return false;
				} else if (that.DRIVERCONTACTNO.length < 10) {
					this.showAlertMessage("Please Provide Correct Phone No!");
					return false;
				} else if ((that.DRIVERNAME1 === "" && that.FLAG === "X") && (that.DRIVERNAME === "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO ===
						"")) {

					this.showAlertMessage("Please Provide the Inputs!");
					return false;

				} else if ((that.DRIVERNAME1 === "" && that.FLAG === "X") && (that.DRIVERNAME === "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO !==
						"")) {

					this.showAlertMessage("Please Provide the Inputs!");
					return false;

				} else if (that.FLAG === "" && (that.DRIVERNAME !== "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME !== "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME !== "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				} else if (that.DRIVERNAME === "" && that.FLAG === "") {
					this.showAlertMessage("Either Scan ID Or Provide Manual Entries");
					return false;
				}  else if (that.FLAG === "X" && (that.DRIVERNAME !== "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				} else if (that.FLAG === "X" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				} else if (that.FLAG === "X" && (that.DRIVERNAME !== "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide the Inputs");
					return false;
				}
				this.getView().byId("filterBa").setVisible(false);
				this.getView().byId("btnsubmit").setVisible(false);
				this.getView().byId("filterBar1").setVisible(true);
				this.getView().byId("filterBarC").setVisible(false);
				
				if(that.bck === "X"){
				var multiInputRSNUM = this.getView().byId("multiInputRSNUM");
				var RSNUMtokens = multiInputRSNUM.getTokens();

				var multiInputMaterial = this.getView().byId("multiInputMaterial");
				var matnrtokens = multiInputMaterial.getTokens();
				var Plant = this.getView().byId("Plant").getValue();
				var Route = this.getView().byId("Route").getSelectedKey();
	
				var Delv = this.getView().byId("Delv").getSelectedKeys();

				var WERKS = this.getView().byId("Plant").getValue();
				var ROUTE = this.getView().byId("Route").getValue();
				var ROUTE = this.getView().byId("Route").setValue();
				
				var multiInputRSNUM = this.getView().byId("multiInputRSNUM");
				var multiInputDlvpnt = this.getView().byId("multiInputDlvpnt");
				var multiInputMaterial = this.getView().byId("multiInputMaterial");
				// var WERKS = this.getView().byId("Plant").getValue();
				// var ROUTE = this.getView().byId("Route").getValue();

				multiInputRSNUM.destroyTokens();
				Route = "";
				multiInputMaterial.destroyTokens();
				this.getView().byId("Plant").setValue();
				this.getView().byId("Delv").setSelectedKeys();
				this.getView().byId("DP1").setDateValue(new Date());
				this.getView().byId("DP2").setDateValue(new Date());
				}
				
				var filters = new Array();
				// this.getView().byId("cancelButton").setVisible(false);
				this.getView().byId("saveButton").setVisible(true);
				this.getView().byId("otbFooter").setVisible(true);
				this.getView().byId("Homedlv").setVisible(true);
				// this.getView().byId("editButton").setVisible(true);
				var multiInputRSNUM = this.getView().byId("multiInputRSNUM");
				var RSNUMtokens = multiInputRSNUM.getTokens();

				var multiInputMaterial = this.getView().byId("multiInputMaterial");
				var matnrtokens = multiInputMaterial.getTokens();
				var Plant = this.getView().byId("Plant").getValue();
				var Route = this.getView().byId("Route").getSelectedKey();
				var DP1 = this.getView().byId("DP1").getValue();
				var DP2 = this.getView().byId("DP2").getValue();
				var Delv = this.getView().byId("Delv").getSelectedKeys();

				var WERKS = this.getView().byId("Plant").getValue();
				var ROUTE = this.getView().byId("Route").getValue();

				if (Route !== "" && DP1 === "" && DP2 === "" && RSNUMtokens.length === 0 && (Delv === "" || Plant === "" || matnrtokens.length ===
						0)) {
					this.showAlertMessage("Issue Date Range Is Mandatory !");
					return false;
				} else if (Delv !== "" && DP1 === "" && DP2 === "" && RSNUMtokens.length === 0 && (Route === "" || Plant === "" || matnrtokens.length ===
						0)) {
					this.showAlertMessage("Issue Date Range Is Mandatory !");
					return false;
				} else if (Plant !== "" && DP1 === "" && DP2 === "" && RSNUMtokens.length === 0 && (Route === "" || Delv === "" || matnrtokens.length ===
						0)) {
					this.showAlertMessage("Issue Date Range Is Mandatory !");
					return false;
				} else if (matnrtokens.length > 0 && DP1 === "" && DP2 === "" && RSNUMtokens.length === 0 && (Route === "" || Delv === "" || Plant ===
						"")) {
					this.showAlertMessage("Issue Date Range Is Mandatory !");
					return false;
				} else if (DP1 === "" && DP2 === "" && RSNUMtokens.length === 0 && (Route === "" || Delv === "" || Plant === "" || matnrtokens.length >
						0)) {
					this.showAlertMessage("Issue Date Range Is Mandatory !");
					return false;
				} else {

					var filtermatnr = new sap.ui.model.Filter();
					for (var i = 0; i < matnrtokens.length; i++) {
						if (matnrtokens[i].getKey().indexOf("range") === -1) {
							filtermatnr = new sap.ui.model.Filter("MATNR", sap.ui.model.FilterOperator.EQ, matnrtokens[i].getKey());
						} else {
							if (matnrtokens[i].data().range.exclude) {
								filtermatnr = new sap.ui.model.Filter("MATNR", sap.ui.model.FilterOperator.NE, matnrtokens[i].data().range.value1);
							} else {
								filtermatnr = new sap.ui.model.Filter("MATNR", matnrtokens[i].data().range.operation, matnrtokens[i].data().range.value1,
									matnrtokens[i].data().range.value2);
							}
						}
						filters.push(filtermatnr);
					}
					// if (Delv !== "") {
					// var oFilters1 = new sap.ui.model.Filter({
					// 	path: "WEMPF",
					// 	operator: sap.ui.model.FilterOperator.EQ,
					// 	value1: Delv
					// });
					// filters.push(oFilters1);
					// }
					// var filters = new Array();
					for (var M = 0; M < Delv.length; M++) {
						var oFilters1 = new sap.ui.model.Filter("WEMPF",
							sap.ui.model.FilterOperator.EQ, Delv[M]);
						filters.push(oFilters1);
					}

					var filterRSNUM = new sap.ui.model.Filter();
					for (var j = 0; j < RSNUMtokens.length; j++) {
						if (RSNUMtokens[j].getKey().indexOf("range") === -1) {
							filterRSNUM = new sap.ui.model.Filter("RSNUM", sap.ui.model.FilterOperator.EQ, RSNUMtokens[j].getKey());
						} else {
							if (RSNUMtokens[j].data().range.exclude) {
								filterRSNUM = new sap.ui.model.Filter("RSNUM", sap.ui.model.FilterOperator.NE, RSNUMtokens[j].data().range.value1);
							} else {
								filterRSNUM = new sap.ui.model.Filter("RSNUM", RSNUMtokens[j].data().range.operation, RSNUMtokens[j].data().range.value1,
									RSNUMtokens[j].data().range.value2);
							}
						}
						filters.push(filterRSNUM);
					}

					// var Dlvpnt = this.getView().byId("multiInputDlvpnt");
					// var Dlvpnttokens = Dlvpnt.getTokens();
					// //var filters = new Array();

					// var filterDlvpnt = new sap.ui.model.Filter();
					// for (var k = 0; k < Dlvpnttokens.length; k++) {
					// 	if (Dlvpnttokens[k].getKey().indexOf("range") === -1) {
					// 		filterDlvpnt = new sap.ui.model.Filter("WEMPF", sap.ui.model.FilterOperator.EQ, Dlvpnttokens[k].getKey());
					// 	} else {
					// 		if (Dlvpnttokens[k].data().range.exclude) {
					// 			filterDlvpnt = new sap.ui.model.Filter("WEMPF", sap.ui.model.FilterOperator.NE, Dlvpnttokens[k].data().range.value1);
					// 		} else {
					// 			filterDlvpnt = new sap.ui.model.Filter("WEMPF", Dlvpnttokens[k].data().range.operation, Dlvpnttokens[k].data().range.value1,
					// 				Dlvpnttokens[k].data().range.value2);
					// 		}
					// 	}
					// 	filters.push(filterDlvpnt);
					// }

					if (WERKS !== "") {
						// var oFilterWERKS = new sap.ui.model.Filter("WERKS", sap.ui.model.FilterOperator.EQ, WERKS.toUpperCase());
						// filters.push(oFilterWERKS);

						var oFilters = new sap.ui.model.Filter({
							path: "WERKS",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: WERKS
						});
						filters.push(oFilters);

					}
						

					if (ROUTE !== "") {
						// var oFilterROUTE = new sap.ui.model.Filter("ROUTE", sap.ui.model.FilterOperator.EQ, ROUTE.toUpperCase());
						// filters.push(oFilterROUTE);
						// oFilters = [];
						var oFilters2 = new sap.ui.model.Filter({
							path: "ROUTE",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: ROUTE
						});
						filters.push(oFilters2);
					}
					//*************************ISSUE DATE RANGE**********************************************************************************//
					// 	var DP1 = this.getView().byId("DP1").getValue();
					//var DP2 = this.getView().byId("DP2").getValue();
					if (DP1 !== "" && DP2 !== "") {
						var oFilterDate = new sap.ui.model.Filter("BUDAT", sap.ui.model.FilterOperator.BT, DP1, DP2);
						filters.push(oFilterDate);
					}
					
					
					
					this.PostFilterDataToBackend(filters);

				}

			},

			rebindTable: function(oTemplate, sKeyboardMode) {
				var oTable = this.getView().byId("Homedlv");
				oTable.bindAggregation("items", {
					path: "/HANDOVERSet",
					template: oTemplate
						//key: "Werks"
				}).setKeyboardMode(sKeyboardMode);
			},

			// handleConfirmationMessageBoxPress: function(oEvent) {

			// 	jQuery.sap.require("sap.m.MessageBox");
			// 	sap.m.MessageBox.confirm(

			// 		"ARE YOU SURE WITH THE DETAILS ", {
			// 			icon: sap.m.MessageBox.Icon.INFORMATION,
			// 			title: "Confirmation Box",
			// 			actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
			// 			onClose: jQuery.proxy(function(oAction) {
			// 				if (oAction === "YES") {
			// 					this.getView().byId("filterBar1").setVisible(false);
			// 					this.getView().byId("otbFooter").setVisible(false);
			// 					this.getView().byId("filterBar").setVisible(true);
			// 					this.getView().byId("Homedlv").setVisible(true);
			// 					this.getView().byId("otbFooter1").setVisible(true);
			// 				}
			// 			}, this)
			// 		}
			// 	);

			// },

			// onPressnext: function(oevent) {
			// 	that.DRIVERNAME = this.getView().byId("DRIVERNAME").getValue();
			// 	that.DRIVERCONTACTNO = this.getView().byId("DRIVERCONTACTNO").getValue();
			// 	that.VEHICLENO = this.getView().byId("VEHICLENO").getValue();
			// 	that.VEHICLEDETAILS = this.getView().byId("VEHICLEDETAILS").getValue();
			// 	if (that.DRIVERNAME === "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO === "") {
			// 		this.showAlertMessage("Please Provide Inputs !");
			// 		return false;
			// 	} else if (that.DRIVERCONTACTNO === "") {
			// 		this.showAlertMessage("Please Enter Contact Number!");
			// 		return false;

			// 	} else if (that.DRIVERNAME === "") {
			// 		this.showAlertMessage("Please Enter Driver Name!");
			// 		return false;

			// 	} else if (that.VEHICLENO === "") {
			// 		this.showAlertMessage("Please Enter Vehicle No!");
			// 		return false;

			// 	} else {

			// 		this.getView().byId("filterBar1").setVisible(false);
			// 		this.getView().byId("otbFooter").setVisible(false);
			// 		this.getView().byId("filterBar").setVisible(true);
			// 		this.getView().byId("Homedlv").setVisible(true);
			// 		this.getView().byId("otbFooter1").setVisible(true);
			// 		//	this.nextlayout();
			// 		// this.handleConfirmationMessageBoxPress();
			// 	}
			// 	//return false;

			// },   "dont delete this code"
		// 	backToInboxPage:function(oEvent){
		// 	 window.history.go(-1);
		// },
			
			backToInboxPage: function(oevent){
					that.bck = "X";
					this.getView().byId("filterBa").setVisible(true);
					this.getView().byId("filterBar1").setVisible(false);
					this.getView().byId("Homedlv").setVisible(false);
					// this.getView().byId("filterBarB").setVisible(false);
					this.getView().byId("filterBarC").setVisible(true);
					
					this.getView().byId("otbFooter").setVisible(false);
					this.getView().byId("btnsubmit").setVisible(true);
			},
			onPressnext: function(oevent) {
		
				
				that.DRIVERNAME = this.getView().byId("DRIVERNAME").getValue();
				that.DRIVERCONTACTNO = this.getView().byId("DRIVERCONTACTNO").getValue();
				that.VEHICLENO = this.getView().byId("VEHICLENO").getValue();
				that.VEHICLEDETAILS = this.getView().byId("VEHICLEDETAILS1A").getValue();
				var lett = /^[0-9]+$/;
				if ((that.DRIVERNAME).match(lett)) {
					this.showAlertMessage("Name is Invalid");
					return false;
				} else if (that.DRIVERCONTACTNO.length < 10) {
					this.showAlertMessage("Please Provide Correct Phone No!");
					return false;
				} else if ((that.DRIVERNAME1 === "" && that.FLAG === "X") && (that.DRIVERNAME === "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO ===
						"")) {

					this.showAlertMessage("Please Provide  the Inputs!");
					return false;

				} else if (that.FLAG === "" && (that.DRIVERNAME !== "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME !== "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				} else if (that.FLAG === "" && (that.DRIVERNAME !== "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				}else if (that.FLAG === "X" && (that.DRIVERNAME !== "" && that.VEHICLENO === "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				}else if (that.FLAG === "X" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				}
				else if (that.FLAG === "X" && (that.DRIVERNAME !== "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO === "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				} 
				else if (that.FLAG === "" && (that.DRIVERNAME === "" && that.VEHICLENO !== "" && that.DRIVERCONTACTNO !== "")) {
					this.showAlertMessage("Please Provide  the Inputs");
					return false;
				} else if (that.DRIVERNAME === "" && that.FLAG === "") {
					this.showAlertMessage("Either Scan ID Or Provide Manual Entries");
					return false;
				} else {

					if (that.DRIVERNAME1 !== "") {
						that.DRIVERNAME = that.DRIVERNAME1;
						that.DRIVERCONTACTNO = that.DRIVERCONTACTNO1;
						that.VEHICLENO = that.VEHICLENO1;

					} else {

					}
					if (that.bck === "X"){   //ON PRESSING THE BACK BUTTON THEN AGAIN PRESS ON SUBMIT BUTTON
					this.getView().byId("filterBa").setVisible(false);
					this.getView().byId("filterBar1").setVisible(true);
					this.getView().byId("Homedlv").setVisible(true);
					// this.getView().byId("filterBarB").setVisible(false);
					this.getView().byId("filterBarC").setVisible(false);
					this.getView().byId("otbFooter").setVisible(true);
					this.getView().byId("Homedlv").setVisible(false);
					this.getView().byId("DP1").setDateValue(new Date());
					this.getView().byId("DP2").setDateValue(new Date());
						// this.onChangeRoute();
										//************************************************
							
				var multiInputRSNUM = this.getView().byId("multiInputRSNUM");
				var RSNUMtokens = multiInputRSNUM.getTokens();

				var multiInputMaterial = this.getView().byId("multiInputMaterial");
				var matnrtokens = multiInputMaterial.getTokens();
				var Plant = this.getView().byId("Plant").getValue();
				var Route = this.getView().byId("Route").getSelectedKey();
	
				var Delv = this.getView().byId("Delv").getSelectedKeys();

				var WERKS = this.getView().byId("Plant").getValue();
				var ROUTE = this.getView().byId("Route").getValue();
				var ROUTE = this.getView().byId("Route").setValue();
				
				var multiInputRSNUM = this.getView().byId("multiInputRSNUM");
				var multiInputDlvpnt = this.getView().byId("multiInputDlvpnt");
				var multiInputMaterial = this.getView().byId("multiInputMaterial");
				// var WERKS = this.getView().byId("Plant").getValue();
				// var ROUTE = this.getView().byId("Route").getValue();

				multiInputRSNUM.destroyTokens();
				Route = "";
				multiInputMaterial.destroyTokens();
				this.getView().byId("Plant").setValue();
				this.getView().byId("Delv").setSelectedKeys();
				// this.getView().byId("Route").setValue("");
					//**************************************************
					
					}
					if (that.bck !== "X"){
					this.getView().byId("filterBa").setVisible(false);
					this.getView().byId("filterBar1").setVisible(true);
					this.getView().byId("Homedlv").setVisible(true);
					// this.getView().byId("filterBarB").setVisible(false);
					this.getView().byId("filterBarC").setVisible(false);
					this.getView().byId("otbFooter").setVisible(true);
					
						// this.onChangeRoute();
					
					}
				

				}

				// this.getView().byId("otbFooter1").setVisible(true);

			},

			nextlayout: function(oevent) {

				this.getView().byId("filterBar1").setVisible(false);
				this.getView().byId("otbFooter").setVisible(false);
				this.getView().byId("filterBar").setVisible(true);
				this.getView().byId("Homedlv").setVisible(true);
				this.getView().byId("otbFooter1").setVisible(true);
			},

			// onPressClearFilter: function(evt) {
			// 	var multiInputRSNUM = this.getView().byId("multiInputRSNUM");
			// 	var multiInputDlvpnt = this.getView().byId("multiInputDlvpnt");
			// 	var multiInputMaterial = this.getView().byId("multiInputMaterial");
			// 	//var WERKS = this.getView().byId("Plant").getValue();
			// 	//var ROUTE = this.getView().byId("Route").getValue();

			// 	multiInputRSNUM.destroyTokens();
			// 	multiInputDlvpnt.destroyTokens();
			// 	multiInputMaterial.destroyTokens();
			// 	this.getView().byId("Plant").setValue("");
			// 	this.getView().byId("Route").setValue("");
			// 	this.getView().byId("DRIVERNAME").setValue("");
			// 	this.getView().byId("DRIVERCONTACTNO").setValue("");
			// 	this.getView().byId("VEHICLENO").setValue("");
			// 	this.getView().byId("VEHICLEDETAILS").setValue("");
			// 	var oClearFilter = this.getView().byId("btnClearFilters");
			// 	oClearFilter.setVisible(true);
			// },
			onCancel: function() {
				this.getView().byId("cancelButton").setVisible(false);
				this.getView().byId("saveButton").setVisible(false);
				// this.getView().byId("editButton").setVisible(true);
				var oTable = this.getView().byId("Homedlv");
				oTable.aProductCollection = jQuery.extend(true, [], sap.ui.getCore().getModel("oModelTest").getProperty("/HANDOVERSet"));
				var oTemplate = new sap.m.ColumnListItem({
					cells: [new sap.m.Text({
									text: "{ROW}"

								}),
								new sap.m.Text({
							text: "{COMB}"

						}),
						new sap.m.Text({
							text: "{COMB1}"

						}),
						new sap.m.Text({
							text: "{RSNUM}"
						}),
						new sap.m.Text({
							text: "{RSPOS}"
						}),
						new sap.m.Text({
							text: "{MBLNR}"
						}),
						new sap.m.Text({
							text: "{MJAHR}"
						}),
						new sap.m.Text({
							text: "{ZEILE}"
						}),
						new sap.m.Text({
							text: "{COUNTER}"
						}),
						new sap.m.Text({
							text: "{BUDAT}"
						}),

						new sap.m.Text({
							text: "{ROUTE}"
						}),
						new sap.m.Text({
							text: "{ENMNG}"
						}).addStyleClass("iqty"),
						new sap.m.Text({
							text: "{HANDOVR_QTY}"
						}).addStyleClass("hdqty"),
						new sap.m.Text({
							text: "{HANDOVR_QTY_COMPL}"
						}),
						new sap.m.Text({
							text: "{HANDOVR_QTY_REMAIN}"
						}),
						new sap.m.Text({
							text: "{WEMPF}"
						}),
						new sap.m.Text({
							text: "{MATNR}"
						}),
						new sap.m.Text({
							text: "{MAKTX}"
						}),
						new sap.m.Text({
							text: "{WERKS}"
						}),
						new sap.m.Text({
							text: "{LGORT}"
						}),

						new sap.m.Text({
							text: "{FINALSTATUS}"
						}),
						new sap.m.Text({
							text: "{DRIVERNAM}"
						}),
						new sap.m.Text({
							text: "{DRIVERPH}"
						}),
						new sap.m.Text({
							text: "{VECHNO}"
						}),
						new sap.m.Text({
							text: "{VEHICLEDET}"
						})

					]
				});

				//this.oModel.setProperty("/ET_BIS_DETAILSet", oTable.aProductCollection);
				this.rebindTable(oTemplate, "Navigation");

			},
			onEdit: function() {

				// this.getView().byId("Homedlv").setVisible(true);
				var oTable = this.getView().byId("Homedlv");

				oTable.aProductCollection = jQuery.extend(true, [], sap.ui.getCore().getModel("oModelTest").getProperty("/HANDOVERSet"));

				this.getView().byId("editButton").setVisible(false);
				this.getView().byId("saveButton").setVisible(true);
				this.getView().byId("cancelButton").setVisible(true);
				//this.getView().byId("addButton").setVisible(false);
				//	oTable.mode("MultiSelect");
				var oTemplate = new sap.m.ColumnListItem({
					cells: [new sap.m.Text({
									text: "{ROW}"

								}),
							new sap.m.Text({
							text: "{COMB}"

						}),
						new sap.m.Text({
							text: "{COMB1}"

						}),
						new sap.m.Text({
							text: "{RSNUM}"

						}),
						new sap.m.Text({
							text: "{RSPOS}"
						}),
						new sap.m.Text({
							text: "{MBLNR}"
						}),
						new sap.m.Text({
							text: "{MJAHR}"
						}),
						new sap.m.Text({
							text: "{ZEILE}"
						}),
						new sap.m.Text({
							text: "{COUNTER}"
						}),
						new sap.m.Text({
							text: "{BUDAT}"
						}),

						new sap.m.Text({
							text: "{ROUTE}"
						}),
						new sap.m.Text({
							text: "{ENMNG}"
						}).addStyleClass("iqty"),
						new sap.m.InputType.Number({
							value: "{HANDOVR_QTY}"
						}).addStyleClass("hdqty"),
						new sap.m.Text({
							text: "{HANDOVR_QTY_COMPL}"
						}),
						new sap.m.Text({
							text: "{HANDOVR_QTY_REMAIN}"
						}),
						new sap.m.Text({
							text: "{WEMPF}"
						}),
						new sap.m.Text({
							text: "{MATNR}"
						}),
						new sap.m.Text({
							text: "{MAKTX}"
						}),
						new sap.m.Text({
							text: "{WERKS}"
						}),
						new sap.m.Text({
							text: "{LGORT}"
						}),

						new sap.m.Text({
							text: "{FINALSTATUS}"

						}),
						new sap.m.Text({
							text: "{DRIVERNAM}"
						}),
						new sap.m.Text({
							text: "{DRIVERPH}"
						}),
						new sap.m.Text({
							text: "{VECHNO}"
						}),
						new sap.m.Text({
							text: "{VEHICLEDET}"
						})

					]
				});
				this.rebindTable(oTemplate, "Edit");

				// for (var i = 0; i < sap.ui.getCore().getModel("oModelTest").data.length; i++)
				// {

				// }
			},

			onSave: function(oEvent) {
				allErrorMsg = '';
				allErrorMsg1 = '';
				var c = 0;
				var h = 0;
				var oTable = this.getView().byId("Homedlv");
				var oSelectedItem = oTable.getSelectedItems();

				var oSelectedItemcount = oSelectedItem.length;

				this.getView().byId("saveButton").setVisible(true);
				// this.getView().byId("cancelButton").setVisible(false);
				// this.getView().byId("editButton").setVisible(true);
				var omodelUpdateBIS = new sap.ui.model.json.JSONModel();
				omodelUpdateBIS = oTable.getModel();

				var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPI_HOME_DELIVERY_SRV/");
				var aDeferredGroup = oModel.getDeferredGroups().concat("updateCreate");
				oModel.setDeferredGroups(aDeferredGroup);
				//	var ModelLength = omodelUpdateBIS.oData.HANDOVERSet.length;
				oModel.setUseBatch(true);
				var mParameters = {
					groupId: "updateCreate"
				};

				var NewData = {};
				if (oSelectedItemcount === 0) {
					this.showAlertMessage("No Reservation Number Selected for posting  ");
					return false;
				} else {
					
					var text1 = "Reservation Number Selected: " + oSelectedItemcount;
					this.handleConfirmationMessageBoxPress(text1);
					
				}
				
				
				// allErrorMsg = '';
				// allErrorMsg1 = '';
				// var c = 0;
				// var h = 0;
				// var oTable = this.getView().byId("Homedlv");
				// var oSelectedItem = oTable.getSelectedItems();

				// var oSelectedItemcount = oSelectedItem.length;

				// // var LastRecInd = 0;
				// for (var i = 0; i < oSelectedItemcount; i++) {
				// 	if (i === (oSelectedItemcount - 1)) {
				// 		// LastRecInd = 1;
				// 	}

				// 	//	var item1 = oSelectedItem[i];

				// 	NewData = {
				// 		"ROW": oSelectedItem[i].getBindingContext().getProperty("ROW"),
				// 		"COMB": oSelectedItem[i].getBindingContext().getProperty("COMB"),
				// 		"COMB1": oSelectedItem[i].getBindingContext().getProperty("COMB1"),
				// 		"RSNUM": oSelectedItem[i].getBindingContext().getProperty("RSNUM"),
				// 		"RSPOS": oSelectedItem[i].getBindingContext().getProperty("RSPOS"),
				// 		"MBLNR": oSelectedItem[i].getBindingContext().getProperty("MBLNR"),
				// 		"MJAHR": oSelectedItem[i].getBindingContext().getProperty("MJAHR"),
				// 		"ZEILE": oSelectedItem[i].getBindingContext().getProperty("ZEILE"),
				// 		"COUNTER": oSelectedItem[i].getBindingContext().getProperty("COUNTER"),
				// 		"BUDAT": oSelectedItem[i].getBindingContext().getProperty("BUDAT"),
				// 		"ENMNG": oSelectedItem[i].getBindingContext().getProperty("ENMNG"),
				// 		"ROUTE": oSelectedItem[i].getBindingContext().getProperty("ROUTE"),
				// 		"WEMPF": oSelectedItem[i].getBindingContext().getProperty("WEMPF"),
				// 		"MATNR": oSelectedItem[i].getBindingContext().getProperty("MATNR"),
				// 		"MAKTX": oSelectedItem[i].getBindingContext().getProperty("MAKTX"),
				// 		"WERKS": oSelectedItem[i].getBindingContext().getProperty("WERKS"),
				// 		"LGORT": oSelectedItem[i].getBindingContext().getProperty("LGORT"),
				// 		"HANDOVR_QTY": oSelectedItem[i].getBindingContext().getProperty("HANDOVR_QTY"),
				// 		"HANDOVR_QTY_COMPL": oSelectedItem[i].getBindingContext().getProperty("HANDOVR_QTY_COMPL"),
				// 		"HANDOVR_QTY_REMAIN": oSelectedItem[i].getBindingContext().getProperty("HANDOVR_QTY_REMAIN"),
				// 		"FINALSTATUS": oSelectedItem[i].getBindingContext().getProperty("FINALSTATUS"),
				// 		"DRIVERNAM": oSelectedItem[i].getBindingContext().getProperty("DRIVERNAM"),
				// 		"DRIVERPH": oSelectedItem[i].getBindingContext().getProperty("DRIVERPH"),
				// 		"VECHNO": oSelectedItem[i].getBindingContext().getProperty("VECHNO"),
				// 		"VEHICLEDET": oSelectedItem[i].getBindingContext().getProperty("VEHICLEDET"),
				// 		// "DRIVERNAME1": this.getView().byId("DRIVERNAME").getValue(),
				// 		// "DRIVERCONTACTNO1": this.getView().byId("DRIVERCONTACTNO").getValue(),
				// 		// "VEHICLENO1": this.getView().byId("VEHICLENO").getValue(),
				// 		"VEHICLEDETAILS1": that.VEHICLEDETAILS,
				// 		"DRIVERNAME1": that.DRIVERNAME,
				// 		"DRIVERCONTACTNO1": that.DRIVERCONTACTNO,
				// 		"VEHICLENO1": that.VEHICLENO
				// 			//	"LastRecInd": LastRecInd
				// 			//	"Insert": "N",
				// 			//	"Update": "Y"var DRIVERNAME = "";

				// 	};
				// 	// break;
				// 	// }
				// 	// 	if (parseFloat(NewData.ENMNG.trim()) < parseFloat(NewData.HANDOVR_QTY.trim())) {
				// 	// 		var c = i + 1;
				// 	// 		allErrorMsg += "(" + c + ") MRNo : " + NewData.RSNUM + " and MR ItemNo : " + NewData.RSPOS + ".  ";

				// 	// 		//this.showAlertMessage1("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
				// 	// 		//return false;
				// 	// 		//throw new Error("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
				// 	// 	} else {

				// 	// 		oModel.create("/HANDOVERSet", NewData, mParameters);
				// 	// 	}

				// 	// }
				// 	// var myInteger = (/^-?\d*(\.\d+)?$/);
				// 	// var letters = /[a-zA-Z/!/"/#/$/%/&/'/(/)/*/+/,/-/:/;/</=/>/?/@/\/]/g;
				// 	// var letters1 = /^[0-9]+$/;
				// 	// if ((NewData.HANDOVR_QTY.trim()).match(letters)) {
				// 	// 	this.showAlertMessage2("Please Input Valid Handover Quantity");
				// 	// 	return false;
				// 	// }else 	if ((NewData.HANDOVR_QTY.trim()).match(myInteger)) {
				// 	// 	this.showAlertMessage2("Please Input Valid Handover Quantity");
				// 	// 	return false;
				// 	// }
				// 	// else if (((NewData.HANDOVR_QTY.trim()).match(letters1)) && (NewData.HANDOVR_QTY.trim()).match(letters)) {
				// 	// 	this.showAlertMessage2("Please Input Valid Handover Quantity");
				// 	// 	return false;
				// 	// }
					
				// 	if((NewData.HANDOVR_QTY.trim())=== "" ){
				// 			this.showAlertMessage1("Please Input Valid Handover Quantity");
				// 			return false;
				// 	};
				// 	var str = (NewData.HANDOVR_QTY.trim());
				// 	var avi = (Math.sign(str));
				// 	if(avi <= 0 ){
				// 		this.showAlertMessage1("Please Input Valid Handover Quantity");
				// 			return false;	
				// 	}	else if (avi === "NaN") {
				// 		this.showAlertMessage1("Please Input Valid Handover Quantity");
				// 	}
				// 	if (parseFloat(NewData.ENMNG.trim()) < parseFloat(NewData.HANDOVR_QTY.trim())) {

				// 		c = c + 1;
				// 		allErrorMsg += "(" + c + ") MRNo : " + NewData.RSNUM + " and MR ItemNo : " + NewData.RSPOS + ".  ";

				// 		//this.showAlertMessage1("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
				// 		//return false;
				// 		//throw new Error("Issue Quantity Cannot Be Lesser Than Handover Quantity !");
				// 	} else if ((parseFloat(NewData.HANDOVR_QTY.trim()) > parseFloat(NewData.HANDOVR_QTY_REMAIN.trim())) && (parseFloat(NewData.HANDOVR_QTY_COMPL
				// 			.trim()) !== 0 && parseFloat(NewData.HANDOVR_QTY_REMAIN.trim()) !== 0)) {
				// 		h = h + 1;
				// 		allErrorMsg1 += "(" + h + ") MRNo : " + NewData.RSNUM + " and MR ItemNo : " + NewData.RSPOS + ".  ";
				// 	} else {

				// 		oModel.create("/HANDOVERSet", NewData, mParameters);
				// 	}

				// }

				// if (allErrorMsg !== '') {
				// 	allErrorMsg = Fixmsg + " " + allErrorMsg;
				// 	this.showAlertMessage1(allErrorMsg);
				// 	// this.getView().byId("editButton").setVisible(false);
				// 	this.getView().byId("saveButton").setVisible(true);
				// 	// this.getView().byId("cancelButton").setVisible(true);
				// 	return false;
				// }

				// if (allErrorMsg1 !== '') {
				// 	allErrorMsg1 = Fixmsg1 + " " + allErrorMsg1;
				// 	this.showAlertMessage1(allErrorMsg1);
				// 	// this.getView().byId("editButton").setVisible(false);
				// 	this.getView().byId("saveButton").setVisible(true);
				// 	// this.getView().byId("cancelButton").setVisible(true);
				// 	return false;
				// }

				// //	oModel.create("/HANDOVERSet", NewData, mParameters);
				// //}

				// //var that = this;

				// oModel.submitChanges({
				// 	success: jQuery.proxy(function(oSuccess, response) {
				// 		var value = [];
				// 		var strInfo = "";
				// 		// alert("msg");

				// 		this.showAlertMessage2("DATA UPDATED SUCCESSFULLY");
				// 	}, this),

				// 	//value = response.data.__batchResponses[0].__changeResponses[0]["body"];
				// 	// for (var j = 0; j < oSelectedItemcount; j++) {
				// 	// 	value[j] = jQuery.parseJSON(response.data.__batchResponses[0].__changeResponses[j].body)["d"]["MsgInd"];
				// 	// }
				// 	// sap.m.MessageToast.show("Updated!");
				// 	// 	for (var j = 0; j < oSelectedItemcount; j++) {
				// 	// 		value[j] = jQuery.parseJSON(response.data.__batchResponses[j].__changeResponses[j].data.MSGIND);
				// 	// 	if (value[j] === "S") {
				// 	// 		strInfo = strInfo + "\n Row " + j + "- Data Updated Succesfully";
				// 	// }
				// 	// 	}
				// 	//ERROR HANDLING OF THE EXCEPTION
				// 	// var obj = JSON.parse(response.data.__batchResponses[0].response.body);
				// 	// sap.m.MessageToast.show(obj.error.message["value"]);
				// 	//	that.DisplayMessage(" Workflow successfully created.", "success");
				// 	// 	var oModel1 = new sap.ui.model.json.JSONModel();
				// 	// 	oModel1.setData({
				// 	// 		HANDOVERSet: value

				// 	// 	});

				// 	// },
				// 	error: jQuery.proxy(function(oError) { //read error}
				// 		var err = oError;

				// 		//that.DisplayMessage("Could Not Create Workflow . Please try again later", "error");
				// 		this.showAlertMessage1("Invalid Data!");
				// 		setTimeout(function() {
				// 			//this.byId("Homedlv").hide();
				// 			this.onSearch();
				// 		}.bind(this), 2000);

				// 	}, this),
				// });

				// var oTemplate = new sap.m.ColumnListItem({
				// 	cells: [
				// 					new sap.m.Text({
				// 					text: "{ROW}"

				// 				}),
						
				// 			new sap.m.Text({
				// 			text: "{COMB}"

				// 		}),
				// 		new sap.m.Text({
				// 			text: "{COMB1}"

				// 		}),
				// 		new sap.m.Text({
				// 			text: "{RSNUM}"

				// 		}),
				// 		new sap.m.Text({
				// 			text: "{RSPOS}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{MBLNR}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{MJAHR}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{ZEILE}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{COUNTER}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{BUDAT}"
				// 		}),

				// 		new sap.m.Text({
				// 			text: "{ROUTE}"
				// 		}),

				// 		new sap.m.Text({
				// 			text: "{ENMNG}"
				// 		}).addStyleClass("iqty"),
				// 		new sap.m.Text({
				// 			text: "{HANDOVR_QTY}"
				// 		}).addStyleClass("hdqty"),
				// 		new sap.m.Text({
				// 			text: "{HANDOVR_QTY_COMPL}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{HANDOVR_QTY_REMAIN}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{WEMPF}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{MATNR}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{MAKTX}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{WERKS}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{LGORT}"
				// 		}),

				// 		new sap.m.Text({
				// 			text: "{FINALSTATUS}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{DRIVERNAM}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{DRIVERPH}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{VECHNO}"
				// 		}),
				// 		new sap.m.Text({
				// 			text: "{VEHICLEDET}"
				// 		})

				// 	]
				// });
				// this.rebindTable(oTemplate, "Navigation");

				// // this.showAlertMessage2("DATA UPDATED SUCCESSFULLY");

				// // setTimeout(function() {
				// // 				//this.byId("Homedlv").hide();
				// // 				this.onSearch();
				// // 			}.bind(this),4000);

				// //this.getView().byId("addButton").setVisible(true);
			}

		});
	});