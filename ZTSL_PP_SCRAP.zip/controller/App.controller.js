sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tatasteelztsl_pp_scrapaprov.controller.App", {

	});
});