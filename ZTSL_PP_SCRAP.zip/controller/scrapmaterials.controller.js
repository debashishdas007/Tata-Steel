sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageStrip",
	"sap/m/MessageToast",
	'sap/m/Button',
	"sap/m/MessageBox",
	'sap/m/Dialog',
	'sap/m/List',
	'sap/m/StandardListItem',
	'sap/ui/model/json/JSONModel'
], function(Controller, MessageStrip,MessageToast,MessageBox,JSONModel, Dialog, List) {
	"use strict";

	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPCO_SCRAP_APROV_SRV/");
	var oValueHelpDialog = null;
	var aTokens = [];
	var that = this;
	var advanceSearchFilters = [];
	var _plant = null;

	return Controller.extend("com.tatasteelztsl_pp_scrapaprov.controller.scrapmaterials", {

		onInit: function() {
			

		},
		

		/////************************************************************************************************
		
		
		// messageboxsetting:function(aMockMessages){
			
		// 	var that = this;

		// 	var	oLink = new sap.m.Link({
		// 		text: "Show more information",
		// 		href: "",
		// 		target: "_blank"
		// 	});

		// 	var oMessageTemplate = new sap.m.MessageItem({
		// 		type: '{type}',
		// 		title: '{title}',
		// 		description: '{description}',
		// 		subtitle: '{subtitle}',
		// 		counter: '{counter}',
		// 		markupDescription: '{markupDescription}',
		// 		link: oLink
		// 	});

			

		// 	var oModel = new sap.ui.model.json.JSONModel();

		// 	oModel.setData(aMockMessages);

		// 	this.oMessageView = new sap.m.MessageView({
		// 		showDetailsPageHeader: false,
		// 		itemSelect: function () {
		// 			oBackButton.setVisible(true);
		// 		},
		// 		items: {
		// 			path: "/",
		// 			template: oMessageTemplate
		// 		}
		// 	});

		// 	var oBackButton = new sap.m.Button({
		// 			icon: sap.ui.core.IconPool.getIconURI("nav-back"),
		// 			visible: false,
		// 			press: function () {
		// 				that.oMessageView.navigateBack();
		// 				this.setVisible(false);
		// 			}
		// 		});



		// 	this.oMessageView.setModel(oModel);

		// 	this.oDialog = new sap.m.Dialog({
		// 		resizable: true,
		// 		content: this.oMessageView,
		// 		state: 'Error',
		// 		beginButton: new sap.m.Button({
		// 			press: function () {
		// 				this.getParent().close();
		// 			},
		// 			text: "Close"
		// 		}),
		// 		customHeader: new sap.m.Bar({
		// 			contentMiddle: [
		// 				new sap.m.Text({ text: "Error"})
		// 			],
		// 			contentLeft: [oBackButton]
		// 		}),
		// 		contentHeight: "700px",
		// 		contentWidth: "900px",
		// 		verticalScrolling: false
		// 	});
		
		// },
		
		showAlertMessage: function(val) {
			sap.m.MessageBox.error(val, {
				title: "Information",
				onClose: null,
				styleClass: "",
				initialFocus: null,
				actions: sap.m.MessageBox.Action.OK,
				textDirection: sap.ui.core.TextDirection.Inherit
			});
		},
	
	
	
	
	
	//////*****************************************************************************************************
	
	
	
	
	
	
	
	
		showValueHelpPlant: function() {
			oValueHelpDialog = null;
			var multiInputPlant = this.getView().byId("multiInputPlant");
			//var that = this;
			if (multiInputPlant.getTokens().length <= 0) {
				that.plantTableValue = null;
			}
			oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				supportRanges: true,
				title: "Plant",
				key: "PlantNo",
				descriptionKey: "Name",
				tokenDisplayBehaviour: "PlantNo",
				ok: function(oControlEvent) {
					aTokens = oControlEvent.getParameter("tokens");
					var sTokens = "";
					for (var i = 0; i < aTokens.length; i++) {
						var oToken = aTokens[i];
						sTokens += oToken.getText() + " ";
					}

					multiInputPlant.setTokens(aTokens);
					if (!that.plantTableValue) {
						that.plantTableValue = oValueHelpDialog.getTable().getModel().getData();
					}
					oValueHelpDialog.close();
					oValueHelpDialog = null;

				},
				cancel: function(oControlEvent) {
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				afterClose: function() {
					this.destroy();
					oValueHelpDialog = null;
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
						label: "Plant",
						template: "PlantNo",
						iskey: "true"
					}, {
						label: "Description",
						template: "Name"
					}

				]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			if (!that.plantTableValue) {
				oValueHelpDialog.setBusy(true);
				// sap.ui.core.BusyIndicator.show();
				var oRowsModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YUI_FILTERBAR_SRV/");
				oRowsModel.read("/PlantSet", {
					//filters: filters,
					success: function(oData, response) {
						//	MessageToast.show(evt.getSource().getId() + " Pressed");
						var value = [];
						value = oData.results;
						var oModelPlant = new sap.ui.model.json.JSONModel();
						oModelPlant.setData(value);
						oValueHelpDialog.getTable().setModel(oModelPlant);
						if (oValueHelpDialog.getTable().bindRows) {
							oValueHelpDialog.getTable().bindRows("/");
						}
						if (multiInputPlant.getTokens().length > 0) {
							oValueHelpDialog.setTokens(multiInputPlant.getTokens());
						}

						if (oValueHelpDialog.getTable().bindItems) {
							var oTable = oValueHelpDialog.getTable();
							oTable.bindAggregation("items", "/", function(sId, oContext) {
								var aCols = oTable.getModel("columns").getData().cols;
								return new sap.m.ColumnListItem({
									cells: aCols.map(function(column) {
										var colname = column.template;
										return new sap.m.Label({
											text: "{" + colname + "}"
										});
									})
								});
							});
						}

						oValueHelpDialog.setBusy(false);
						oValueHelpDialog.update();

					},
					error: function(oError) { //read error}
						sap.m.MessageToast.show("Error Fetching data");
					},
					beforeOpen: function(oControlEvent) {
						sap.m.MessageToast.show("Selection changed!");
					}
				});
			} else {
				var oModelPlant2 = new sap.ui.model.json.JSONModel();
				oModelPlant2.setData(that.plantTableValue);
				oValueHelpDialog.getTable().setModel(oModelPlant2);
				if (oValueHelpDialog.getTable().bindRows) {
					oValueHelpDialog.getTable().bindRows("/");
				}
				if (multiInputPlant.getTokens()) {
					oValueHelpDialog.setTokens(multiInputPlant.getTokens());
				}
				oValueHelpDialog.open();
				oValueHelpDialog.update();
			}

			oValueHelpDialog.setRangeKeyFields([{
				label: "Plant",
				key: "PlantNo"
			}]);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				searchEnabled: true,
				showGoOnFB: true,
				showClearButton: true
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					tooltip: "Search for Plant",
					placeholder: "Search",
					search: function(event) {
						var data = event.mParameters.query;
						var oFilters = new sap.ui.model.Filter({
							and: false,
							filters: [
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("PlantNo", sap.ui.model.FilterOperator.Contains, data)
									]
								}),
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, data)
									]
								})
							]
						});
						// var oElement = sap.ui.getCore().byId("idValueHelpPlant").getTable();
						var oElement = oValueHelpDialog.getTable();
						if (sap.ui.Device.system.desktop === true) {
							oElement.getBinding("rows").filter([oFilters]);
						} else {
							oElement.getBinding("items").filter([oFilters]);
						}
						//oValueHelpDialog.getTable().bindRows("/").filter([oFilters]);

					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();

		},

		onSearch: function() {
			var postingDate = new Date(this.getView().byId("posting_date").getValue());
			var multiInputPlant = this.getView().byId("multiInputPlant").getTokens();
			var filters = new Array();

			if (postingDate !== '') {
				filters.push(new sap.ui.model.Filter("Budat", sap.ui.model.FilterOperator.EQ, postingDate));
			} 
			if (multiInputPlant.length > 0) {
				_plant = multiInputPlant[0].getKey();
				filters.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, multiInputPlant[0].getKey()));
			}

			var scrapTable = this.getView().byId("scrapTable");

			sap.ui.core.BusyIndicator.show();

			oModel.read('/ScrapSet', {
				filters: filters,
				success: function(oData, response) {
					var value = [];
					value = oData.results;
					var oModelMRPStat = new sap.ui.model.json.JSONModel();
					oModelMRPStat.setData({
						ScrapSet: value
					});

					var oTemplate = new sap.m.ColumnListItem({
						cells: [
							new sap.m.Text({
								text: "{DaccNo}"
							}),
							new sap.m.Text({
								text: "{Matnr}"
							}),
							new sap.m.Text({
								text: "{Menge}"
							}),
							new sap.m.Text({
								text: "{Meins}"
							}),
							new sap.m.Text({
								text: "{Lgort}"
							}),
							new sap.m.Text({
								text: "{Werks}"
							}),
							new sap.m.Text({
								text: "{Kostl}"
							}),
							new sap.m.Text({
								text: "{Ebeln}"
							}),
							//-------------------------------
							new sap.m.Text({
								text: "{Mandt}"
							}),
							new sap.m.Text({
								text: "{Mjahr}"
							}),
							new sap.m.Text({
								text: "{Charg}"
							}),
							new sap.m.Text({
								text: "{Budat}"
							}),
							new sap.m.Text({
								text: "{ConfirmS}"
							}),
							new sap.m.Text({
								text: "{Ernam}"
							}),
							new sap.m.Text({
								text: "{Erdat}"
							}),
							new sap.m.Text({
								text: "{ErrorMsg}"
							}),
							new sap.m.Text({
								text: "{TfrMatDoc}"
							}),
							new sap.m.Text({
								text: "{TfrMatDocYear}"
							})

							//-------------------------------

						]
					});

					scrapTable.setModel(oModelMRPStat);
					scrapTable.bindAggregation("items", {
						path: "/ScrapSet",
						template: oTemplate
					});
					sap.ui.core.BusyIndicator.hide();

				},
				error: function(oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show(oError.responseText.substring(oError.responseText.lastIndexOf('<message xml:lang="en">RFC Error: ') +
						34, oError.responseText.lastIndexOf("</message>")));
					// sap.m.MessageToast.show(JSON.parse(oError.responseText).error.message.value);
				}

			});

		},

		createTokens: function(oEvent, obj) {
			var oView = this.getView();
			var tokens = obj.getTokens();
			// var _newTokens = [];
			var _newTokens = new sap.m.Token({
				text: oEvent.getParameters().newValue,
				key: oEvent.getParameters().newValue
			});

			// For 1.54 or above version
			// tokens.push(_newTokens);
			// obj.setTokens(tokens);
			// obj.setValue("");

			// For 1.44 or less version
			obj.addToken(_newTokens);
			obj.setValue("");

		},
		changeToken: function(oEvent) {
			var oView = this.getView();
			var oMultiInput1 = oView.byId(oEvent.mParameters.id);
			this.createTokens(oEvent, oMultiInput1);
		},

		scrapApprove: function() {
			var array = [];
			var arrayApprove = [];

			var aItems = this.getView().byId('scrapTable').getItems();

			//oModel.setUseBatch(true);

			var data = [];
			var postingDate = new Date(this.getView().byId("posting_date").getValue());

			for (var i = 0; i < this.getView().byId("scrapTable").getSelectedItems().length; i++) {
				var data2 = {
					"Mandt": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[8].getText(),
					"DaccNo": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[0].getText(),
					"Mjahr": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[9].getText(),
					"Ebeln": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[7].getText(),
					"Matnr": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[1].getText(),
					"Werks": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[5].getText(),
					"Lgort": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[4].getText(),
					"Charg": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[10].getText(),
					"Kostl": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[6].getText(),
					"Menge": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[2].getText(),
					"Budat": new Date(this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[11].getText()),
					"ConfirmS": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[12].getText(),
					"Ernam": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[13].getText(),
					"Erdat": new Date(this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[14].getText()),
					"Meins": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[3].getText(),
					"ErrorMsg": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[15].getText(),
					"TfrMatDoc": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[16].getText(),
					"TfrMatDocYear": this.getView().byId("scrapTable").getSelectedItems()[i].getCells()[17].getText()
				};
				data.push(data2);
			}

			var approverArray = {
				"Werks": _plant,
				"Budat": postingDate,
				"ReturnMsg": "",
				"ScrapApproval": data
			};

			var that3 = this;
 
			oModel.create("/ApproveSet", approverArray, {
				success: function(response) {
					// console.log(response);
					// response.ReturnMsg =  + response.ReturnMsg + "'";
					response.ReturnMsg.toString();
					var responseMsg = JSON.parse(response.ReturnMsg.replace(",]", "]"));
					var messages = [];
					
					
	///***********************************************************************************************************************************************				
					var arraylength = null;
					arraylength = responseMsg.length;
					var Msgtype = [];
					// {
					// 	type: '',
					// 	title: '',
					// 	description: '',
					// 	counter: ''
					// };
					var msgarr = new Array();
					for (var j = 0; j < arraylength; j++) {
						if (responseMsg[j].hasOwnProperty("E")) {
							Msgtype[j] = {
								
								type: 'Error',
								title: responseMsg[j].E
							};
						
						}else if(responseMsg[j].hasOwnProperty("S")){
							Msgtype[j] = {
								
								type: 'Success',
								title: responseMsg[j].S
							};
						}
					}
						
					var aMockMessages = Msgtype;
				
					
					
				var oModelMRPmsg = new sap.ui.model.json.JSONModel();
					oModelMRPmsg.setData({
						msgval: Msgtype
					});
					that3.getView().setModel(oModelMRPmsg);
				that3.pressDialog = new sap.m.Dialog({
					title: 'Message',
					content: new sap.m.List({
						items: {
							path: "/msgval",
							template: new sap.m.StandardListItem({
								title: "{type}",
								description:"{title}"
							})
						}
					}),
					beginButton: new sap.m.Button({
						text: 'Close',
						press: function () {
							this.pressDialog.close();
							that3.onSearch();
						}.bind(that3)
					})
				});

				//to get access to the global model
				that3.getView().addDependent(that3.pressDialog);
			

			that3.pressDialog.open();
			
					//that3.messageboxsetting(aMockMessages);
				//	that3.onDialogPress(aMockMessages);
				//	that3.oMessageView.navigateBack();
				//	that3.oDialog.open();
						
						
						
					// if(arraylength !== null){
					// // MessageBox.alert("responseMsg[0]");
					// that3.showAlertMessage(
					// 		for (var j = 0; j < arraylength; j++) {
					// 	responseMsg[j].E);
					// 		}
							
					// }
//////****************************************************************************************************************					
					
					// var aMockMessages = {};

					// var oVC = sap.ui.getCore().byId("oVerticalContent");
					// var oMsgStrip = null;
					
					// for (var j = 0; j < responseMsg.length; j++) {
					// 	if (responseMsg[j].hasOwnProperty("E")) {
					// 		oMsgStrip = new MessageStrip("E" + j, {
					// 			text: responseMsg[j].E,
					// 			showCloseButton: true,
					// 			showIcon: true,
					// 			type: sap.ui.core.MessageType.Error
					// 		});
					// 	} else {
					// 		oMsgStrip = new MessageStrip("S" + j, {
					// 			text: responseMsg[j].E,
					// 			showCloseButton: true,
					// 			showIcon: true,
					// 			type: sap.ui.core.MessageType.Error
					// 		});
					// 	}
					// 	oVC.addContent(oMsgStrip);
					// }

					// ================================================================
					// var oMessageTemplate = new sap.m.MessageItem({
					// 	type: '{type}',
					// 	title: '{title}',
					// 	description: '{description}',
					// 	subtitle: '{subtitle}',
					// 	counter: '{counter}',
					// 	markupDescription: '{markupDescription}'
					// });
					// for (var j = 0; j < responseMsg.length; j++) {
					// 	if (responseMsg[j].hasOwnProperty("E")) {
					// 		aMockMessages = {
					// 			type: "Error",
					// 			description: responseMsg[j].E
					// 		};
					// 	} else {
					// 		aMockMessages = {
					// 			type: "Success",
					// 			description: responseMsg[j].S
					// 		};
					// 	}
					// 	messages.push(aMockMessages);
					// }
					// var msgModel = new sap.ui.model.json.JSONModel();
					// msgModel.setData(aMockMessages);
					// that3.oMessageView = new sap.m.MessageView({
					// 	showDetailsPageHeader: false,
					// 	items: {
					// 		path: "/",
					// 		template: oMessageTemplate
					// 	}
					// });
					// that3.oMessageView.setModel(oModel);
					// that3.oDialog = new sap.m.Dialog({
					// 	resizable: true,
					// 	content: that3.oMessageView,
					// 	state: "Error",
					// 	beginButton: new sap.m.Button({
					// 		press: function() {
					// 			this.getParent().close();
					// 		},
					// 		text: "Close"
					// 	}),
					// 	customHeader: new sap.m.Bar({
					// 		contentMiddle: [
					// 			new sap.m.Text({
					// 				text: "Error"
					// 			})
					// 		]
					// 	}),
					// 	contentHeight: "300px",
					// 	contentWidth: "500px",
					// 	verticalScrolling: false
					// });
					// that3.oMessageView.navigateBack();
					// that3.oDialog.open();
					// ================================================================
				},
				error: function(response) {
					//console.log(response);
					sap.m.MessageToast.show(JSON.parse(response.responseText).error.message.value);
				}
			
				
			});
			
				
			
		}

	});

});