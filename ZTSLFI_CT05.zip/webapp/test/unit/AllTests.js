sap.ui.define([
	"com/tatasteel/ZTSLFI_CT05/test/unit/controller/Card.controller"
], function () {
	"use strict";
});