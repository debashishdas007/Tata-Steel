/*global QUnit*/

sap.ui.define([
	"com/tatasteel/ZTSLFI_CT05/controller/Card.controller"
], function (oController) {
	"use strict";

	QUnit.module("Card Controller");

	QUnit.test("I should test the Card controller", function (assert) {
		var oAppController = new oController();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});