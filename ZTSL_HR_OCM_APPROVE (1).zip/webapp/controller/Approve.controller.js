sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/m/Label",
	"sap/m/Dialog",
	"sap/m/TextArea",
	"sap/m/Button"
], function (Controller, MessagePopover, MessagePopoverItem, Label, Dialog, TextArea, Button) {
	"use strict";
	var dialog = "";
	return Controller.extend("com.tatasteel.ZTSL_HR_OCM_APPROVE.controller.Approve", {
		onInit: function () {

		},
		onPress: function (oControlEvent) {
			//console.log(oControlEvent);
			//console.log(oControlEvent.getSource().getBindingContext("statusJobs").getObject());
			var filters = [];
			var dateFrom = this.getView().byId("dateFrom").getValue().trim();
			var dateTo = this.getView().byId("dateTo").getValue().trim();

			if (dateFrom !== "" && dateTo !== "") {
				var oFilters = new sap.ui.model.Filter("FromDate", sap.ui.model.FilterOperator.EQ, dateFrom);
				filters.push(oFilters);
				oFilters = new sap.ui.model.Filter("ToDate", sap.ui.model.FilterOperator.EQ, dateTo);
				filters.push(oFilters);
				this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("dateTo").setValueState(sap.ui.core.ValueState.None);
			} else {
				if (dateFrom === "") {
					this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.Error);
				}
				if (dateTo === "") {
					this.getView().byId("dateTo").setValueState(sap.ui.core.ValueState.Error);
				}
				return false;
			}

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YHRO_OCM_APP_SRV/");
			var oTable = this.getView().byId("approveTable");
			oTable.setBusy(true);
			var that = this;
			oModel.read("/Et_OcmFinalApprovalSet", {
				filters: filters,
				success: function (oData, response) {
					var value = [];
					value = oData.results;
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel1.setData({
						Et_OcmFinalApprovalSet: value
					});
					//column list item creation
					var oTemplate = new sap.m.ColumnListItem({
						cells: [new sap.m.ObjectIdentifier({
								text: "{OcmDesc}"
							}).addStyleClass("headerItemBold"),
							new sap.m.ObjectIdentifier({
								text: "{FinalAprvrPernr}"
							}).addStyleClass("headerItemBold"),
							new sap.m.ObjectIdentifier({
								text: "{OcmId}"
							}).addStyleClass("headerItemBold"),
							new sap.m.ObjectIdentifier({
								text: "{RequesterName}"
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: "{OcmType}"
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: ""
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: ""
							}).addStyleClass("txtColor"),
							new sap.m.ObjectStatus({
								text: "Open",
								//icon: "sap-icon://circle-task-2",
								active: true,
								press: function (oEvent) {
									that.goOnePageProfile(oEvent, "OnePageProfile");
								}
							}).addStyleClass("txtColor"),
							new sap.m.ObjectStatus({
								text: "Open",
								//icon: "sap-icon://circle-task-2",
								active: true,
								press: function (oEvent) {
									//that.onBackPressed(oEvent, "DelCompDetails");
								}
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: ""
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: ""
							}).addStyleClass("txtColor")
						]
					});

					oTable.setModel(oModel1);

					oTable.bindAggregation("items", {
						path: "/Et_OcmFinalApprovalSet",
						template: oTemplate
					});
					oTable.setBusy(false);
				},
				error: function (oError) { //read error}
					oTable.setBusy(false);
					var parser = new DOMParser();
					var xmlDoc = parser.parseFromString(oError.responseText, "text/xml");
					sap.m.MessageToast.show(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
				}
			});

		},
		goOnePageProfile: function (event, OnePageProfile) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("onePageProfile");
		},
		pOneForm: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Details");
		},
		onSubmitDialog: function () {
			dialog = new Dialog("remarksDialog", {
				title: "Remarks",
				type: "Message",
				content: [
					new Label({
						text: "Please Submit Your Remarks",
						labelFor: "submitDialogTextarea"
					}),
					new TextArea("submitDialogTextarea", {
						liveChange: function (oEvent) {
							var sText = oEvent.getParameter("value");
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: "100%",
						placeholder: "Add Remarks (required)"
					})
				],
				beginButton: new Button({
					text: "Submit",
					enabled: false,
					press: function () {
						dialog.close();
					}
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					//dialog.destroy();
				}
			});

			dialog.open();
		},

		onApprove: function (event) {
			var oTable = this.getView().byId("approveTable");
			//dialog.open();
			var remarksTextArea = dialog.getContent()[1].getValue();
			dialog.destroy();

			var selectedItems = oTable.getSelectedItems();
			var itemArray = [];
			for (var i = 0; i < selectedItems.length; i++) {
				var data = {
					"FinalAprvrPernr": selectedItems[i].getCells()[1].getText(),
					"FromDate": "",
					"ToDate": "",
					"ProcessingMode": "",
					"OcmId": selectedItems[i].getCells()[2].getText(),
					"OcmDesc": selectedItems[i].getCells()[0].getText(),
					"RaisedDate": "",
					"EffDate": (selectedItems[i].getCells()[4].getText().split(".")[2] + selectedItems[i].getCells()[4].getText().split(".")[1] +
						selectedItems[i].getCells()[4].getText().split(".")[0]).toString(),
					"NumPers": "",
					"OcmType": selectedItems[i].getCells()[5].getText(),
					"AdvDesc": "",
					"RequesterName": selectedItems[i].getCells()[3].getText(),
					"ActionTag": "",
					"Remarks": remarksTextArea,
					"Circular": ""
				};
				itemArray.push(data);
			}
			oTable.setBusy(true);
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YHRO_OCM_APP_SRV/");
			oModel.setUseBatch(true);

			for (var j = 0; j < itemArray.length; j++) {
				var oEntry = itemArray[j];
				oModel.update("/Et_OcmFinalApprovalSet('" + oEntry.OcmId + "')", oEntry, {
					method: "PUT",
					success: function (oData, response) {
						oTable.setBusy(false);
					},
					error: function (e) {
						oTable.setBusy(false);
					}
				});

			}

			oModel.submitChanges({
				success: function (oData, response) {
					//To do
					oTable.setBusy(false);
				},
				error: function (e) {
					oTable.setBusy(false);
					//To do
				}
			});

		},

		onReturn: function (event) {

		},

		getTableSelectedItems: function () {

		}

	});
});