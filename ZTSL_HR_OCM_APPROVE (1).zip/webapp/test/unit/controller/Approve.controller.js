/*global QUnit*/

sap.ui.define([
	"com/tatasteel/ZTSL_HR_OCM_APPROVE/controller/Approve.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Approve Controller");

	QUnit.test("I should test the Approve controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});