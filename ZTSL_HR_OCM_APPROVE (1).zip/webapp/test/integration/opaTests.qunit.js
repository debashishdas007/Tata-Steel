/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/tatasteel/ZTSL_HR_OCM_APPROVE/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});