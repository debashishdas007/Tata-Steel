/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/tatasteel/ZTSLFI_CT00/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});