sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"./InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, InitPageUtil) {
	"use strict";
	var entity = "";
	var globalViz = " ";
	var that2 = this;
	
	return Controller.extend("com.tatasteel.ZTSLFI_CT00.controller.Card", {
		
		onInit: function () {
			entity = "et_collection_display";
			//var viewModel = " ";
		},

		onBeforeRendering: function () {
			//sap.ui.core.BusyIndicator.show();
			//this.fetchEtCollectionDisplay();	
		},

		onAfterRendering: function () {
			sap.ui.core.BusyIndicator.show();
			globalViz = this.getView().byId("idVizFrame");
			//this.fetchEtCollectionDisplay();
			var that = this;
			jQuery.sap.delayedCall(5000, null, function () {
				//this.getView().byId("idVizFrame").rerender();
				that.fetchEtCollectionDisplay();
			});
		},

		fetchEtCollectionDisplay: function () {
			//  ============== This section is for *** ET_Collection_DisplaySet *** ====================

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_Collection_DisplaySet", {
				success: function (oData, response) {
					//var results = oData.results; 

					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						jsonModel: oData.results
					});
					that.et_collection_display(dataModel);
					sap.ui.core.BusyIndicator.hide();
					that.getView().byId("chartFixFlex1").setVisible(true);
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});

			//  ============== End of section for *** ET_Collection_DisplaySet *** ====================
		},

		et_collection_display: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [
						// {
						// 	name: "Small",
						// 	value: "/betterSmall.json"
						// }, {
						// 	name: "Medium",
						// 	value: "/betterMedium.json"
						// }, 
						{
							name: "Large",
							value: "/betterLarge.json"
						}
					]
				},
				series: {
					name: "Series",
					defaultSelected: 2,
					values: [
						// {
						// 	name: "1 Series",
						// 	value: ["Manthly_Proj"]
						// }, 
						{
							name: "2 Series",
							value: ["Manthly_Proj", "Daily_Proj", "Actuals"]
						}
					]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					// Small: [{
					// 	name: "Seasons",
					// 	value: "{Seasons}"
					// }],
					// Medium: [{
					// 	name: "Week",
					// 	value: "{Week}"
					// }],
					Large: [{
						name: "Mnth",
						value: "{Mnth}"
					}]
				},
				measures: [{
					name: "Manthly",
					value: "{Manthly_Proj}"
				}, {
					name: "Daily_Proj",
					value: "{Daily_Proj}",
				}, {
					name: "Actuals",
					value: "{Actuals}",
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Monthly Proj, Daily Proj and Actuals by Mnth"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel1", "chartFixFlex1", "idVizFrame");

		},
	});
});