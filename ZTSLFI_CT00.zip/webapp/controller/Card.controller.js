sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"./InitPage"
	//"ZTSLFI_C00/controller/InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, Export, ExportTypeCSV, InitPageUtil) {
	"use strict";
	var entity = "";
	var globalViz = " ";
	var globalData = " ";
	var that2 = this;
	var count = 0;
	var settingsModel = {
		dataset: {
			name: "Dataset",
			defaultSelected: 0,
			values: [{
				name: "Large",
				value: "/betterLarge.json"
			}]
		},
		series: {
			name: "Series",
			defaultSelected: 2,
			values: [{
				name: "2 Series",
				value: ["Manthly_Proj", "Daily_Proj", "Actuals"]
			}]
		},
		dataLabel: {
			name: "Value Label",
			defaultState: true
		},
		axisTitle: {
			name: "Axis Title",
			defaultState: false
		},
		dimensions: {
			// Small: [{
			// 	name: "Seasons",
			// 	value: "{Seasons}"
			// }],
			// Medium: [{
			// 	name: "Week",
			// 	value: "{Week}"
			// }],
			Large: [{
				name: "Mnth",
				value: "{Mnth}"
			}]
		},
		measures: [{
			name: "Manthly",
			value: "{Manthly_Proj}"
		}, {
			name: "Daily_Proj",
			value: "{Daily_Proj}",
		}, {
			name: "Actuals",
			value: "{Actuals}",
		}]
	};

	return Controller.extend("com.tatasteel.ZTSLFI_CT00.controller.Card", {

		onInit: function () {
			entity = "et_collection_display";
			//var viewModel = " ";
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_Collection_DisplaySet", {
				success: function (oData, response) {
					//var results = oData.results; 

					var dataModel = new sap.ui.model.json.JSONModel();
					globalData = oData.results;
					dataModel.setData({
						jsonModel: oData.results
					});
					
					globalData = dataModel;
					//that.et_collection_display(dataModel);
					//==============

					Format.numericFormatter(ChartFormatter.getInstance());
					var formatPattern = ChartFormatter.DefaultPattern;

					var oVizFrame = that.getView().byId("idVizFrame");
					oVizFrame.setVizProperties({
						plotArea: {
							dataLabel: {
								formatString: formatPattern.SHORTFLOAT_MFD2,
								visible: true
							}
						},
						valueAxis: {
							label: {
								formatString: formatPattern.SHORTFLOAT
							},
							title: {
								visible: false
							}
						},
						categoryAxis: {
							title: {
								visible: false
							}
						},
						title: {
							visible: true,
							text: "Monthly Projection, Daily Projection and Monthly Actuals by Month"
						}
					});

					oVizFrame.setModel(dataModel);

					var oPopOver = that.getView().byId("idPopOver");
					oPopOver.connect(oVizFrame.getVizUid());
					oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

					InitPageUtil.initPageSettings(that.getView(), that);
					//==============
					sap.ui.core.BusyIndicator.hide();
					that.getView().byId("chartFixFlex").setVisible(true);
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		onAfterRendering: function () {
			sap.ui.core.BusyIndicator.show();
			globalViz = this.getView().byId("idVizFrame");
			//this.fetchEtCollectionDisplay();
			var that = this;
			// jQuery.sap.delayedCall(5000, null, function () {
			// 	//this.getView().byId("idVizFrame").rerender();
			// 	that.fetchEtCollectionDisplay();
			// });
		},

		fetchEtCollectionDisplay: function () {
			//  ============== This section is for *** ET_Collection_DisplaySet *** ====================

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_Collection_DisplaySet", {
				success: function (oData, response) {
					//var results = oData.results;&nbsp;

					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						jsonModel: oData.results
					});
					//that.et_collection_display(dataModel);

					//===========
					Format.numericFormatter(ChartFormatter.getInstance());
					var formatPattern = ChartFormatter.DefaultPattern;
					// set explored app's demo model on this sample
					//var oModel = new JSONModel(this.settingsModel);
					//oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
					//this.getView().setModel(oModel);

					var oVizFrame = that.getView().byId("idVizFrame");
					oVizFrame.setVizProperties({
						plotArea: {
							dataLabel: {
								formatString: formatPattern.SHORTFLOAT_MFD2,
								visible: true
							}
						},
						valueAxis: {
							label: {
								formatString: formatPattern.SHORTFLOAT
							},
							title: {
								visible: false
							}
						},
						categoryAxis: {
							title: {
								visible: false
							}
						},
						title: {
							visible: true,
							text: "Monthly Proj, Daily Proj and Actuals by Mnth"
						}
					});

					oVizFrame.setModel(dataModel);

					var oPopOver = that.getView().byId("idPopOver");
					oPopOver.connect(oVizFrame.getVizUid());
					oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

					//InitPageUtil.initPageSettings(this.getView());
					InitPageUtil.initPageSettings(that.getView());

					// ==========
					sap.ui.core.BusyIndicator.hide();
					that.getView().byId("chartFixFlex").setVisible(true);
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});

			//  ============== End of section for *** ET_Collection_DisplaySet *** ====================
		},

		et_collection_display: function (dataModel) {

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(this.settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			//this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Monthly Projection, Daily Projection and Monthly Actuals by Month"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView());

		},

		excelDownload: function () {
			//alert('shifhsdf');
			//console.log(globalData);

			var aCols;
			aCols = this.createColumnConfig();
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				models: globalData,
				rows: {
					path: "/jsonModel"
				},
				// column definitions with column name and binding info for the content
				columns: aCols

			});
			oExport.saveFile("card00").catch(function (oError) {
				//Handle your error
				//console.log(oError);
			}).then(function () {
				oExport.destroy();
			});

		},

		createColumnConfig: function () {
			return [
				{
					name: "Monthly Actuals",
					template: {
						content: {
							path: "Actuals"
						}
					}
				}, {
					name: "Daily Projection",
					template: {
						content: {
							path: "Daily_Proj"
						}
					}
				}, {
					name: "Monthly Projection",
					template: {
						content: {
							path: "Manthly_Proj"
						}
					}
				}, {
					name: "Month",
					template: {
						content: {
							path: "Mnth"
						}
					}
				}
			];
		}

	});
});