sap.ui.define([
		'jquery.sap.global',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel',
		'sap/viz/ui5/data/FlattenedDataset',
		'sap/viz/ui5/format/ChartFormatter',
		'sap/viz/ui5/api/env/Format',
		'sap/m/MessageBox',
		"sap/m/MessageToast"
	],

	function(jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, MessageBox) {
		"use strict";
		var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMFACV_P2P_DASHBOARD_SRV/");
		oModel.attachRequestSent(function() {
			sap.ui.core.BusyIndicator.show();
		});
		oModel.attachRequestCompleted(function() {
			sap.ui.core.BusyIndicator.hide();
		});

		var oRouter;
		return Controller.extend("corp.tatasteel.sapP2P_VendorPayable_1.controller.VendorsPayable", {

			onInit: function() {
				oRouter = this.getRouter();
				var ownerId = sap.ui.core.Component.getOwnerIdFor(this.getView());
				var component = sap.ui.component(ownerId).getComponentData();

				var vCategory = encodeURIComponent(component.startupParameters["Field1"]);

				//vCategory = "DUE%20IN%207";
				if (vCategory === "undefined") {
					vCategory = "";
				}
				if (vCategory === "RETENTION") {
					vCategory = "RETENTION";
				}
				if (vCategory === "ADVANCE") {
					vCategory = "ADVANCE";
				}
				if (vCategory === "DUE%20IN%207") {
					vCategory = "DUE7";
				}
				
				if (vCategory === "DUE%20%3C%20TOD")
				{
					vCategory = "DUE_TODAY";
				}
				
				if (vCategory === "NOT%20DUE") {
					vCategory = "NOT_DUE";
				}
				
				if (vCategory === "OPEN_GR_I") {
					vCategory = "OPEN_GR_IR";
				}
				
				if (vCategory === "CREDITORS") {
					vCategory = "CREDITORS";
				}

				// Commented By Debashish 17.9.2018
				// vCategory = "DUE%20IN%207";
				// if (vCategory == "DUE%20%3C%20TOD")
				// {
				// 	vCategory = "DUE < TOD";
				// }
				// if (vCategory == "DUE%20IN%207")
				// {
				// 	// vCategory = "DUE IN 7";
				// 	vCategory = "DUE7";
				// }
				// if (vCategory == "NOT%20DUE")
				// {
				// 	vCategory = "NOT DUE";
				// }
				/*var vCompCode = encodeURIComponent(component.startupParameters["Rbukrs"]);
				var vFiscalYr = encodeURIComponent(component.startupParameters["Gjahr"]);
				var vBussArea = encodeURIComponent(component.startupParameters["Rbusa"]);
				var vBranch = encodeURIComponent(component.startupParameters["Zuonr"]);*/
				jQuery.sap.require("jquery.sap.storage");
				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				oStorage.put("StCategory", vCategory);

				//RETENTION, ADVANCE, DUE IN 7, DUE < TOD, NOT DUE, OPEN_GR_I, CREDITORS

				var t = this;
				var vizColumnChart = t.getView().byId("idcolumn");

				var filters = new Array();
				var filterCat = new sap.ui.model.Filter("FilterCond", sap.ui.model.FilterOperator.EQ, vCategory);
				filters.push(filterCat);

				/*if (vCompCode !== "" || vCompCode !== null || vCompCode !== undefined) {
					var filterCompCode = new sap.ui.model.Filter("Rbukrs", sap.ui.model.FilterOperator.EQ, vCompCode);
					filters.push(filterCompCode);
				}
				if (vFiscalYr !== "" || vFiscalYr !== null) {
					var filterFiscalYr = new sap.ui.model.Filter("Rbukrs", sap.ui.model.FilterOperator.EQ, vFiscalYr);
					filters.push(filterFiscalYr);
				}
				if (vBussArea !== "" || vBussArea !== null) {
					var filterBussArea = new sap.ui.model.Filter("Rbukrs", sap.ui.model.FilterOperator.EQ, vBussArea);
					filters.push(filterBussArea);
				}
				if (vBranch !== "" || vBranch !== null) {
					var filterBranch = new sap.ui.model.Filter("Rbukrs", sap.ui.model.FilterOperator.EQ, vBranch);
					filters.push(filterBranch);
				}*/

				var oDataset = new sap.viz.ui5.data.FlattenedDataset({
					dimensions: [{
						name: 'Business Area',
						value: "{Rbusa}"
					}],

					measures: [{
						name: 'Amount',
						value: '{Hsl}'
					}],

					data: {
						"path": "/ET_HSL_GSBERSet",
						"filters": filters
					}
				});
				vizColumnChart.setDataset(oDataset);
				vizColumnChart.setModel(oModel);
				vizColumnChart.setVizType('column');

				//4.Set Viz properties
				vizColumnChart.setVizProperties({
					plotArea: {
						colorPalette: d3.scale.category20().range()
					},
					title: {
						text: "Business Area vs Amount Graph" + "( " + vCategory + " )"
					},
					legend: {
						visible: false
					},
					yAxis: {
						title: {
							text: "Amount"
						}
					},
					xAxis: {
						title: {
							text: "Business Area"
						},
						axisLine: {
							visible: true
						}
					}
				});

				var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "valueAxis",
						'type': "Measure",
						'values': ['Amount']
					}),
					feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "categoryAxis",
						'type': "Dimension",
						'values': ['Business Area']
					});
				vizColumnChart.addFeed(feedValueAxis);
				vizColumnChart.addFeed(feedCategoryAxis);
			},
			//on click handler of Graph
			onClickHandler: function(oEvent) {
				oRouter.navTo("detail", {
					busArea: oEvent.getParameter("data")[0].data["Business Area"],
					categoryCode: jQuery.sap.storage.get("StCategory")

				});
			},
			getRouter: function() {
				return sap.ui.core.UIComponent.getRouterFor(this);
			},
			//on click of Detail button
			onPress: function(evt) {
				oRouter.navTo("detail", {
					categoryCode: jQuery.sap.storage.get("StCategory"),
					busArea: "0"
				});
			}
		});
	});