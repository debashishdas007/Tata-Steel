sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"corp/tatasteel/sapP2P_VendorPayable_1/model/formatter",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
], function(Controller, JSONModel, formatter, History) {
	"use strict";
	var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMFACV_P2P_DASHBOARD_SRV/", false);
		oModel.attachRequestSent(function() {
			sap.ui.core.BusyIndicator.show();
		});
		oModel.attachRequestCompleted(function() {
			sap.ui.core.BusyIndicator.hide();
		});
	return Controller.extend("corp.tatasteel.sapP2P_VendorPayable_1.controller.VendorPayable_DD2", {
		formatter: formatter,

		onInit: function() {
			this.getRouter().getRoute("detail").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var vBusArea = oEvent.getParameter("arguments").busArea;
			var CategoryCode = "";
			CategoryCode =  oEvent.getParameter("arguments").categoryCode;
			var vCardType = "CARD05";
			var t = this;
			var vGrid = t.getView().byId("idBusAreaDtls");

			var filters = new Array();
			if (vBusArea === "0") {
				vBusArea = "";
			} else {
				var filterBusinessArea = new sap.ui.model.Filter("Rbusa", sap.ui.model.FilterOperator.EQ, vBusArea);
				filters.push(filterBusinessArea);
			}

			var filterCard = new sap.ui.model.Filter("FilterCond", sap.ui.model.FilterOperator.EQ, vCardType); //vCardType
			filters.push(filterCard);
			
			var filterCategory = new sap.ui.model.Filter("CardType", sap.ui.model.FilterOperator.EQ, CategoryCode);
			filters.push(filterCategory);

			var oTemplate = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({
					text: "{Mandt}"
				}), new sap.m.Text({
					text: "{Rbukrs}"
				}), new sap.m.Text({
					text: "{Gjahr}"
				}), new sap.m.Text({
					text: "{Rbusa}"
				}), new sap.m.Text({
					text: "{Zuonr}"
				}), new sap.m.Text({
					text: "{CardType}"
				}), new sap.m.Text({
					text: "{FilterCond}"
				}), new sap.m.Text({
					text: "{LIFNR}"
				}), new sap.m.Text({
					text: "{NAME1}"
				}), new sap.m.Text({
					text: "{BLART}"
				}), new sap.m.Text({
					text: "{XBLNR}"
				}), new sap.m.Text({
					text: "{BLDAT}"
				}), new sap.m.Text({
					text: "{BELNR}"
				}), new sap.m.Text({
					text: "{BUDAT}"
				}), new sap.m.Text({
					text: "{HSL}"
				}), new sap.m.Text({
					text: "{SGTXT}"
				}), new sap.m.Text({
					text: "{BKTXT}"
				}), new sap.m.Text({
					text: "{AUGBL}"
				}), new sap.m.Text({
					text: "{AUGDT}"
				}), new sap.m.Text({
					text: "{KIDNO}"
				}), new sap.m.Text({
					text: "{GKONT}"
				})]
			});

			oModel.read("/ET_BussArea_DtlsSet", {
				filters: filters,
				success: function(oData, response) {
					//var oColumChartModel = new sap.ui.model.json.JSONModel();
					//oColumChartModel.setData(oData.results); //setting data to model
					var value = oData.results;
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel1.setData({
						ET_BussArea_DtlsSet: value
					});

					vGrid.setModel(oModel1);
					vGrid.bindAggregation("items", {
						path: "/ET_BussArea_DtlsSet",
						template: oTemplate
					});

					if (oData.results.length === 0) {
						sap.m.MessageToast.show("No Records Found");
					} else {
						sap.m.MessageToast.show(oData.results.length + " Record(s) fetched");
					}
				},
				error: function(oError) { //read error}
					sap.m.MessageToast.show("Error while fetching data");
				}
			});
		},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		/**
		 * Event handler  for navigating back.
		 * It checks if there is a history entry. If yes, history.go(-1) will happen.
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				// Otherwise we go backwards with a forward history
				var bReplace = true;
				this.getRouter().navTo("graphicalAnalysis", {}, bReplace);
			}
		}

	});

});