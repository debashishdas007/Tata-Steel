sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"corp/tatasteel/sapP2P_VendorPayable_1/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("corp.tatasteel.sapP2P_VendorPayable_1.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
		//	jQuery.sap.require("jquery.sap.storage");
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var router = this.getRouter();
			this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
			router.initialize();
			//this.getRouter().initialize();
			
		}
	});
});