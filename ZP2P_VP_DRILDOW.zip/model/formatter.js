sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		dateFormat:function(sDate){
			if(!sDate){
				return "";
			}
			else{
				return sDate;
			}
			return sDate.toGMTString('dd-MM-yyyy').toString().substring(5,16);
		},
		dateFormatList:function(sDate){
			if(!sDate){
				return "";
			}
			else{
				return sDate.toGMTString('dd-MM-yyyy').toString().substring(5,16);
			}
			return sDate.toGMTString('dd-MM-yyyy').toString().substring(5,16);
		},
		/**
		 * Returns a configuration object for the {@link sap.ushell.ui.footerbar.AddBookMarkButton} "appData" property
		 * @public
		 * @param {string} sTitle the title for the "save as tile" dialog
		 * @returns {object} the configuration object
		 */
		shareTileData: function(sTitle) {
			return {
				title: sTitle
			};
		},
		truncPersonalNo: function(sPerNo) {
		  if(sPerNo.length>0){
				var truncPNo=sPerNo.substring(2,sPerNo.length);
				return truncPNo;
			}else{
				return "";
			}
			return sPerNo;
		},
		truncSrlNo: function(sSrlNo) {
			var vNewSrlNo = sSrlNo;
			var vCheckDigit  = vNewSrlNo.substring(0,1);
			
			while(vCheckDigit === "0")
			{ 
				vNewSrlNo = vNewSrlNo.substring(1,vNewSrlNo.length);
				vCheckDigit = vNewSrlNo.substring(0,1);
			}
		 
			return vNewSrlNo;
		}

	};

});