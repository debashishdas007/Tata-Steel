
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/m/MessageToast",
	"sap/m/BusyDialog"
], 	
function(Controller, Button, BusyDialog, Text, TextArea, MessageToast) {
	"use strict";
	

	
	return Controller.extend("com.sap.tatasteel.z_CreateDOWrtSO.controller.OrderHeader", {
		_that: null,


		onInit: function() {
			// ****************Note:*************************
			// Dropdowns of this screen have been binded through Component.js
			
		},
		onPressSubmit: function() {
			
		
			var that = this;
			var view = this.getView();

			// var getDialog = sap.ui.getCore().byId("GlobalBusyDialog");
			// getDialog.open();

			// var oPage = this.getView().byId("pageId");
			// oPage.setBusy(true);

			var sText = view.byId('orderId').getValue();
		
			var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
			oRouter.navTo("orderdetails", {
				orderid: sText
			});
		

		
		
		}
	});
});