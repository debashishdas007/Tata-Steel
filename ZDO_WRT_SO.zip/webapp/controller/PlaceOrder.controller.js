sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"jquery.sap.history"
], function(Controller, History, MessageToast) {
	"use strict";
	var itemModel;
	return Controller.extend("com.sap.tatasteel.z_CreateDOWrtSO.controller.PlaceOrder", {
		
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.PlaceOrder
		 */
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("placeorder").attachPatternMatched(this._onObjectMatched, this);

			oRouter.attachRouteMatched(function(e) {
				var oArgs;
				var that = this;
				oArgs = e.getParameter("arguments");
				var _orderID = oArgs.orderid; // Retrieving Order ID from Router

				jQuery.sap.require("jquery.sap.storage");
				var editedModel1 = jQuery.sap.storage.get("myLocalData");
				itemModel = new sap.ui.model.json.JSONModel();
				itemModel.setData({
					OrderDetails: editedModel1

				});
				this.getView().setModel(itemModel);
				this.getView().bindElement("/OrderDetails");

				var itemDetModel = itemModel.getData().OrderDetails.OrderItemSet.results;
				var itemDetJModel = new sap.ui.model.json.JSONModel();
				itemDetJModel.setData({
					ItemDetails: itemDetModel
				});
				this.getView().byId("items").setModel(itemDetJModel);

			}, this);
		},
		_onObjectMatched: function(oEvent) {
			this.getView().bindElement({
				path: "/" + oEvent.getParameter("arguments").invoicePath,
				model: "invoice"
			});
		},
		onNavBack: function() {
			// var oHistory = History.getInstance();
			// var sPreviousHash = oHistory.getPreviousHash();

			// if (sPreviousHash !== undefined) {
			// 	window.history.go(-1);
			// } else {
			// 	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// 	oRouter.navTo("orderdetails", true);
			// }
			// jQuery.sap.require("jquery.sap.history");
			window.history.go(-1);
		},
		booleanFormatter: function(bValue) {
			return (bValue ? "YES" : "NO");
		},
		_showConfirmationDialogForPlaceOrder: function(context) {
			var dialog = new sap.m.Dialog({
				title: "Confirm",
				type: "Message",
				content: new sap.m.Text({
					text: "Are you sure you want to Place this order?"
				}),
				beginButton: new sap.m.Button({
					text: "Submit",
					press: function() {

						context.onPlaceOrderConfirmation(context);
						dialog.close();
						// sap.ui.core.BusyIndicator.show();
						// MessageToast.show("Processing Order...");
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},
		onPlaceOrder: function() {
			this._showConfirmationDialogForPlaceOrder(this);
		},
		onPlaceOrderConfirmation: function(context) {
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMSDOD_DELIVERYORDER_CREATE_SRV/", true);
			var jModel = itemModel.getData().OrderDetails;
			jModel.SalesOrderSimulation = false;

			var that = context;
			oModel.create("/SalesOrders", jModel, {
				success: jQuery.proxy(function(mResponse) {
					// Code for success
					// sap.ui.core.BusyIndicator.hide();
					// On Success

					if (mResponse === null) {
						// On Error
						that._showStatusDialog(that, "Error", "Message",
							"Error", "Error while processing the order details");
					} else {

						var orderID = mResponse.SalesOrderNumber.toString();

						if (orderID === "") {
							context._showStatusDialog(that, "Error", "Message",
								"Error", "");
						} else {
							context._showStatusDialog(that, "Success", "Message",
								"Success", "Delivery Order successfully created with ID: " + orderID);
						}

					}
				}),
				error: jQuery.proxy(function(r) {
					// sap.ca.ui.message.showMessageToast("error");
					var errorBody = r.response.body;
					var errorMessage = JSON.parse(errorBody).error.message.value;

					// On Error
					that._showStatusDialog(that, "Error", "Message",
						"Error", "Error while processing the order details: " + errorMessage);
				})
			});
		},

		_showStatusDialog: function(context, strTitle, strType, strState, strText) {
			var dialog = new sap.m.Dialog({
				title: strTitle,
				type: strType,
				state: strState,
				content: new sap.m.Text({
					text: strText
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function() {

						dialog.close();

						if (strTitle === "Error") {

						} else {

							// Navigating to the Home page of the application
							var oRouter = sap.ui.core.UIComponent.getRouterFor(context);
							oRouter.navTo("header");
						}
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.PlaceOrder
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.PlaceOrder
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.PlaceOrder
		 */
		//	onExit: function() {
		//
		//	}

	});

});