sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/Dialog",
	"sap/m/BusyDialog"
	// ,
	// "com.sap.tatasteel.z_CreateDOWrtSO.util.Validator"
], function(Controller, History, Dialog,BusyDialog) {
	"use strict";
	var _orderID, response, _oBusyDialog, finalResponse;

	return Controller.extend("com.sap.tatasteel.z_CreateDOWrtSO.controller.OderDetails", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.OderDetails
		 */
		 
		
	
		onInit: function() {

	
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("orderdetails").attachPatternMatched(this._onObjectMatched, this);
			// this._oBusyDialog.open();
			oRouter.attachRouteMatched(function(e) {
				var oArgs;
				var that = this;
				
				// that._oBusyDialog = new sap.m.BusyDialog();
				// that._oBusyDialog.close();

				oArgs = e.getParameter("arguments");
				_orderID = oArgs.orderid;
				
				
				
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMSDOD_DELIVERYORDER_CREATE_SRV/", true);
				oModel.read(
					// Commented by Shreya on 26/02/2018

					"SalesOrders(SalesOrderNumber='" + _orderID + "')?$expand=OrderItemSet",
					null, null, false,
					function(d) {

						response = d;
						if (response === null) {

						} else {

							var itemModel = new sap.ui.model.json.JSONModel();
							var orderModel = new sap.ui.model.json.JSONModel();

							itemModel.setData({
								itemDetails: response.OrderItemSet.results
							});

							orderModel.setData({
								orderDetails: response
							});

							var orderDetails = orderModel.getProperty("/orderDetails");
							orderDetails.SalesOrderSimulation = true;

							orderModel.setData({
								orderDetails: response
							});

							// Added by Shreya on 26/02/2018
							// Invoking the create method on SalesOrders entity for updation of records
							oModel.create("/SalesOrders", orderModel.getData().orderDetails, {
								success: jQuery.proxy(function(mResponse) {
									// Code for success
									// sap.ui.core.BusyIndicator.hide();
									// On Success
									// that._oBusyDialog.close();
									if (mResponse === null) {
										finalResponse = mResponse;

									} else {
										finalResponse = mResponse;

										var resultModel = new sap.ui.model.json.JSONModel();
										resultModel.setData({
											itemDetails: finalResponse.OrderItemSet.results
										});
										that.getView().byId("itemDetails").setModel(resultModel);
									}
								}),
								error: jQuery.proxy(function(r) {
									// sap.ca.ui.message.showMessageToast("error");
									var d = r;
									that._oBusyDialog.close();
									that.onMessageErrorDialog("Error", "error in fetching the details");
								})
							});
								
							

							// 
							// that.getView().byId("itemDetails").setModel(itemModel);

							var customerId = orderModel.getData().orderDetails.CustomerID;
							var _salesOrg = orderModel.getData().orderDetails.SalesOrganization;
							var _distChannel = orderModel.getData().orderDetails.DistributionChannel;
							var _division = orderModel.getData().orderDetails.Division;

							// Populating Ship to Party ComboBox

							oModel.read(
								"Customers(CustomerID='" + customerId + "',SalesOrganization='" + _salesOrg + "',DistributionChannel='" + _distChannel +
								"',Division='" + _division + "')?$expand=PartnerAddressSet",
								null, null, false,
								function(d) {
									if (d === null) {

									} else {
										var stpModel = new sap.ui.model.json.JSONModel();
										stpModel.setData({
											ShipToPartyModel: d.PartnerAddressSet.results
										});
										that.getView().byId("cmbSTP").setModel(stpModel);

									}

								},
								function fnError(e) {
									// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
									var error = e;
									// MessageToast.show("Defect names fetched");
								});
								
sap.ui.core.BusyIndicator.hide();
							// Populating Bill to Party ComboBox
							oModel.read(
								// "BillToPartySet/?$filter=(KUNN2 eq '0000100002' and SalesOrganization eq '9000' and Division eq '10' and DistributionChannel eq '10')",
								"BillToPartySet/?$filter=(KUNN2 eq '" + customerId + "' and SalesOrganization eq '" + _salesOrg + "' and Division eq '" +
								_division + "' and DistributionChannel eq '" + _distChannel + "')",
								null, null, false,
								function(d) {
									if (d === null) {

									} else {
										var btpModel = new sap.ui.model.json.JSONModel();
										btpModel.setData({
											BillToPartyModel: d.results
										});
										that.getView().byId("cmbBoxBTP").setModel(btpModel);
									}

								},
								function fnError(e) {
									// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
									var error = e;
									// MessageToast.show("Defect names fetched");
								});
								new sap.m.BusyDialog().close();

						}
						// MessageToast.show("Defect names fetched");
					},
					function fnError(e) {
						// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
						var error = e;
						// MessageToast.show("Defect names fetched");
					});

			}, this);
			// ,

			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.OderDetails
			 */
			//	onBeforeRendering: function() {
			//
			//	},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.OderDetails
			 */
			//	onAfterRendering: function() {
			//
			//	},

			/**
			 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
			 * @memberOf com.sap.tatasteel.z_CreateDOWrtSO.view.OderDetails
			 */
			//	onExit: function() {
			//
			//	}


		},

		onMessageErrorDialog: function(title, message) {
			var dialog = new Dialog({
				title: title,
				type: 'Message',
				state: 'Error',
				content: new Text({
					text: message
				}),
				beginButton: new Button({
					text: 'OK',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		_onObjectMatched: function(oEvent) {
			this.getView().bindElement({
				path: "/" + oEvent.getParameter("arguments").invoicePath,
				model: "invoice"
			});
		},
		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("overview", true);
			}
		},
		onReviewSubmit: function() {
			//Get Storage object to use
			var view = this.getView();
			var editedModel = new sap.ui.model.json.JSONModel();
			editedModel.setData(finalResponse);
			var itemsModel = new sap.ui.model.json.JSONModel();
			itemsModel = view.byId("itemDetails").getModel();

			var cmbBoxFwdAgent = view.byId("cmbBoxFwdAgent");
			var selFwdAgent = cmbBoxFwdAgent.getSelectedKey();

			var cmbBoxMrktAgent = view.byId("cmbBoxMrktAgent");
			var selMrktAgent = cmbBoxMrktAgent.getSelectedKey();

			var cmbBoxInspAgent = view.byId("cmbBoxInspAgent");
			var selInspAgent = cmbBoxInspAgent.getSelectedKey();

			var cmbBoxTestingAgent = view.byId("cmbBoxTestingAgent");
			var selTestingAgent = cmbBoxTestingAgent.getSelectedKey();

			var cmbSTP = view.byId("cmbSTP");
			var selSTP = cmbSTP.getSelectedKey();

			var cmbBoxBTP = view.byId("cmbBoxBTP");
			var selBTP = cmbBoxBTP.getSelectedKey();

			// Setting the edited data 
			editedModel.setProperty("OrderItemSet", itemsModel.getData());

			// Added by Shreya on 5th March 2018
			editedModel.getData().ForwardingAgent = selFwdAgent;
			editedModel.getData().MarketingAgent = selMrktAgent;
			editedModel.getData().Testingagent = selTestingAgent;
			editedModel.getData().Inspectionagent = selInspAgent;
			editedModel.getData().ShipToPartnerID = selSTP;
			editedModel.getData().BillToParty = selBTP;

			// var strModel = JSON.stringify(editedModel.getData());

			sap.ui.getCore().setModel(editedModel, "editedModel");

			jQuery.sap.require("jquery.sap.storage");
			var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			oStorage.put("myLocalData", editedModel.getData());

			// var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			// //Check if there is data into the Storage

			// oStorage.get("myLocalData");
			// oStorage.put("myLocalData", editedModel.getData());

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("placeorder", {
				orderid: _orderID
			});
		},
		removeItem: function(event) {
			var button = event.getSource();
			var listItem = button.getParent();
			var path = listItem.getBindingContext().getPath();

			var itemIndex = path.substr(path.lastIndexOf("/") + 1);

			var datePickerCellPosition = 3;
			var datePicker = listItem.getCells()[datePickerCellPosition];
			this.validator.unregisterInvalidControl(datePicker.getId());

			//update the model
			com.sap.tatasteel.z_CreateDOWrtSO.util.ModelUtils.deleteCartItemAtIndex(itemIndex);

		},

		updateItem: function(e) { // Method added by Shreya
			// if (!this._oPopover) {

			// 	this._oPopover = sap.ui.xmlfragment("com.sap.tatasteel.z_createdo.view.UpdateItem", this);
			// 	this.getView().addDependent(this._oPopover);
			// }

			// this._oPopover.openBy(e.getSource());
			var that = this;
			that._readConfigurationDetails(e);
			that._getItemDialog().open();

		},
		onCloseDialog: function(e) {
			var that = this;
			that._getItemDialog().close();
		},
		_readConfigurationDetails: function(e) {
			var that = this;

			// var b = e.getSource();
			// var l = b.getParent();
			// var p = l.getBindingContext("soc_cart").getPath();
			// var i = p.substr(p.lastIndexOf("/") + 1);
			var b = e.getSource();
			var l = b.getParent();
			var bindingContext = l.getBindingContext("soc_cart");
			var path = bindingContext.getPath();
			var i = path.substr(path.lastIndexOf("/") + 1);
			var orderItemNumber = bindingContext.getModel().getProperty("/oShoppingCartItems")[i].ItemNumber;

			// Object of oDtaModel
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMSDOD_DELIVERYORDER_CREATE_SRV/", true);

			// oModel.read("ConfigurationSet/?$filter=((Vbeln eq '0070567441') and (Posnr eq '000001') and (Flag eq 'FETCH'))",
			oModel.read("ConfigurationSet/?$filter=((Vbeln eq '" + _orderID + "') and (Posnr eq '" + orderItemNumber +
				"') and (Flag eq 'FETCH'))",
				null, // Context
				null, // URL parametrs
				true, // Async
				// filters, // Filters
				function(r) {
					// On Success
					var jsonModel = new sap.ui.model.json.JSONModel();
					jsonModel.setData(r.results[0]);
					that.getView().setModel(jsonModel, "ConfigDetails");
				},
				function(r) {
					// On Error
					sap.ca.ui.message.showMessageToast("empty");
				});
		},

		_getItemDialog: function() {

			// helper function is instantiating the fragment by 
			// calling the sap.ui.xmlfragment method with the path to the fragment definition 
			//as an argument. The function returns the instantiated controls for further use in the app

			// create dialog lazily
			if (!this._oDialog) {
				// create dialog via fragment factory
				// we pass PlansOverviewPieChartController as parameter so the fragment can use it
				// i.e. this controller has handler functions for the fragment
				this._oDialog = sap.ui.xmlfragment("com.sap.tatasteel.z_CreateDOWrtSO.view.UpdateItem", this);
				// connect dialog to view (models, lifecycle)
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		onSubmitDialog: function(e) {
			var that = sap.ui.getCore();
			var bindedModel = this.getView().getModel("ConfigDetails");

			var jsonData = bindedModel.getData();
			// Send OData Create request

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMSDOD_DELIVERYORDER_CREATE_SRV/", true);

			oModel.create("/ConfigurationSet", jsonData, {
				success: jQuery.proxy(function(mResponse) {
					// Code for success
					// sap.ui.core.BusyIndicator.hide();
					// On Success

					if (mResponse === null) {
						sap.ca.ui.message.showMessageToast("empty");

					} else {
						sap.ca.ui.message.showMessageToast("success");

					}
				}),
				error: jQuery.proxy(function(r) {
					sap.ca.ui.message.showMessageToast("error");

				})
			});

			this._getItemDialog().close();
		},
		onSelectDateChange: function(oEvent) {
			var oText = this.byId("DP2");
			var oDP = oEvent.oSource;
			var selEvent = oEvent.getSource();
			var sValue = oEvent.getParameter("newValue");
			var bInvalid = oEvent.getParameter("invalidValue");
		
			//var sDate = new Date(sValue);
			var sDate = selEvent.dateObj;
			this._iEvent++;
			//oText.setText("Change - Event " + this._iEvent + ": DatePicker " + oDP.getId() + ":" + sValue);
			var cmboboxFrmt = this.getView().byId("cmbBoxFrmt");

			if (oDP.oParent.mAggregations.cells[3].getSelectedKey() == "Wk") {
				var sYr = sDate.getFullYear();
				var WkNO = Math.ceil(((new Date(sDate.getFullYear(), sDate.getMonth(), sDate.getDate()) - new Date(sDate.getFullYear(), 0, 1)) /
					86400000 + 1 + new Date(sDate.getFullYear(), 0, 1).getDay()) / 7);
				oDP.setValue(WkNO + "/" + sYr);

				var selWkNo = WkNO;
				if (WkNO < 10) {
					selWkNo = "0" + WkNO;
				}

				var selWk = sYr + "" + selWkNo;
				var selWkDisplay = selWkNo + "/" + sYr;

				// selEvent.getModel().setProperty("RDD", selWk, selEvent.getBindingContext("soc_cart"));
				// selEvent.getModel().setProperty("DateDisplay", selWkDisplay, selEvent.getBindingContext("soc_cart"));
				//selEvent.getModel().setProperty("SOC_CART_RDD", selWk, selEvent.getBindingContext());
				//selEvent.getModel().setProperty("DateDisplay", selWkDisplay, selEvent.getBindingContext());
				 this.getView().byId("cmbBoxFrmt").setSelectedKey("Wk");
			} else {
				var D = oEvent.getParameter("newYyyymmdd");
				var fullYr = sDate.getFullYear();
				var selMonth = sDate.getMonth() + 1;
				var selDate = sDate.getDate();

				if (selMonth < 10) {
					selMonth = "0" + selMonth;
				}

				if (selDate < 10) {
					selDate = "0" + selDate;
				}

				var selDateVal = fullYr + "" + selMonth + "" + selDate;
				var selDateDisplay = selDate + "." + selMonth + "." + fullYr;
				oDP.setValue(selDateDisplay);
				//sValue = "20140320";
				// selEvent.getModel().setProperty("RDD", selDateDisplay, selEvent.getBindingContext("soc_cart"));
				// selEvent.getModel().setProperty("DateDisplay", selDateDisplay, selEvent.getBindingContext("soc_cart"));
		
				//selEvent.getModel().setProperty("SOC_CART_RDD", selDateDisplay, selEvent.getBindingContext());
				//selEvent.getModel().setProperty("DateDisplay", selDateDisplay, selEvent.getBindingContext());
				 this.getView().byId("cmbBoxFrmt").setSelectedKey("Dt");
			}

			if (bInvalid) {
				oDP.setValueState(sap.ui.core.ValueState.Error);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.None);
			}
		}

	});
});