/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("com.sap.tatasteel.z_CreateDOWrtSO.util.ModelUtils");
jQuery.sap.require("com.sap.tatasteel.z_CreateDOWrtSO.util.Formatter");
com.sap.tatasteel.z_CreateDOWrtSO.util.ModelUtils = {
	setUniformRddInCartModel: function() {
		var c = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("soc_cart");
		var n = c.getData().singleRdd;
		var a = c.getData().oShoppingCartItems;
		var b = parseInt(n.slice(4, 6), 10) - 1;
		var i;
		for (i = 0; i < a.length; i++) {
			a[i].RDD = n;
			a[i].formatRDD = new Date(n.slice(0, 4), b, n.slice(6, 8));
		}
		c.updateBindings();
	},
	_setCartModel: function() {
		var c = new sap.ui.model.json.JSONModel();
		var d = this._getDateAsString();
		var n = parseInt(d.slice(4, 6), 10) - 1;
		var D = new Date(d.slice(0, 4), n, d.slice(6, 8));
		c.setData({
			singleRdd: d,
			formatSingleRdd: D,
			itemCount: 0,
			oShippingInfo: [],
			oShoppingCartItems: []
		});
		c.setSizeLimit(1000);
		sap.ca.scfld.md.app.Application.getImpl().setApplicationModel("soc_cart", c);
		this.updateCartIcon();
	},
	_getDateAsString: function() {
		var d = new Date();
		d.setDate(d.getDate() + 1);
		return sap.ca.ui.model.format.DateFormat.getDateInstance({
			pattern: "yyyyMMdd"
		}).format(d);
	},
	resetCartKeepCustomers: function() {
		var c = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("soc_cart");
		var d = this._getDateAsString();
		var n = parseInt(d.slice(4, 6), 10) - 1;
		var D = new Date(d.slice(0, 4), n, d.slice(6, 8));
		c.setData({
			singleRdd: d,
			formatSingleRdd: D,
			itemCount: 0,
			oShippingInfo: [],
			oShoppingCartItems: [],
			CustomerNumber: c.getData().CustomerNumber,
			CustomerName: c.getData().CustomerName,
			DistributionChannel: c.getData().DistributionChannel,
			Division: c.getData().Division,
			SalesOrganization: c.getData().SalesOrganization
		});
		c.updateBindings();
		this.updateCartIcon();
	},
	updateCartIcon: function() {
		var m = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("soc_cart");
		var d = m.getData();
		var i = d.oShoppingCartItems;
		var I = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("img");
		I.getData().cartIcon = i.length > 0 ? "sap-icon://cart-full" : "sap-icon://cart";
		I.updateBindings();
	},
	navToCustomers: function() {
		this.resetCart();
	},
	navToHome: function() {
		this.resetCartKeepCustomer();
	},
	deleteCartItemAtIndex: function(i) {
		var m = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("soc_cart");
		var d = m.getData();
		var a = d.oShoppingCartItems;
		a.splice(i, 1);
		if (!a.length) {
			delete d.Freight;
			delete d.GrandTotal;
			delete d.Tax;
			delete d.TotalAmount;
		}
		m.setData(d);
		d.itemCount = com.sap.tatasteel.z_createdo.util.ModelUtils.getCartCount();
		m.updateBindings();
		this.updateCartIcon();
	},
	updateCartModelFromSimulationResponse: function(r) {
		var c = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("soc_cart");
		var C = c.getData();
		var o = {};
		var a = C.oShoppingCartItems;
		var i;
		for (i = 0; i < a.length; i++) {
			var n = com.sap.tatasteel.z_createdo.util.Formatter.formatItemNumber(i + 1);
			o[n] = a[i];
		}
		C.TotalAmount = r.data.TotalAmount;
		C.GrandTotal = r.data.GrandTotal;
		C.Tax = r.data.Tax;
		C.Freight = r.data.Freight;
		C.PaymentTerms = r.data.PaymentTerms;
		if (r.data.OrderItemSet !== null) {
			C.oShoppingCartItems = r.data.OrderItemSet.results;
		} else {
			C.oShoppingCartItems = [];
		}
		var b = C.oShoppingCartItems;
		this.formatCartModel(b, o);
		c.updateBindings();
	},
	// updateCartModelFromSimulationResponse: function(r) {
	// 	var c = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("soc_cart");
	// 	var C = c.getData();
	// 	var o = {};
	// 	var a = C.oShoppingCartItems;
	// 	var i;
	// 	for (i = 0; i < a.length; i++) {
	// 		// var n = com.sap.tatasteel.z_createdo.util.Formatter.formatItemNumber(i + 1);
	// 		var n = i;
	// 		o[n] = a[i];
	// 	}
	// 	C.TotalAmount = r.data.TotalAmount;
	// 	C.GrandTotal = r.data.GrandTotal;
	// 	C.Tax = r.data.Tax;
	// 	C.Freight = r.data.Freight;
	// 	C.PaymentTerms = r.data.PaymentTerms;
	// 	if (r.data.OrderItemSet !== null) {
	// 		C.oShoppingCartItems = r.data.OrderItemSet.results;
	// 	} else {
	// 		C.oShoppingCartItems = [];
	// 	}
	// 	var b = C.oShoppingCartItems;
	// 	this.formatCartModel(b, o);
	// 	c.updateBindings();
	// },
	formatCartModel: function(a, o) {
		var s = sap.ui.core.ValueState.Success;
		var w = sap.ui.core.ValueState.Warning;
		var e = sap.ui.core.ValueState.Error;
		var n = sap.ui.core.ValueState.None;
		var i;
		for (i = 0; i < a.length; i++) {
			a[i].isVisible = i > 0 ? a[i].ItemNumber !== a[i - 1].ItemNumber : true;
			if (!(i > 0 && a[i].ItemNumber === (a[i - 1].ItemNumber))) {
				var N = a[i].ItemNumber;
				
				a[i].ImgUrl = o[N].ImgUrl;
				a[i].qty = o[N].qty;
				a[i].RDD = o[N].RDD;
				a[i].DateDisplay = o[N].DateDisplay;
				a[i].UOM = o[N].UOM;
				a[i].UnitofMeasureTxt = o[N].UnitofMeasureTxt;
				a[i].Werks = o[N].Werks;
				a[i].ProductID = a[i].Product;
				a[i].ProductDesc = a[i].ProductName;
				
				a[i].LengthFrom = o[N].LengthFrom;
			    a[i].LengthTo = o[N].LengthTo;
				
				
			//	a[i].BasePrice = o[N].BasePrice;
		    	if (o[N].BasePriceNew)
			    {
				a[i].BasePriceNew = o[N].BasePriceNew;
				a[i].BasePrice = o[N].BasePrice;
				a[i].BasePriceCode = o[N].BasePriceCode;
			    } 
			    if (o[N].FreightPriceNew)
			    {
				a[i].FreightPriceNew = o[N].FreightPriceNew;
					a[i].FreightPriceCode = o[N].FreightPriceCode;
				a[i].FreightPrice = o[N].FreightPrice;
			    } 
			    if (o[N].MrktAgentCommissionNew)
			    {
				a[i].MrktAgentCommissionNew = o[N].MrktAgentCommissionNew;
				a[i].MrktAgentCommissionCode = o[N].MrktAgentCommissionCode;
				a[i].MrktAgentCommission = o[N].MrktAgentCommission;
			    } 
				
				if (a[i].RDD) {
					var b = parseInt(a[i].RDD.slice(4, 6), 10) - 1;
					a[i].formatRDD = new Date(a[i].RDD.slice(0, 4), b, a[i].RDD.slice(6, 8));
				} else {
					a[i].formatRDD = new Date();
				}
			}
			a[i].AvailableQuantity = parseFloat(a[i].AvailableQuantity);
			var f = com.sap.tatasteel.z_createdo.util.Formatter.convertFloatToLocaleNoDecimalHandling(a[i].AvailableQuantity);
			switch (a[i].QuantityStatusCode) {
				case "A":
					a[i].AvailableQuantityStatus = s;
					a[i].AvailQuantity = com.sap.tatasteel.z_createdo.util.Formatter.formatQuantityStatusA();
					break;
				case "B":
					a[i].AvailableQuantityStatus = w;
					a[i].AvailQuantity = f;
					break;
				default:
					a[i].AvailableQuantityStatus = n;
					a[i].AvailQuantity = a[i].AvailableQuantity;
			}
			switch (a[i].DeliveryStatusCode) {
				case "A":
					a[i].EstimatedDeliveryStatus = s;
					a[i].EstimatedDelivery = com.sap.tatasteel.z_createdo.util.Formatter.formatDeliveryStatusA();
					break;
				case "B":
					a[i].EstimatedDeliveryStatus = w;
					a[i].EstimatedDelivery = com.sap.tatasteel.z_createdo.util.Formatter.convertDateToLocaleMedium(a[i].EstimatedDeliveryDate);
					break;
				case "C":
					a[i].EstimatedDeliveryStatus = e;
					a[i].EstimatedDelivery = com.sap.tatasteel.z_createdo.util.Formatter.formatDeliveryStatusC();
					a[i].AvailableQuantityStatus = e;
					a[i].AvailQuantity = com.sap.tatasteel.z_createdo.util.Formatter.formatSignQuantity(f);
					break;
				default:
					a[i].EstimatedDeliveryStatus = n;
					a[i].EstimatedDelivery = a[i].EstimatedDeliveryDate;
			}
		}
	},
	getCartCount: function() {
		var c = sap.ca.scfld.md.app.Application.getImpl().getApplicationModel("soc_cart");
		var C = c.getData();
		var a = C.oShoppingCartItems;
		var b = 0;
		var i;
		for (i = 0; i < a.length; i++) {
			if (a[i].isVisible === true) {
				b++;
			}
		}
		return b;
	}
};