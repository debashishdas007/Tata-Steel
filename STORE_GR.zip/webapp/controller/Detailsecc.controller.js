sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/m/TablePersoController"
], function(Controller, Filter, FilterOperator, JSONModel, History, TablePersoController) {
	"use strict";
	var filters = new Array();
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_STOREGRCOMPLIANCE_SRV_01/");
	return Controller.extend("STORE_GR.controller.Detailsecc", {
		
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf STORE_GR.view.Detailsecc
		 */
			onInit: function() {
			
				var SGcompliancePersoServicedtls = {
	
					oData: {
						_persoSchemaVersion: "1.0",
						aColumns: [{
							id: "demoAppdtls-idStoreGRdtls-Ebeln",
							order: 0,
							visible: true
						}, {
							id: "demoAppdtls-idStoreGRdtls-Ebelp",
							order: 1,
							visible: true
						},{
							id: "demoAppdtls-idStoreGRdtls-Matnr",
							order: 2,
							visible: true
						},{
							id: "demoAppdtls-idStoreGRdtls-Maktx",
							order: 3,
							visible: true
						},{
							id: "demoAppdtls-idStoreGRdtls-MatRecvDate",
							order: 4,
							visible: true
						}, {
							id: "demoAppdtls-idStoreGRdtls-Budat",
							order: 5,
							visible: true
						}, {
							id: "demoAppdtls-idStoreGRdtls-QaInspDt",
							order: 6,
							visible: true
						}, 
						{
							id: "demoAppdtls-idStoreGRdtls-Werks",
							order: 7,
							visible: true
						},{
							id: "demoAppdtls-idStoreGRdtls-Lgort",
							order: 8,
							visible: true
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Xblnr",
							order: 9,
							visible: true
						}, {
							id: "demoAppdtls-idStoreGRdtls-Lifnr",
							order: 10,
							visible: true
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Bsart",
							order: 11,
							visible: false
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Location",
							order: 12,
							visible: false
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Warehouse",
							order: 13,
							visible: false
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Gjahr",
							order: 14,
							visible: false
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Belnr",
							order: 15,
							visible: false
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Buzei",
							order: 16,
							visible: false
						}, 
						{
							id: "demoAppdtls-idStoreGRdtls-Ekgrp",
							order: 17,
							visible: false 
						},
						{
							id: "demoAppdtls-idStoreGRdtls-Dmbtr",
							order: 18,
							visible: false 
						},{
							id: "demoAppdtls-idStoreGRdtls-Bwart",
							order: 19,
							visible: false 
						},{
							id: "demoAppdtls-idStoreGRdtls-Erdat",
							order: 20,
							visible: false 
						},{
							id: "demoAppdtls-idStoreGRdtls-QA_LOT_NO",
							order: 21,
							visible: false
						},
						{
							id: "demoAppdtls-idStoreGRdtls-EccEwmTxt",
							order: 22,
							visible: true
						}]
					},
	
					getPersData: function() {
						var oDeferred = new jQuery.Deferred();
						if (!this._oBundle) {
							this._oBundle = this.oData;
						}
						var oBundle = this._oBundle;
						oDeferred.resolve(oBundle);
						return oDeferred.promise();
					},
	
					setPersData: function(oBundle) {
						var oDeferred = new jQuery.Deferred();
						this._oBundle = oBundle;
						oDeferred.resolve();
						return oDeferred.promise();
					}
	
					//resetPersData: function() {}
	
				};
	
			
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("page3").attachPatternMatched(this._onObjectMatched, this);
					this._oTPC = new TablePersoController({
					table: this.getView().byId("idStoreGRdtls"),
					//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
					componentName: "demoAppdtls",
					persoService: SGcompliancePersoServicedtls
				}).activate();
	
			
			},

			_onObjectMatched: function(oEvent) {
		
			filters = JSON.parse(oEvent.getParameter('arguments').filterPath);
			sap.ui.core.BusyIndicator.show(0);
			var oTable = this.getView().byId("idStoreGRdtls");
			oModel.read('/ET_STORE_GR_DTLSSet', {
				filters: filters,
				success: function(oData, response) {
					oTable.setVisible(true);
					var value = [];
					value = oData.results;
					var oModelMRPStat = new sap.ui.model.json.JSONModel();
					oModelMRPStat.setData({
						ET_STORE_GR_DTLSSet: value
					});
					/**********************export****************/
					var oAuthorityData = oModelMRPStat.oData.ET_STORE_GR_DTLSSet;
					var oAuthorityModel = new sap.ui.model.json.JSONModel(oAuthorityData);
					sap.ui.getCore().setModel(oAuthorityModel, "oAuthorityModel");
					/**************************end******************/
					var oTemplate = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({
								text: "{Ebeln}"
								}),
								new sap.m.Text({
									text: "{Ebelp}"
								}),
								new sap.m.Text({
									text: "{Matnr}"
								}),
								new sap.m.Text({
									text: "{Maktx}"
								}),
								new sap.m.Text({
								text: {
									path: "MatRecvDate",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										pattern: "dd.MM.yyyy"
									}
								}
								}),
								new sap.m.Text({
								text: {
									path: "Budat",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										pattern: "dd.MM.yyyy"
									}
								}
								}),
								new sap.m.Text({
								text: {
									path: "QaInspDt",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										pattern: "dd.MM.yyyy"
									}
								}
								}),
								new sap.m.Text({
									text: "{Werks}"
								}),
								new sap.m.Text({
									text: "{Lgort}"
								}),
								new sap.m.Text({
									text: "{Xblnr}"
								}),
								new sap.m.Text({
									text: "{Lifnr}"
								}),
								new sap.m.Text({
									text: "{Bsart}"
								}),
								new sap.m.Text({
									text: "{Location}"
								}),
								new sap.m.Text({
									text: "{Warehouse}"
								}),
								new sap.m.Text({
									text: "{Gjahr}"
								}),
								new sap.m.Text({
									text: "{Belnr}"
								}),
								new sap.m.Text({
									text: "{Buzei}"
								}),
								new sap.m.Text({
									text: "{Ekgrp}"
								}),
								new sap.m.Text({
									text: "{Dmbtr}"
								}),
								new sap.m.Text({
									text: "{Bwart}"
								}),
								
								new sap.m.Text({
									text: "{Erdat}"
								}),
								new sap.m.Text({
									text: "{QaLotNo}"
								}),
								new sap.m.Text({
									text: "{EccEwmTxt}"
								})
						]
					});
					oTable.setModel(oModelMRPStat);
					oTable.bindAggregation("items", {
						path: "/ET_STORE_GR_DTLSSet",
						template: oTemplate
					});
					sap.ui.core.BusyIndicator.hide();
					
				}
			});
		},
		onToPage1: function() {
			this.getOwnerComponent().getRouter().navTo("page1");
		},
		onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
		},
		/********************************table export*******************************************/
		onExport: function() {
			var getAuthorityModel = sap.ui.getCore().getModel("oAuthorityModel");
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",

					mimeType: "application/vnd.ms-excel",
					charset: "utf-8",
					fileExtension: "xls"

				}),
				models: getAuthorityModel,
				rows: {
					path: "/"
				},

				// column definitions with column name and binding info for the content
				columns: [{
						name: "Po No",
						template: {
							content: {
								path: "Ebeln"
							}
						}
					},{
						name: "Po Item",
						template: {
							content: {
								path: "Ebelp"
							}
						}
					},{
						name: "Matnr",
						template: {
							content: {
								path: "Matnr"
							}
						}
					},{
						name: "Maktx",
						template: {
							content: {
								path: "Maktx"
							}
						}
					},{
						name: "Material Receiving vDate",
						template: {
							content: {
								path: "MatRecvDate"
							}
						}
					}, {
						name: "GR Date",
						template: {
							content: {
								path: "Budat"
							}
						}
					},{
						name: "QA Inspection Date",
						template: {
							content: {
								path: "QaInspDt"
							}
						}
					},{
						name: "Plant",
						template: {
							content: {
								path: "Werks"
							}
						}
					}, {
						name: "Storage location",
						template: {
							content: {
								path: "Lgort"
							}
						}
					},{
						name: "Reference Document Number",
						template: {
							content: {
								path: "Xblnr"
							}
						}
					},{
						name: "Vendor",
						template: {
							content: {
								path: "Lifnr"
							}
						}
					},{
						name: "Po Type",
						template: {
							content: {
								path: "Bsart"
							}
						}
					},
					 {
						name: "Location Code",
						template: {
							content: {
								path: "Location"
							}
						}
					},
					 {
						name: "Warehouse",
						template: {
							content: {
								path: "Warehouse"
							}
						}
					},
					{
						name: "Material Document Year",
						template: {
							content: {
								path: "Gjahr"
							}
						}
					},
					{
						name: "Number of Material Document",
						template: {
							content: {
								path: "Belnr"
							}
						}
					},
					{
						name: "Item in Material Document",
						template: {
							content: {
								path: "Buzei"
							}
						}
					},
					{
						name: "Purchasing Group",
						template: {
							content: {
								path: "Ekgrp"
							}
						}
					},
					{
						name: "Amount",
						template: {
							content: {
								path: "Dmbtr"
							}
						}
					},
					{
						name: "Mvmnt type",
						template: {
							content: {
								path: "Bwart"
							}
						}
					},
					{
						name: "Cr DT",
						template: {
							content: {
								path: "Erdat"
							}
						}
					},
					{
						name: "Inspection Lot Number",
						template: {
							content: {
								path: "QaLotNo"
							}
						}
					}, {
						name: "EccEwmTxt",
						template: {
							content: {
								path: "EccEwmTxt"
							}
						}
					}

				]

			});
			oExport.saveFile().catch(function(oError) {
				//Handle your error
			}).then(function() {
				oExport.destroy();
			});
		}
	
	});

});