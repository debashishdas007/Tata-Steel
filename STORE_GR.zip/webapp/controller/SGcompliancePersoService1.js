sap.ui.define(["jquery.sap.global"],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var SGcompliancePersoService1 = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "demoApp-idStoreGR-INBOUND_DLV1",
					order: 0,
					text: "PO No",
					visible: true
				}, {
					id: "demoApp-idStoreGR-INBOUND_DLV_ITEM1",
					order: 1,
					text: "PO Item",
					visible: true
				}, {
					id: "demoApp-idStoreGR-GR_SAMEDAY1",
					order: 2,
					text: "Vendor",
					visible: true
				}, {
					id: "demoApp-idStoreGR-GR_SAMEDAY_PRCNTG1",
					order: 3,
					text: "Pur Grp",
					visible: true
				}, {
					id: "demoApp-idStoreGR-GR_TEND1",
					order: 4,
					text: "Price",
					visible: true
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			//resetPersData: function() {}

		};

		return SGcompliancePersoService1;

	}, /* bExport= */ true);