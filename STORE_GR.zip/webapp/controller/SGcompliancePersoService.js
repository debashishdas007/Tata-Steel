sap.ui.define(["jquery.sap.global"],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var SGcompliancePersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "demoApp-idStoreGR-INBOUND_DLV",
					order: 0,
					text: "PO No",
					visible: true
				}, {
					id: "demoApp-idStoreGR-INBOUND_DLV_ITEM",
					order: 1,
					text: "PO Item",
					visible: true
				}, {
					id: "demoApp-idStoreGR-GR_SAMEDAY",
					order: 2,
					text: "Vendor",
					visible: true
				}, {
					id: "demoApp-idStoreGR-GR_SAMEDAY_PRCNTG",
					order: 3,
					text: "Pur Grp",
					visible: false
				}, {
					id: "demoApp-idStoreGR-GR_TEND",
					order: 4,
					text: "Price",
					visible: true
				},
				 {
					id: "demoApp-idStoreGR-GR_TEND_PRCNTG",
					order: 5,
					text: "Pur Grp",
					visible: false
				},
				{
					id: "demoApp-idStoreGR-GR_PENDING",
					order: 6,
					text: "Pur Grp",
					visible: true
				},
				{
					id: "demoApp-idStoreGR-GR_PENDING_PRCNTG",
					order: 7,
					text: "Pur Grp",
					visible: false
				},
				{
					id: "demoApp-idStoreGR-QUALITY_INSP_SAMEDAY",
					order: 8,
					text: "Pur Grp",
					visible: true
				},
				{
					id: "demoApp-idStoreGR-QUALITY_INSP_SAMEDAYPERCENTG",
					order: 9,
					text: "Pur Grp",
					visible: false
				},
				{
					id: "demoApp-idStoreGR-QUALITY_INSP_TEND",
					order: 10,
					text: "Pur Grp",
					visible: true
				},
				{
					id: "demoApp-idStoreGR-QUALITY_INSP_TEND_PRCNTG",
					order: 11,
					text: "Pur Grp",
					visible: false
				},
				{
					id: "demoApp-idStoreGR-QUALITY_INSP_PENDING",
					order: 12,
					text: "Pur Grp",
					visible: true
				},
				{
					id: "demoApp-idStoreGR-QUALITY_INSP_PENDING_PRCNTG",
					order: 13,
					text: "Pur Grp",
					visible: false
				},
				{
					id: "demoApp-idStoreGR-PUTAWAY_SAMEDAY",
					order: 14,
					text: "Pur Grp",
					visible: true
				},
				{
					id: "demoApp-idStoreGR-PUTAWAY_SAMEDAY_PRCNTG",
					order: 15,
					text: "Pur Grp",
					visible: false
				},
				{
					id: "demoApp-idStoreGR-PUTAWAY_TEND",
					order: 16,
					text: "Pur Grp",
					visible: true
				},
					{
					id: "demoApp-idStoreGR-PUTAWAY_TEND_PRCNTG",
					order: 17,
					text: "Pur Grp",
					visible: false
				},
				{
					id: "demoApp-idStoreGR-PUTAWAY_PENDING",
					order: 18,
					text: "Pur Grp",
					visible: true
				}
				,{
					id: "demoApp-idStoreGR-PUTAWAY_PENDING_PRCNTG",
					order: 19,
					text: "Pur Grp",
					visible: false
				}
				
				]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			//resetPersData: function() {}

		};

		return SGcompliancePersoService;

	}, /* bExport= */ true);