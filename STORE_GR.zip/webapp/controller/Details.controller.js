sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/m/TablePersoController"
], function(Controller, Filter, FilterOperator, JSONModel, History, TablePersoController) {
	"use strict";
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_STOREGRCOMPLIANCE_SRV_01/");
	return Controller.extend("STORE_GR.controller.Details", {

		onInit: function() {

			var SGcompliancePersoServicedtls = {

				oData: {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "demoAppdtls-idStoreGRdtls-Vbeln",
						order: 0,
						text: "Delivery Item",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Ebeln",
						order: 2,
						text: "PO No",
						visible: true
					}, {
						id: "demoAppdtls-idStoreGRdtls-Ebelp",
						order: 3,
						text: "PO Item",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Matnr",
						order: 4,
						text: "Material no",
						visible: true
					}, {
						id: "demoAppdtls-idStoreGRdtls-Maktx",
						order: 5,
						text: "Maktx",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Lfdat",
						order: 6,
						text: "Lfdat",
						visible: true
					}, {
						id: "demoAppdtls-idStoreGRdtls-MatRecvDate",
						order: 7,
						text: "Price",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Budat",
						order: 8,
						text: "Price",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-QaInspDt",
						order: 9,
						text: "Price",
						visible: true
					}, {
						id: "demoAppdtls-idStoreGRdtls-PutawayDate",
						order: 10,
						text: "Price",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Werks",
						order: 11,
						text: "Price",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Lgort",
						order: 12,
						text: "Lgort",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Xblnr",
						order: 13,
						text: "Xblnr",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Lifnr",
						order: 4,
						text: "Lifnr",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Bsart",
						order: 14,
						text: "Bsart",
						visible: true
					},{
						id: "demoAppdtls-idStoreGRdtls-Location",
						order: 15,
						text: "Location",
						visible: true
					}, {
						id: "demoAppdtls-idStoreGRdtls-Warehouse",
						order: 16,
						text: "Warehouse",
						visible: false
					}, {
						id: "demoAppdtls-idStoreGRdtls-Gjahr",
						order: 17,
						text: "Gjahr",
						visible: false
					}, {
						id: "demoAppdtls-idStoreGRdtls-Belnr",
						order: 18,
						text: "Pur Grp",
						visible: false
					}, {
						id: "demoAppdtls-idStoreGRdtls-Buzei",
						order: 19,
						text: "Price",
						visible: false
					}, {
						id: "demoAppdtls-idStoreGRdtls-Ekgrp",
						order: 29,
						text: "Price",
						visible: false
					}, {
						id: "demoAppdtls-idStoreGRdtls-Dmbtr",
						order: 21,
						text: "Price",
						visible: false
					},{
						id: "demoAppdtls-idStoreGRdtls-Bwart",
						order: 22,
						visible: false
					},{
						id: "demoAppdtls-idStoreGRdtls-Erdat",
						order: 23,
						visible: false
					},{
						id: "demoAppdtls-idStoreGRdtls-QaLotNo",
						order: 24,
						visible: false
					}, {
						id: "demoAppdtls-idStoreGRdtls-EccEwmTxt",
						order: 25,
						visible: true
					}]
				},

				getPersData: function() {
					var oDeferred = new jQuery.Deferred();
					if (!this._oBundle) {
						this._oBundle = this.oData;
					}
					var oBundle = this._oBundle;
					oDeferred.resolve(oBundle);
					return oDeferred.promise();
				},

				setPersData: function(oBundle) {
					var oDeferred = new jQuery.Deferred();
					this._oBundle = oBundle;
					oDeferred.resolve();
					return oDeferred.promise();
				}

				//resetPersData: function() {}

			};

		
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("page2").attachPatternMatched(this._onObjectMatched, this);
				this._oTPC = new TablePersoController({
				table: this.getView().byId("idStoreGRdtls"),
				//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
				componentName: "demoAppdtls",
				persoService: SGcompliancePersoServicedtls
			}).activate();

		},
		_onObjectMatched: function(oEvent) {
			var filters = new Array();
			filters = JSON.parse(oEvent.getParameter('arguments').filterPath);
			sap.ui.core.BusyIndicator.show(0);
			var oTable = this.getView().byId("idStoreGRdtls");
			oModel.read('/ET_STORE_GR_DTLSSet', {
				filters: filters,
				success: function(oData, response) {
					oTable.setVisible(true);
					var value = [];
					value = oData.results;
					var oModelMRPStat = new sap.ui.model.json.JSONModel();
					oModelMRPStat.setData({
						ET_STORE_GR_DTLSSet: value
					});
					/**********************export****************/
					var oAuthorityData = oModelMRPStat.oData.ET_STORE_GR_DTLSSet;
					var oAuthorityModel = new sap.ui.model.json.JSONModel(oAuthorityData);
					sap.ui.getCore().setModel(oAuthorityModel, "oAuthorityModel");
					/**************************end******************/
					var oTemplate = new sap.m.ColumnListItem({
						cells: [
								new sap.m.Text({
									text: "{Vbeln}"
								}),
								new sap.m.Text({
								text: "{Ebeln}"
								}),
								new sap.m.Text({
									text: "{Ebelp}"
								}),
								new sap.m.Text({
									text: "{Matnr}"
								}),
								new sap.m.Text({
									text: "{Maktx}"
								}),
								new sap.m.Text({
									text: {
										path: "Lfdat",
										type: "sap.ui.model.type.Date",
										formatOptions: {
											pattern: "dd.MM.yyyy"
										}
									}
								}),
								new sap.m.Text({
								text: {
									path: "MatRecvDate",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										pattern: "dd.MM.yyyy"
									}
								}
								}),
								new sap.m.Text({
								text: {
									path: "Budat",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										pattern: "dd.MM.yyyy"
									}
								}
								}),
								new sap.m.Text({
								text: {
									path: "QaInspDt",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										pattern: "dd.MM.yyyy"
									}
								}
								}),
								new sap.m.Text({
								text: {
									path: "PutawayDate",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										pattern: "dd.MM.yyyy"
									}
								}
								}),
								new sap.m.Text({
									text: "{Werks}"
								}),
								new sap.m.Text({
									text: "{Lgort}"
								}),
								new sap.m.Text({
									text: "{Xblnr}"
								}),
								new sap.m.Text({
									text: "{Lifnr}"
								}),
								new sap.m.Text({
									text: "{Bsart}"
								}),
								new sap.m.Text({
									text: "{Location}"
								}),
								new sap.m.Text({
									text: "{Warehouse}"
								}),
								new sap.m.Text({
									text: "{Gjahr}"
								}),
								new sap.m.Text({
									text: "{Belnr}"
								}),
								new sap.m.Text({
									text: "{Buzei}"
								}),
								new sap.m.Text({
									text: "{Ekgrp}"
								}),
								new sap.m.Text({
									text: "{Dmbtr}"
								}),
								new sap.m.Text({
									text: "{Bwart}"
								}),
								new sap.m.Text({
									text: {
										path: "Erdat",
										type: "sap.ui.model.type.Date",
										formatOptions: {
											pattern: "dd.MM.yyyy"
										}
									}
								}),
								new sap.m.Text({
									text: "{QaLotNo}"
								}),
								
								new sap.m.Text({
									text: "{EccEwmTxt}"
								})
						]
					});
					oTable.setModel(oModelMRPStat);
					oTable.bindAggregation("items", {
						path: "/ET_STORE_GR_DTLSSet",
						template: oTemplate
					});
					sap.ui.core.BusyIndicator.hide();
					
				}
			});
		},
		onToPage1: function() {
			this.getOwnerComponent().getRouter().navTo("page1");
		},
		onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
		},
		/********************************table export*******************************************/
		onExport: function() {
			var getAuthorityModel = sap.ui.getCore().getModel("oAuthorityModel");
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",

					mimeType: "application/vnd.ms-excel",
					charset: "utf-8",
					fileExtension: "xls"

				}),
				models: getAuthorityModel,
				rows: {
					path: "/"
				},

				// column definitions with column name and binding info for the content
				columns: [
					 {
						name: "Dlv Item",
						template: {
							content: {
								path: "Vbeln"
							}
						}
					},
					{
						name: "Po No",
						template: {
							content: {
								path: "Ebeln"
							}
						}
					},{
						name: "Po Item",
						template: {
							content: {
								path: "Ebelp"
							}
						}
					}, 
					{
						name: "Mat No",
						template: {
							content: {
								path: "Matnr"
							}
						}
					},{
						name: "Mat Desc",
						template: {
							content: {
								path: "Maktx"
							}
						}
					},
					 {
						name: "Dlv Date",
						template: {
							content: {
								path: "Lfdat"
							}
						}
					},{
						name: "Mat rcv Date",
						template: {
							content: {
								path: "MatRecvDate"
							}
						}
					}, {
						name: "GR Date",
						template: {
							content: {
								path: "Budat"
							}
						}
					},{
						name: "QA Insp Date",
						template: {
							content: {
								path: "QaInspDt"
							}
						}
					}, {
						name: "Putaway Date",
						template: {
							content: {
								path: "PutawayDate"
							}
						}
					},
					{
						name: "Plant",
						template: {
							content: {
								path: "Werks"
							}
						}
					}, {
						name: "Sto loc",
						template: {
							content: {
								path: "Lgort"
							}
						}
					}, 
					 {
						name: "Ref No",
						template: {
							content: {
								path: "Xblnr"
							}
						}
					}, {
						name: "Vendor",
						template: {
							content: {
								path: "Lifnr"
							}
						}
					},  {
						name: "Po Type",
						template: {
							content: {
								path: "Bsart"
							}
						}
					},{
						name: "Location",
						template: {
							content: {
								path: "Location"
							}
						}
					},{
						name: "Warehouse",
						template: {
							content: {
								path: "Warehouse"
							}
						}
					},{
						name: "Mat Doc Yr",
						template: {
							content: {
								path: "Gjahr"
							}
						}
					},{
						name: "Tot Mat Doc",
						template: {
							content: {
								path: "Belnr"
							}
						}
					}, {
						name: "Item Mat Doc",
						template: {
							content: {
								path: "Buzei"
							}
						}
					},{
						name: "Prch Gr",
						template: {
							content: {
								path: "Ekgrp"
							}
						}
					 }, 
					 {
						name: "Amount",
						template: {
							content: {
								path: "Dmbtr"
							}
						}
					 },
					 {
						name: "Movement type",
						template: {
							content: {
								path: "Bwart"
							}
						}
					 },
					 {
						name: "Cr Date",
						template: {
							content: {
								path: "Erdat"
							}
						}
					 },
					{
						name: "Insp Lot No",
						template: {
							content: {
								path: "QaLotNo"
							}
						}
					}, {
						name: "EccEwmTxt",
						template: {
							content: {
								path: "EccEwmTxt"
							}
						}
					}

				]

			});
			oExport.saveFile().catch(function(oError) {
				//Handle your error
			}).then(function() {
				oExport.destroy();
			});
		}
		/*******************************end**********************************************************************/

	});

});