sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/TablePersoController",
	"./SGcompliancePersoService",
	"./SGcompliancePersoService1",
	"sap/m/MessageBox",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV"
], function(Controller, Filter, JSONModel, FilterOperator, TablePersoController, SGcompliancePersoService, SGcompliancePersoService1, MessageBox, Export, ExportTypeCSV) {
	"use strict";
	var oValueHelpDialog = null;
	var filterEccEwm = '';
	var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMPIO_STOREGRCOMPLIANCE_SRV_01/");
	return Controller.extend("STORE_GR.controller.Home", {
		
		onInit: function()
		{
			this._oTPC = new TablePersoController({
				table: this.getView().byId("idStoreGR"),
				//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
				componentName: "demoApp",
				persoService: SGcompliancePersoService
			}).activate();
			this._oTPC1 = new TablePersoController({
				table: this.getView().byId("idStoreGR1"),
				//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
				componentName: "demoApp",
				persoService: SGcompliancePersoService1
			}).activate();
	
			
		},
		onPersoButtonPressed: function(oEvent) {

			this._oTPC.openDialog();
		},
		onPersoButtonPressed1: function(oEvent) {

			this._oTPC1.openDialog();
		},

		onChangePending: function(evt) {

			this.onSearch();
		},
		/************************MATNR SEARCH HELP****************************/
		showValueHelpMATNR: function() {
			var multiInputMatNo = this.getView().byId("multiInputMATNR");
			this.getView().byId("multiInputMATNR").setValueState(sap.ui.core.ValueState.None);
			if (!this._oValueHelpDialogMatnr) {
				this._oValueHelpDialogMatnr = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idmultiInputMATNR", {
					supportRanges: true,
					supportRangesOnly: true,
					title: "Material No",
					key: "Material No",
					descriptionKey: "Material No",
					tokenDisplayBehaviour: "Material No",
					ok: function(oEvent) {
						var aTokens = oEvent.getParameter("tokens");
						multiInputMatNo.setTokens(aTokens);
						// var tokens = multiInputMatNo.getTokens();
						// jQuery.each(tokens, function(idx, token) {
						// 	token.setEditable(false);
						// });
						this.close();
					},
					cancel: function() {
						this.close();
					}
				});
			}
			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "Material No",
					template: "Material No"

				}]
			});
			
			this._oValueHelpDialogMatnr.setRangeKeyFields([{
				label: "Material No",
				key: "Material No"
			}]);

		//	this._oValueHelpDialogMatnr.setModel(oModelMatno);
			this._oValueHelpDialogMatnr.open();
		},
		/************************end******************************************/

		/************************PO NO SEARCH HELP****************************/
		showValueHelpPONO: function() {
			var multiInputMatNo = this.getView().byId("multiInputPONO");
			this.getView().byId("multiInputPONO").setValueState(sap.ui.core.ValueState.None);
			if (!this._oValueHelpDialogMatno) {
				this._oValueHelpDialogMatno = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idmultiInputPONO", {
					supportRanges: true,
					supportRangesOnly: true,
					title: "PurchaseOrder No",
					key: "PurchaseOrder No",
					descriptionKey: "PurchaseOrder No",
					tokenDisplayBehaviour: "PurchaseOrder No",
					ok: function(oEvent) {
						var aTokens = oEvent.getParameter("tokens");
						multiInputMatNo.setTokens(aTokens);
						// var tokens = multiInputMatNo.getTokens();
						// jQuery.each(tokens, function(idx, token) {
						// 	token.setEditable(false);
						// });
						this.close();
					},
					cancel: function() {
						this.close();
					}
				});
			}
			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "PurchaseOrder No",
					template: "PurchaseOrder No"

				}]
			});
			
			this._oValueHelpDialogMatno.setRangeKeyFields([{
				label: "PurchaseOrderNo",
				key: "PurchaseOrderNo"
			}]);

//			this._oValueHelpDialogMatno.setModel(oModelMatno);
			this._oValueHelpDialogMatno.open();
		},
		/************************end******************************************/
		/**************************for token create and change****************/
			changeToken: function(oEvent) {
			// var str = oEvent.mParameters.id;
			//   var id = str.replace("__xmlview1--", '').trim();
			var oView = this.getView();
			var oMultiInput1 = oView.byId(oEvent.mParameters.id);
			this.createTokens(oEvent, oMultiInput1);
		},
		createTokens: function(oEvent, obj) {
			var oView = this.getView();
			var tokens = obj.getTokens();
			var _newTokens = [];
			_newTokens = new sap.m.Token({
				text: oEvent.mParameters.value,
				key: oEvent.mParameters.value
			});

			//tokens.push(_newTokens);
			obj.addToken(_newTokens);
			obj.setValue("");
		},
		/***********************************end*********************************/
		/***************************plant search help*************************/
		showValueHelpPlant: function() {
			oValueHelpDialog = null;
			var multiInputPlant = this.getView().byId("multiInputPlant");
			//var that = this;
			if (multiInputPlant.getTokens().length <= 0) {
				this.plantTableValue = null;
			}
			oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				supportRanges: true,
				title: "Plant",
				key: "Plant",
				showSuggestion:true,
                showValueHelp: true,
				descriptionKey: "Plant",
				tokenDisplayBehaviour: "Plant",
				stretch: sap.ui.Device.system.phone,
				ok: function(oControlEvent) {
					var aTokens = oControlEvent.getParameter("tokens");
					var sTokens = "";
					for (var i = 0; i < aTokens.length; i++) {
						var oToken = aTokens[i];
						sTokens += oToken.getText() + " ";
					}
					multiInputPlant.setTokens(aTokens);
					if (!this.plantTableValue) {
						this.plantTableValue = oValueHelpDialog.getTable().getModel().getData();
					}
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				cancel: function(oControlEvent) {
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				afterClose: function() {
					this.destroy();
					oValueHelpDialog = null;
				}
			});
			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "Plant",
					template: "Plant",
					iskey: "true"
				}, {
					label: "Description",
					template: "PlantDesc"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			if (!this.plantTableValue) {
				oValueHelpDialog.setBusy(true);
				// sap.ui.core.BusyIndicator.show();
				var oRowsModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_CDS_PLANT_CDS/");
				oRowsModel.read("/Y_Cds_Plant", {
					success: function(oData, response) {
						var value = [];
						value = oData.results;
						var oModelPlant = new sap.ui.model.json.JSONModel();
						oModelPlant.setData(value);
						oValueHelpDialog.getTable().setModel(oModelPlant);
						if (oValueHelpDialog.getTable().bindRows) {
							oValueHelpDialog.getTable().bindRows("/");
						}
						if (oValueHelpDialog.getTable().bindItems) {
						var oTable = oValueHelpDialog.getTable();

						oTable.bindAggregation("items", "/", function(sId, oContext) {
							var aCols = oTable.getModel("columns").getData().cols;

							return new sap.m.ColumnListItem({
								cells: aCols.map(function(column) {
									var colname = column.template;
									return new sap.m.Label({
										text: "{" + colname + "}"
									});
								})
							});
						});
					}
						if (multiInputPlant.getTokens().length > 0) {
							oValueHelpDialog.setTokens(multiInputPlant.getTokens());
						}
						oValueHelpDialog.setBusy(false);
						oValueHelpDialog.update();

					},
					error: function(oError) { //read error}
						sap.m.MessageToast.show("Error Fetching data");
					},
					beforeOpen: function(oControlEvent) {
						sap.m.MessageToast.show("Selection changed!");
					}
				});
			} else {
				var oModelPlant2 = new sap.ui.model.json.JSONModel();
				oModelPlant2.setData(this.plantTableValue);
				oValueHelpDialog.getTable().setModel(oModelPlant2);
				if (oValueHelpDialog.getTable().bindRows) {
					oValueHelpDialog.getTable().bindRows("/");
				}
				if (oValueHelpDialog.getTable().bindItems) {
					var oTable = oValueHelpDialog.getTable();

					oTable.bindAggregation("items", "/", function(sId, oContext) {
						var aCols = oTable.getModel("columns").getData().cols;

						return new sap.m.ColumnListItem({
							cells: aCols.map(function(column) {
								var colname = column.template;
								return new sap.m.Label({
									text: "{" + colname + "}"
								});
							})
						});
					});
				}
				if (multiInputPlant.getTokens()) {
					oValueHelpDialog.setTokens(multiInputPlant.getTokens());
				}
				oValueHelpDialog.open();
				oValueHelpDialog.update();
			}
			
			oValueHelpDialog.setRangeKeyFields([{
				label: "Plant",
				key: "Werks"
			}]);
			
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				searchEnabled: false,
				showGoOnFB: false,
				showClearButton: true
			});
			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					tooltip: "Search for Plant",
					placeholder: "Search",
					search: function(event) {
						var data = event.mParameters.query;
						var oFilters = new sap.ui.model.Filter({
							and: false,
							filters: [
								new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, data)
									]
								}),
								new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("PlantDesc", sap.ui.model.FilterOperator.Contains, data)
									]
								})
							]
						});
						var oElement = oValueHelpDialog.getTable();
						if(oValueHelpDialog.getTable().bindRows) {
							oElement.getBinding("rows").filter([oFilters]);
						}else{
							oElement.getBinding("items").filter([oFilters]);
						}
						
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();
		},
		/***************************end***************************************/
		/**********************show alert message****************************/
		showAlertMessage: function(val) {
			sap.m.MessageBox.error( val, {
			    title: "Information",                                      
			    onClose: null  ,                                      
			    styleClass: ""  ,                                     
			    initialFocus: null ,
			    actions: sap.m.MessageBox.Action.OK,
			    textDirection: sap.ui.core.TextDirection.Inherit    
			   });
		},
		/***************************end**************************************/
		/********************************search filtering*********************/
		onSearch: function(event) {
				var gr_date_from = this.getView().byId("gr_dt_from").getValue();
				var gr_date_to = this.getView().byId("gr_dt_to").getValue();
				var pono = this.getView().byId("multiInputPONO");
				var matnr = this.getView().byId("multiInputMATNR");
				var plant = this.getView().byId("multiInputPlant");
				var PlantTokens = plant.getTokens();
				var potokens = pono.getTokens();
				var matnrtokens = matnr.getTokens();
				var Ecc_Ewm = this.getView().byId("ecc_ewm").getSelectedKey();
				 filterEccEwm = Ecc_Ewm;
				var location = this.getView().byId("Location").getValue();
				var filters = new Array();
				//var that = this;
				if (Ecc_Ewm === "") {
					this.showAlertMessage("Please Select ECC-EWM!");
					 
					return false;
				} 
				if (gr_date_from !== '' && gr_date_to !== '') {
				var oFilters = new sap.ui.model.Filter("MatRecvDate", sap.ui.model.FilterOperator.BT, gr_date_from, gr_date_to);
					filters.push(oFilters);
				}
				
				for (var i = 0; i < potokens.length; i++) {
					var filterpo = new sap.ui.model.Filter();
					if (potokens[i].getKey().indexOf("range") === -1) {
						filterpo = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.EQ, potokens[i].getKey());
					} else {
						if (potokens[i].data().range.exclude) {
							filterpo = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.NE, potokens[i].data().range.value1);
						} else {
							filterpo = new sap.ui.model.Filter("Ebeln", potokens[i].data().range.operation, potokens[i].data().range.value1,
								potokens[i].data().range.value2);
						}
					}
					filters.push(filterpo);
				}
				//**if PONO is input as plain text **//
				if (pono.getValue() !== "") {
					var filterPONO = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.EQ, pono.getValue());
					filters.push(filterPONO);
				}
				/************************matnr*****************************/
					for (var i = 0; i < matnrtokens.length; i++) {
					var filtermatnr = new sap.ui.model.Filter();
					if (matnrtokens[i].getKey().indexOf("range") === -1) {
						filtermatnr = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.EQ, matnrtokens[i].getKey());
					} else {
						if (matnrtokens[i].data().range.exclude) {
							filtermatnr = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.NE, matnrtokens[i].data().range.value1);
						} else {
							filtermatnr = new sap.ui.model.Filter("Matnr", matnrtokens[i].data().range.operation, matnrtokens[i].data().range.value1,
								matnrtokens[i].data().range.value2);
						}
					}
					filters.push(filtermatnr);
				}
				//**if matnr is input as plain text **//
				if (matnr.getValue() !== "") {
					var filtermatnrs = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.EQ, pono.getValue());
					filters.push(filtermatnrs);
				}
				/*************************plant ***********************************************/
				for (var j = 0; j < PlantTokens.length; j++) {
					var filterplant = new sap.ui.model.Filter();
					if (PlantTokens[j].getKey().indexOf("range") === -1) {
						filterplant = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, PlantTokens[j].getKey());
					} else {
						if (PlantTokens[j].data().range.exclude) {
							filterplant = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.NE, PlantTokens[j].data().range.value1);
						} else {
							filterpo = new sap.ui.model.Filter("Werks", PlantTokens[j].data().range.operation, PlantTokens[j].data().range.value1,
								PlantTokens[j].data().range.value2);
						}
					}
					filters.push(filterplant);
				}
				//**if Plant is input as plain text **//
				if (plant.getValue() !== "") {
					var filterWerks = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, plant.getValue());
					filters.push(filterWerks);
				}
				/*******for ecc ewm*******/
				var oFilterecc = new sap.ui.model.Filter("EccEwmTxt", sap.ui.model.FilterOperator.EQ, Ecc_Ewm);
				filters.push(oFilterecc);
				/********for location*****************/
				if (location !== "") {
					var oFilterlocation = new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.EQ, location.toUpperCase());
					filters.push(oFilterlocation);
				}
				
				
				sap.ui.core.BusyIndicator.show(0);
				if(Ecc_Ewm === 'EWM'){
					var oTable = this.getView().byId("idStoreGR");
					var oTable1 = this.getView().byId("idStoreGR1");
						oModel.read('/ET_STORE_GRSet', {
					filters: filters,
					success: function(oData, response) {
						oTable.setVisible(true);
						oTable1.setVisible(false);
					
						var value = [];
						value = oData.results;
						var oModelMRPStat = new sap.ui.model.json.JSONModel();
						oModelMRPStat.setData({
							ET_STORE_GRSet: value
						});
						/**********************export****************/
						var oAuthorityData = oModelMRPStat.oData.ET_STORE_GRSet;
						var oAuthorityModel = new sap.ui.model.json.JSONModel(oAuthorityData);
						sap.ui.getCore().setModel(oAuthorityModel, "oAuthorityModel");	
						/**************************end******************/
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
									text: "{InboundDlv}"
								}),
								new sap.m.Text({
									text: "{InboundDlvItem}"
								}),
								new sap.m.Text({
									text: "{GrSameday}"
								}),
								new sap.m.Text({
									text: "{GrSamedayPrcntg}"
								}),
								new sap.m.Text({
									text: "{GrTend}"
								}),
								new sap.m.Text({
									text: "{GrTendPrcntg}"
								}),
								new sap.m.Text({
									text: "{GrPending}"
								}),
								new sap.m.Text({
									text: "{GrPendingPrcntg}"
								}),
								new sap.m.Text({
									text: "{QualityInspSameday}"
								}),
								new sap.m.Text({
									text: "{QualityInspSamedayPrcntg}"
								}),
								new sap.m.Text({
									text: "{QualityInspTend}"
								}),
								new sap.m.Text({
									text: "{QualityInspTendPrcntg}"
								}),
								new sap.m.Text({
									text: "{QualityInspPending}"
								}),
								new sap.m.Text({
									text: "{QualityInspPendingPrcntg}"
								}),
								new sap.m.Text({
									text: "{PutawaySameday}"
								}),
								new sap.m.Text({
									text: "{PutawaySamedayPrcntg}"
								}),
								new sap.m.Text({
									text: "{PutawayTend}"
								}),
								new sap.m.Text({
									text: "{PutawayTendPrcntg}"
								}),
								new sap.m.Text({
									text: "{PutawayPending}"
								}),
								new sap.m.Text({
									text: "{PutawayPendingPrcntg}"
								})
							
							]
						});
			
						oTable.setModel(oModelMRPStat);
						oTable.bindAggregation("items", {
							path: "/ET_STORE_GRSet",
							template: oTemplate
						});
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}else{
					var oTable = this.getView().byId("idStoreGR1");
					var oTable1 = this.getView().byId("idStoreGR");
						oModel.read('/ET_STORE_GRSet', {
					filters: filters,
					success: function(oData, response) {
						oTable.setVisible(true);
						oTable1.setVisible(false);
						var value = [];
						value = oData.results;
						var oModelMRPStat = new sap.ui.model.json.JSONModel();
						oModelMRPStat.setData({
							ET_STORE_GRSet: value
						});
						/**********************export****************/
						var oAuthorityData = oModelMRPStat.oData.ET_STORE_GRSet;
						var oAuthorityModel = new sap.ui.model.json.JSONModel(oAuthorityData);
						sap.ui.getCore().setModel(oAuthorityModel, "oAuthorityModel");	
						/**************************end******************/
						var oTemplate = new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
									text: "{TotPoNo}"
								}),
								new sap.m.Text({
									text: "{TotPoItem}"
								}),
								new sap.m.Text({
									text: "{GrSameday}"
								}),
								new sap.m.Text({
									text: "{GrSamedayPrcntg}"
								}),
								new sap.m.Text({
									text: "{GrTend}"
								}),
								new sap.m.Text({
									text: "{GrTendPrcntg}"
								}),
								new sap.m.Text({
									text: "{GrPending}"
								}),
								new sap.m.Text({
									text: "{GrPendingPrcntg}"
								}),
								new sap.m.Text({
									text: "{QualityInspSameday}"
								}),
								new sap.m.Text({
									text: "{QualityInspSamedayPrcntg}"
								}),
								new sap.m.Text({
									text: "{QualityInspTend}"
								}),
								new sap.m.Text({
									text: "{QualityInspTendPrcntg}"
								}),
								new sap.m.Text({
									text: "{QualityInspPending}"
								}),
								new sap.m.Text({
									text: "{QualityInspPendingPrcntg}"
								})
							]
						});
			
						oTable.setModel(oModelMRPStat);
						oTable.bindAggregation("items", {
							path: "/ET_STORE_GRSet",
							template: oTemplate
						});
						sap.ui.core.BusyIndicator.hide();
					}
				});
			
				
			}
			
		},
		
		
		/************************************end*****************************/
		/************************selection change*****************************/
		onSelectionChange : function(oEvent){
			
				var gr_date_from = this.getView().byId("gr_dt_from").getValue();
				var gr_date_to = this.getView().byId("gr_dt_to").getValue();
				var pono = this.getView().byId("multiInputPONO");
				var matnr = this.getView().byId("multiInputMATNR");
				var plant = this.getView().byId("multiInputPlant");
				var PlantTokens = plant.getTokens();
				var potokens = pono.getTokens();
				var matnrtokens = matnr.getTokens();
				var Ecc_Ewm = this.getView().byId("ecc_ewm").getSelectedKey();
				 filterEccEwm = Ecc_Ewm;
				var location = this.getView().byId("Location").getValue();
				var filters = new Array();
				//var that = this;
				if (Ecc_Ewm === "") {
					this.showAlertMessage("Please Select Ecc_Ewm!");
					return false;
				} 
				if (gr_date_from !== '' && gr_date_to !== '') {
				var oFilters = new sap.ui.model.Filter("MatRecvDate", sap.ui.model.FilterOperator.BT, gr_date_from, gr_date_to);
					filters.push(oFilters);
				}
				
				for (var i = 0; i < potokens.length; i++) {
					var filterpo = new sap.ui.model.Filter();
					if (potokens[i].getKey().indexOf("range") === -1) {
						filterpo = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.EQ, potokens[i].getKey());
					} else {
						if (potokens[i].data().range.exclude) {
							filterpo = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.NE, potokens[i].data().range.value1);
						} else {
							filterpo = new sap.ui.model.Filter("Ebeln", potokens[i].data().range.operation, potokens[i].data().range.value1,
								potokens[i].data().range.value2);
						}
					}
					filters.push(filterpo);
				}
				//**if PONO is input as plain text **//
				if (pono.getValue() !== "") {
					var filterPONO = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.EQ, pono.getValue());
					filters.push(filterPONO);
				}
					/************************matnr*****************************/
					for (var i = 0; i < matnrtokens.length; i++) {
					var filtermatnr = new sap.ui.model.Filter();
					if (matnrtokens[i].getKey().indexOf("range") === -1) {
						filtermatnr = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.EQ, matnrtokens[i].getKey());
					} else {
						if (matnrtokens[i].data().range.exclude) {
							filtermatnr = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.NE, matnrtokens[i].data().range.value1);
						} else {
							filtermatnr = new sap.ui.model.Filter("Matnr", matnrtokens[i].data().range.operation, matnrtokens[i].data().range.value1,
								matnrtokens[i].data().range.value2);
						}
					}
					filters.push(filtermatnr);
				}
				//**if matnr is input as plain text **//
				if (matnr.getValue() !== "") {
					var filtermatnrs = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.EQ, pono.getValue());
					filters.push(filtermatnrs);
				}
				for (var j = 0; j < PlantTokens.length; j++) {
					var filterplant = new sap.ui.model.Filter();
					if (PlantTokens[j].getKey().indexOf("range") === -1) {
						filterplant = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, PlantTokens[j].getKey());
					} else {
						if (PlantTokens[j].data().range.exclude) {
							filterplant = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.NE, PlantTokens[j].data().range.value1);
						} else {
							filterpo = new sap.ui.model.Filter("Werks", PlantTokens[j].data().range.operation, PlantTokens[j].data().range.value1,
								PlantTokens[j].data().range.value2);
						}
					}
					filters.push(filterplant);
				}
				//**if Plant is input as plain text **//
				if (plant.getValue() !== "") {
					var filterWerks = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, plant.getValue());
					filters.push(filterWerks);
				}
				/*******for ecc ewm*******/
				var oFilterecc = new sap.ui.model.Filter("EccEwmTxt", sap.ui.model.FilterOperator.EQ, Ecc_Ewm);
				filters.push(oFilterecc);
				/********for location*****************/
				if (location !== "") {
					var oFilterlocation = new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.EQ, location.toUpperCase());
					filters.push(oFilterlocation);
				}
				
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				if(Ecc_Ewm === 'EWM'){
					oRouter.navTo("page2", {
						filterPath: JSON.stringify(filters)
					});
					this.getView().byId('idStoreGR').removeSelections(true );
				}else{
					oRouter.navTo("page3", {
						filterPath: JSON.stringify(filters)
					});
					this.getView().byId('idStoreGR1').removeSelections(true );
				}
			
				//	sap.ui.core.BusyIndicator.show();
			
			},
		/*****************************end************************************/
		/********************************table export*******************************************/
		onExport: function() {
	/*******************************for excel column heading**************************************/		
			if(filterEccEwm === 'EWM'){
				var	acolumns = [
				{
				name: "InboundDlv",
				template: {
				content: {
				path: "InboundDlv"
				}
				}
				},
				{
				name: "InboundDlvItem",
				template: {
				content: {
				path: "InboundDlvItem"
				}
				}
				},
				{
				name: "GrSameday",
				template: {
				content: {
				path: "GrSameday"
				}
				}
				},
				{
				name: "GrSamedayPrcntg",
				template: {
				content: {
				path: "GrSamedayPrcntg"
				}
				}
				},
				{
				name: "GrTend",
				template: {
				content: {
				path: "GrTend"
				}
				}
				},
				{
				name: "GrTendPrcntg",
				template: {
				content: {
				path: "GrTendPrcntg"
				}
				}
				},
				{
				name: "GrPending",
				template: {
				content: {
				path: "GrPending"
				}
				}
				},
				{
				name: "GrPendingPrcntg",
				template: {
				content: {
				path: "GrPendingPrcntg"
				}
				}
				},
				{
				name: "QualityInspSameday",
				template: {
				content: {
				path: "QualityInspSameday"
				}
				}
				},
				{
				name: "QualityInspSamedayPrcntg",
				template: {
				content: {
				path: "QualityInspSamedayPrcntg"
				}
				}
				},
				{
				name: "QualityInspTend",
				template: {
				content: {
				path: "QualityInspTend"
				}
				}
				},
				{
				name: "QualityInspTendPrcntg",
				template: {
				content: {
				path: "QualityInspTendPrcntg"
				}
				}
				},
				{
				name: "QualityInspPending",
				template: {
				content: {
				path: "QualityInspPending"
				}
				}
				},{
				name: "QualityInspPendingPrcntg",
				template: {
				content: {
				path: "QualityInspPendingPrcntg"
				}
				}
				},
				{
				name: "PutawaySameday",
				template: {
				content: {
				path: "PutawaySameday"
				}
				}
				},
				{
				name: "PutawaySamedayPrcntg",
				template: {
				content: {
				path: "PutawaySamedayPrcntg"
				}
				}
				},
				{
				name: "PutawayTend",
				template: {
				content: {
				path: "PutawayTend"
				}
				}
				},
				{
				name: "PutawayTendPrcntg",
				template: {
				content: {
				path: "PutawayTendPrcntg"
				}
				}
				},
				{
				name: "PutawayPending",
				template: {
				content: {
				path: "PutawayPending"
				}
				}
				},
				{
				name: "PutawayPendingPrcntg",
				template: {
				content: {
				path: "PutawayPendingPrcntg"
				}
				}
				}
				];
			}else{
				var	acolumns = [
				{
				name: "TotPoNo",
				template: {
				content: {
				path: "TotPoNo"
				}
				}
				},
				{
				name: "TotPoItem",
				template: {
				content: {
				path: "TotPoItem"
				}
				}
				},
				{
				name: "GrSameday",
				template: {
				content: {
				path: "GrSameday"
				}
				}
				},
				{
				name: "GrSamedayPrcntg",
				template: {
				content: {
				path: "GrSamedayPrcntg"
				}
				}
				},
				{
				name: "GrTend",
				template: {
				content: {
				path: "GrTend"
				}
				}
				},
				{
				name: "GrTendPrcntg",
				template: {
				content: {
				path: "GrTendPrcntg"
				}
				}
				},
				{
				name: "GrPending",
				template: {
				content: {
				path: "GrPending"
				}
				}
				},
				{
				name: "GrPendingPrcntg",
				template: {
				content: {
				path: "GrPendingPrcntg"
				}
				}
				},
				{
				name: "QualityInspSameday",
				template: {
				content: {
				path: "QualityInspSameday"
				}
				}
				},
				{
				name: "QualityInspSamedayPrcntg",
				template: {
				content: {
				path: "QualityInspSamedayPrcntg"
				}
				}
				},
				{
				name: "QualityInspTend",
				template: {
				content: {
				path: "QualityInspTend"
				}
				}
				},
				{
				name: "QualityInspTendPrcntg",
				template: {
				content: {
				path: "QualityInspTendPrcntg"
				}
				}
				},
				{
				name: "QualityInspPending",
				template: {
				content: {
				path: "QualityInspPending"
				}
				}
				},{
				name: "QualityInspPendingPrcntg",
				template: {
				content: {
				path: "QualityInspPendingPrcntg"
				}
				}
				}
				
				];
			}
		/**********************column heading end*******************************/
		
			var getAuthorityModel = sap.ui.getCore().getModel("oAuthorityModel");
		//	console.log(getAuthorityModel);
			var oExport = new sap.ui.core.util.Export({
				exportType: new  sap.ui.core.util.ExportTypeCSV({
				separatorChar: "\t",
				
				mimeType: "application/vnd.ms-excel" ,
				charset: "utf-8" ,
				fileExtension: "xls"
				
				}),
				models: getAuthorityModel,
				rows: {
				path: "/" 
				},
				
				// column definitions with column name and binding info for the content
				columns: acolumns
				
			});
			oExport.saveFile().catch(function(oError) {
			//Handle your error
			}).then(function() {
			oExport.destroy();
			});
		}
      /*******************************end**********************************************************************/
	
	});

});