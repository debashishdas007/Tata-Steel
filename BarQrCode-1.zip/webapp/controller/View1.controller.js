sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("BarQrCode.controller.View1", {
		
		
		onBarCodeScan:function(evt){
			var that = this;
			var code = "";
			try{
				cordova.plugins.barcodeScanner.scan(
				  function (result) {
				  alert("We got a barcode\n" +
				  "Result: " + result.text + "\n" +
				  "Format: " + result.format + "\n" +
				  "Cancelled: " + result.cancelled);
				  }, 
				  function (error) {
				  alert("Scanning failed: " + error);
				  }
				  );
				
			}catch(e){
				
			}
		}

	});
});