sap.ui.define([
	"com/tatasteel/ZTSLFI_CT03/test/unit/controller/Card.controller"
], function () {
	"use strict";
});