sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"./InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, Export, ExportTypeCSV, InitPageUtil) {
	"use strict";
	var globalData = " ";
	return Controller.extend("com.tatasteel.ZTSLFI_CT03.controller.Card", {
		onInit: function () {
			//entity = "et_monthlyprojvsactualpayments";
			//var viewModel = " ";
			sap.ui.core.BusyIndicator.show();
			this.fetchEtMonthlyProjVsActualPayments();
		},

		fetchEtMonthlyProjVsActualPayments: function () {
			//  ============== This section is for *** ET_MonthlyProjVsActualPaymentsSet *** ====================
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_MonthlyProjVsActualPaymentsSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						monthlyProjVsActualPaymentsModel: oData.results
					});
					globalData = dataModel;
					that.et_monthlyProjVsActualPayments(dataModel);
					sap.ui.core.BusyIndicator.hide();

				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});

			//  ============== End of section for *** ET_MonthlyProjVsActualPaymentsSet *** ====================
		},

		et_monthlyProjVsActualPayments: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 2,
					values: [{
						name: "2 Series",
						value: ["Monthly Proj", "Actuals"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Month",
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Monthly Proj",
					value: "{Monthly_Proj}"
				}, {
					name: "Actuals",
					value: "{Actuals}"
				}]
			};

			var id_oVizFrame = null;

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.id_oVizFrame = this.getView().byId("idVizFrame_monthlyProjVsActualPayments");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.STANDARDINTEGER,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Monthly Projection Vs Monthly Actuals"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_monthlyProjVsActualPayments");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel2", "chartFixFlex2", "idVizFrame_monthlyProjVsActualPayments", " ",
				this);

		},

		excelDownload: function () {
			//alert('shifhsdf');
			//console.log(globalData);

			var aCols;
			aCols = this.createColumnConfig();
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				models: globalData,
				rows: {
					path: "/monthlyProjVsActualPaymentsModel"
				},
				// column definitions with column name and binding info for the content
				columns: aCols

			});
			oExport.saveFile("card03").catch(function (oError) {
				//Handle your error
				//console.log(oError);
			}).then(function () {
				oExport.destroy();
			});

		},
		createColumnConfig: function () {
			return [{
				name: "Month",
				template: {
					content: {
						path: "Month"
					}
				}
			}, {
				name: "Monthly Actuals",
				template: {
					content: {
						path: "Actuals"
					}
				}
			}, {
				name: "Monthly Projection",
				template: {
					content: {
						path: "Monthly_Proj"
					}
				}
			}];
		}

	});
});