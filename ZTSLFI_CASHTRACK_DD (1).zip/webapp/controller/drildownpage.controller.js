sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"./InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, InitPageUtil) {
	"use strict";

	//  https://sapui5.hana.ondemand.com/sdk/test-resources/sap/viz/demokit/dataset/milk_production_testing_data/revenue_cost_consume/betterMedium.json

	var entity = " ";

	return Controller.extend("com.tatasteel.ZTSLFI_CASHTRACK_DD.controller.drildownpage", {
		onInit: function () {
			entity = "et_collection_display";
			var viewModel = " ";

			if (entity === "et_collection_display") {
				this.deleteOtherPanels("et_collection_display");
				this.fetchEtCollectionDisplay();
			} else if (entity === "et_monthlyprojvsactualpayments") {
				this.deleteOtherPanels("et_monthlyprojvsactualpayments");
				this.fetchEtMonthlyProjVsActualPayments();
			} else if (entity === "et_actualcollvsactualpayment") {
				this.deleteOtherPanels("et_actualcollvsactualpayment");
				this.fetchEtActualCollVsActualPayment();
			} else if (entity === "et_monthlyprojvsactualcollection" || entity === "et_dailyprojvsactualcollection" || entity ===
				"et_paymentsmnthvsactualdiff") {
				this.deleteOtherPanels("et_threeinone");
				if (entity === "et_monthlyprojvsactualcollection") {
					viewModel = new sap.ui.model.json.JSONModel({
						title: "Collection(6 Months in Cr)"
					});
					this.getView().byId("et_threeinone").setModel(viewModel);
					this.fetchET_ThreeInOneSet("/ET_MonthlyProjVsActualCollectionSet");

				} else if (entity === "et_dailyprojvsactualcollection") {
					viewModel = new sap.ui.model.json.JSONModel({
						title: "Collection(6 Months in Cr)"
					});
					this.getView().byId("et_threeinone").setModel(viewModel);
					this.fetchET_ThreeInOneSet("/ET_DailyProjvsActualCollectionSet");

				} else {
					viewModel = new sap.ui.model.json.JSONModel({
						title: "Payments (6 Months in Cr)",
						subtitle: "Monthly Proj Vs Actuals"
					});
					this.getView().byId("et_threeinone").setModel(viewModel);
					this.fetchET_ThreeInOneSet("/ET_PaymentsMnthVsActualDiffSet");
				}
			} else if (entity === "et_totalactualcollection") {
				this.deleteOtherPanels("et_totalactualcollection");
				this.fetchET_TotalActualCollection();
			} else if (entity === "et_totalactualpayment") {
				this.deleteOtherPanels("et_totalactualpayment");
				this.fetchET_TotalActualPayment();
			} else if (entity === "et_actualcollection") {
				this.deleteOtherPanels("et_actualcollection");
				this.fetchET_ActualCollection();
			} else if (entity === "et_actualpayments") {
				this.deleteOtherPanels("et_actualpayments");
				this.fetchET_ActualPayments();
			}
			return false;

		},

		fetchEtCollectionDisplay: function () {
			//  ============== This section is for *** ET_Collection_DisplaySet *** ====================

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_Collection_DisplaySet", {
				success: function (oData, response) {
					//var results = oData.results; 

					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						jsonModel: oData.results
					});
					//var dataModel = [];
					// for (var i = 0; i < results.length; i++) {
					// 	var data = {
					// 		"Mnth": results[i].Mnth,
					// 		"Manthly_Proj": results[i].Manthly_Proj,
					// 		"Daily_Proj": results[i].Daily_Proj,
					// 		"Actuals": results[i].Actuals
					// 	};
					// 	dataModel.push(data);
					// }
					// var jsonModel = {
					// 	"jsonModel": dataModel
					// };
					//globalData = jsonModel;
					that.et_collection_display(dataModel);
				},
				error: function (oError) { //read error}
				}
			});
			//this.getView().byId('et_monthlyprojvsactualpayments').removeAllContent();
			//this.getView().byId('et_monthlyprojvsactualpayments').destroy();

			//  ============== End of section for *** ET_Collection_DisplaySet *** ====================
		},

		et_collection_display: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [
						// {
						// 	name: "Small",
						// 	value: "/betterSmall.json"
						// }, {
						// 	name: "Medium",
						// 	value: "/betterMedium.json"
						// }, 
						{
							name: "Large",
							value: "/betterLarge.json"
						}
					]
				},
				series: {
					name: "Series",
					defaultSelected: 2,
					values: [
						// {
						// 	name: "1 Series",
						// 	value: ["Manthly_Proj"]
						// }, 
						{
							name: "2 Series",
							value: ["Manthly_Proj", "Daily_Proj", "Actuals"]
						}
					]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					// Small: [{
					// 	name: "Seasons",
					// 	value: "{Seasons}"
					// }],
					// Medium: [{
					// 	name: "Week",
					// 	value: "{Week}"
					// }],
					Large: [{
						name: "Mnth",
						value: "{Mnth}"
					}]
				},
				measures: [{
					name: "Manthly",
					value: "{Manthly_Proj}"
				}, {
					name: "Daily_Proj",
					value: "{Daily_Proj}",
				}, {
					name: "Actuals",
					value: "{Actuals}",
				}]
			};

			var id_oVizFrame = null;

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.id_oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Monthly Proj, Daily Proj and Actuals by Mnth"
				}
			});
			// var dataModel = new JSONModel(this.dataPath + "/betterMedium.json");
			// var dataModel = new JSONModel(
			// 	"https://sapui5.hana.ondemand.com/sdk/test-resources/sap/viz/demokit/dataset/milk_production_testing_data/revenue_cost_consume/betterMedium.json"
			// );

			// var dataModel = new JSONModel({
			// 	"milk": [{
			// 		"Mnth": "Aug-18",
			// 		"Manthly_Proj": 6481,
			// 		"Daily_Proj": 230000.00
			// 	}, {
			// 		"Mnth": "Sep-18",
			// 		"Manthly_Proj": 7157,
			// 		"Daily_Proj": 238000.00
			// 	}, {
			// 		"Mnth": "Oct-18",
			// 		"Manthly_Proj": 7171,
			// 		"Daily_Proj": 221000.00
			// 	}, {
			// 		"Mnth": "Nov-18",
			// 		"Manthly_Proj": 0,
			// 		"Daily_Proj": 280000.00
			// 	}, {
			// 		"Mnth": "Dec-18",
			// 		"Manthly_Proj": 0,
			// 		"Daily_Proj": 230000.00
			// 	}, {
			// 		"Mnth": "Jan-19",
			// 		"Manthly_Proj": 0,
			// 		"Daily_Proj": 250000.00
			// 	}]
			// });

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel1", "chartFixFlex1", "idVizFrame");

		},

		fetchEtMonthlyProjVsActualPayments: function () {
			//  ============== This section is for *** ET_MonthlyProjVsActualPaymentsSet *** ====================
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_MonthlyProjVsActualPaymentsSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						monthlyProjVsActualPaymentsModel: oData.results
					});
					that.et_monthlyProjVsActualPayments(dataModel);
				},
				error: function (oError) { //read error}
				}
			});
			//this.getView().byId('et_collection_display').removeAllContent();
			//this.getView().byId('et_collection_display').destroy();
			//  ============== End of section for *** ET_MonthlyProjVsActualPaymentsSet *** ====================
		},

		et_monthlyProjVsActualPayments: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 2,
					values: [{
						name: "2 Series",
						value: ["Monthly Proj", "Actuals"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Month",
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Monthly Proj",
					value: "{Monthly_Proj}"
				}, {
					name: "Actuals",
					value: "{Actuals}"
				}]
			};

			var id_oVizFrame = null;

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.id_oVizFrame = this.getView().byId("idVizFrame_monthlyProjVsActualPayments");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: 'Monthly Proj Vs Actuals'
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_monthlyProjVsActualPayments");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel2", "chartFixFlex2", "idVizFrame_monthlyProjVsActualPayments");

		},

		fetchEtActualCollVsActualPayment: function () {
			//  ============== This section is for *** ET_ActualCollVsActualPaymentSet *** ====================

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_ActualCollVsActualPaymentSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						actualcollvsactualpaymentModel: oData.results
					});

					that.et_actualcollvsactualpayment(dataModel);
				},
				error: function (oError) { //read error}
				}
			});

			//  ============== End of section for *** ET_ActualCollVsActualPaymentSet *** ====================
		},

		et_actualcollvsactualpayment: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 2,
					values: [{
						name: "2 Series",
						value: ["Collection", "Payment"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Month",
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Collection",
					value: "{Collection}"
				}, {
					name: "Payment",
					value: "{Payment}"
				}]
			};

			var id_oVizFrame = null;

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = id_oVizFrame = this.getView().byId("idVizFrame_actualcollvsactualpayment");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: 'Collection and Payment by Month'
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_actualcollvsactualpayment");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel3", "chartFixFlex3", "idVizFrame_actualcollvsactualpayment");
		},

		fetchET_ThreeInOneSet: function (entitySet) {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read(entitySet, {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						threeInOneModel: oData.results
					});
					that.etThreeInOne(dataModel);
				},
				error: function (oError) { //read error}
				}
			});
		},

		etThreeInOne: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					enabled: false,
					values: [{
						name: "2 Series",
						value: ["Projection_Diff", "Variance"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: true
				},
				chartType: {
					name: "Chart Type",
					defaultSelected: 0,
					values: [{
						name: "Column + Line",
						vizType: "combination",
						value: ["Projection_Diff", "Variance"]
					}]
				},
				dimensions: {
					Large: [{
						name: 'Month',
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Projection_Diff",
					value: "{Projection_Diff}"
				}, {
					name: "Variance",
					value: "{Variance}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var cardSubtitle = "";

			if (entity === "et_monthlyprojvsactualcollection")
				cardSubtitle = "Monthly Proj Vs Actuals";
			else if (entity === "et_dailyprojvsactualcollection")
				cardSubtitle = "Daily Proj Vs Actuals";
			else
				cardSubtitle = "Projection and Actual Difference";

			var oVizFrame = this.getView().byId("idVizFrame_threeinone");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					},
					dataShape: {
						primaryAxis: ["bar", "line"]
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: cardSubtitle
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_threeinone");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel4", "chartFixFlex4", "idVizFrame_threeinone", 1);

		},

		fetchET_TotalActualCollection: function () {
			//  ============== This section is for *** ET_MonthlyProjVsActualPaymentsSet *** ====================
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_TotalActualCollectionSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						totalActualCollectionModel: oData.results
					});
					that.et_totalActualCollection(dataModel);
				},
				error: function (oError) { //read error}
				}
			});
		},

		et_totalActualCollection: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					values: [{
						name: "1 Series",
						value: ["Monthly_Collection"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Month",
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Monthly Collection",
					value: "{Monthly_Collection}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrame_totalActualCollection");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Monthly Collection by month"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_totalActualCollection");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel5", "chartFixFlex5", "idVizFrame_totalActualCollection");
		},

		fetchET_TotalActualPayment: function () {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_TotalActualPaymentSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						totalActualPaymentModel: oData.results
					});
					that.et_totalActualPayment(dataModel);
				},
				error: function (oError) { //read error}
				}
			});
		},

		et_totalActualPayment: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					values: [{
						name: "1 Series",
						value: ["Payment"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Month",
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Paymentt",
					value: "{Payment}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrame_totalActualPayment");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Payment by Month"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_totalActualPayment");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel6", "chartFixFlex6", "idVizFrame_totalActualPayment");
		},

		fetchET_ActualCollection: function () {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_ActualCollectionSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						actualCollectionModel: oData.results
					});
					that.et_actualCollection(dataModel);
				},
				error: function (oError) { //read error}
				}
			});
		},

		et_actualCollection: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					values: [{
						name: "1 Series",
						value: ["Collection"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Month",
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Particulars",
					value: "{Particulars}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrame_actualCollection");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Collection by Particulars"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_actualCollection");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel7", "chartFixFlex7", "idVizFrame_actualCollection");
		},

		fetchET_ActualPayments: function () {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_ActualPaymentsSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						actualPaymentsModel: oData.results
					});
					that.et_actualPayments(dataModel);
				},
				error: function (oError) { //read error}
				}
			});
		},

		et_actualPayments: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					values: [{
						name: "1 Series",
						value: ["Payments"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Particulars",
						value: "{Particulars}"
					}]
				},
				measures: [{
					name: "Payments",
					value: "{Payments}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrame_actualPayments");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Payments by Particulars"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_actualPayments");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel8", "chartFixFlex8", "idVizFrame_actualPayments");
		},

		deleteOtherPanels: function (panelId) {
			var arrayOfPanel = ["et_collection_display", "et_monthlyprojvsactualpayments", "et_actualcollvsactualpayment", "et_threeinone",
				"et_totalactualcollection", "et_totalactualpayment", "et_actualcollection", "et_actualpayments"
			];
			// var arrayOfPanel = [ "et_actualcollection", "et_actualpayments"];
			for (var i = 0; i < arrayOfPanel.length; i++) {
				if (panelId !== arrayOfPanel[i]) {
					this.getView().byId(arrayOfPanel[i]).destroy();
				}
			}

		}

	});
});