sap.ui.define(["jquery.sap.global"],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var MRDetailsPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "MRPStatisticsApp-tblPRDetails-PRDetMonth",
					order: 0,
					text: "Month",
					visible: true
				},
				// , {
				// 	id: "MRPStatisticsApp-tblPRDetails-PRDetYear",
				// 	order: 1,
				// 	text: "Year",
				// 	visible: true
				// },
				{
					id: "MRPStatisticsApp-tblPRDetails-PRDetMatNo",
					order: 2,
					text: "Mat No",
					visible: true
				},{
					id: "MRPStatisticsApp-tblPRDetails-PRDetPlant",
					order: 3,
					text: "Plant",
					visible: true
				}, {
					id: "MRPStatisticsApp-tblPRDetails-PRDetBGG",
					order: 4,
					text: "BGG",
					visible: true
				}, {
					id: "MRPStatisticsApp-tblPRDetails-PRDetPRNo",
					order: 5,
					text: "PR No",
					visible: true
				},
				{
					id: "MRPStatisticsApp-tblPRDetails-PRDetPONo",
					order: 6,
					text: "PO No",
					visible: true
				},
				{
					id: "MRPStatisticsApp-tblPRDetails-PRDetMatDesc",
					order: 7,
					text: "Mat Desc",
					visible: true
				},
				{
					id: "MRPStatisticsApp-tblPRDetails-PRDetBGGDesc",
					order: 8,
					text: "BGG Desc",
					visible: false
				},
					{
					id: "MRPStatisticsApp-tblPRDetails-PRDetPlantDesc",
					order: 9,
					text: "Plant Desc",
					visible: true
			
				}
				,
					{
					id: "MRPStatisticsApp-tblPRDetails-PRDetPRDt",
					order: 10,
					text: "PR Date",
					visible: true
			
				},
				{
					id: "MRPStatisticsApp-tblPRDetails-PRDetDODt",
					order: 11,
					text: "DO Date",
					visible: true
			
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "demoApp-productsTable-productCol",
						order: 0,
						text: "Product",
						visible: true
					}, {
						id: "demoApp-productsTable-supplierCol",
						order: 1,
						text: "Supplier",
						visible: false
					}, {
						id: "demoApp-productsTable-dimensionsCol",
						order: 4,
						text: "Dimensions",
						visible: false
					}, {
						id: "demoApp-productsTable-weightCol",
						order: 2,
						text: "Weight",
						visible: true
					}, {
						id: "demoApp-productsTable-priceCol",
						order: 3,
						text: "Price",
						visible: true
					}]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			}

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			// getCaption : function (oColumn) {
			// 	if (oColumn.getHeader() && oColumn.getHeader().getText) {
			// 		if (oColumn.getHeader().getText() === "Weight") {
			// 			return "Weight (Important!)";
			// 		}
			// 	}
			// 	return null;
			// },

			// getGroup : function(oColumn) {
			// 	if ( oColumn.getId().indexOf('productCol') != -1 ||
			// 			oColumn.getId().indexOf('supplierCol') != -1) {
			// 		return "Primary Group";
			// 	}
			// 	return "Secondary Group";
			// }
		};

		return MRDetailsPersoService;

	}, /* bExport= */ true);