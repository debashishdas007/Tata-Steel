sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/m/TablePersoController", "./CoverageDetailsPersoService", "sap/m/MessageBox",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV"
], function(Controller, TablePersoController, CoverageDetailsPersoService, MessageBox, Export, ExportTypeCSV) {
	"use strict";

	return Controller.extend("com.sap.tsl.mrpStatisticsMRPStatistics.controller.CoverageDetails", {
		onInit: function() {

			this._oTPC = new TablePersoController({
				table: this.getView().byId("tblCoverageDetails"),
				//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
				componentName: "MRPStatisticsApp",
				persoService: CoverageDetailsPersoService
			}).activate();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("CoverageDetails").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_P2P_MRPSTATISTICS_SRV/");
			var filters = new Array();
			var oParameters = oEvent.getParameters();
			//get the filters passed from StockPODetails page//
			filters = JSON.parse(oParameters.arguments.filterPath);
			sap.ui.core.BusyIndicator.show(0);
			var oTable = this.getView().byId("tblCoverageDetails");
			var that = this;
			var oLblPlantBGGDetails = that.getView().byId("oLblPlantBGGDetails");
			oLblPlantBGGDetails.setText(" for Plant " + filters[0].oValue1.toString() + " Material Group " + filters[1].oValue1.toString());
			oModel.read("/ET_CoverageDetailsSet", {
				filters: filters,
				success: function(oData, response) {
					oTable.setVisible(true);

					var value = [];
					value = oData.results;
					var oModelCoverageDetails = new sap.ui.model.json.JSONModel();
					oModelCoverageDetails.setData({
						ET_CoverageDetailsSet: value
					});

					//  Added by debashish on 06.08.2018
					var coverageDetailsData = oModelCoverageDetails.oData.ET_CoverageDetailsSet;
					var coverageDetailsModel = new sap.ui.model.json.JSONModel(coverageDetailsData);
					sap.ui.getCore().setModel(coverageDetailsModel, "coverageDetailsModel");
					//  End of Addition by debashish on 06.08.2018

					var oLblNoOfRows = that.getView().byId("oLblNoOfRows");
					oLblNoOfRows.setText("Total records: " + value.length);

					//column list item creation
					var oTemplate = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({
							text: "{Month}-{Year}"
								// }), new sap.m.Text({
								// 	text: "{Year}"
						}), new sap.m.Text({
							text: "{MaterialNumber}"
						}), new sap.m.Text({
							text: "{Plant}"
						}), new sap.m.Text({
							text: "{BGG}"

						}), new sap.m.Text({
							text: "{PoNo}"
						}), new sap.m.Text({
							text: "{MaterialDescription}"
						}).bindProperty("text", {
							parts: [{
									path: "MaterialDescription"

								}

							],
							formatter: function(MaterialDescription) {

								this.addStyleClass("descriptionclass");

								return MaterialDescription;

							}
						}), new sap.m.Text({
							text: "{BGGDescription}"
						}).bindProperty("text", {
							parts: [{
									path: "BGGDescription"

								}

							],
							formatter: function(BGGDescription) {

								this.addStyleClass("descriptionclass");

								return BGGDescription;

							}
						}), new sap.m.Text({
							text: "{PlantDescription}"
						}).bindProperty("text", {
							parts: [{
									path: "PlantDescription"

								}

							],
							formatter: function(PlantDescription) {

								this.addStyleClass("descriptionclass");

								return PlantDescription;

							}
						}), new sap.m.Text({
							text: {
								path: "PRDate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						}), new sap.m.Text({
							text: "{Vendor}"
						}), new sap.m.Text({
							text: {
								path: "KStartDate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						}), new sap.m.Text({
							text: {
								path: "KEndDate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						})]
					});
					oTable.setModel(oModelCoverageDetails);
					sap.ui.getCore().setModel(oModelCoverageDetails, "oModelCoverageDetails");

					oTable.bindAggregation("items", {
						path: "/ET_CoverageDetailsSet",
						template: oTemplate
					});
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(oError) { //read error}
					//sap.m.MessageToast.show("Error Fetching data");
					var bCompacterror = !!that.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.information(
						oError.message, {
							styleClass: bCompacterror ? "sapUiSizeCompact" : ""
						}
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		// init and activate controller

		onPersoButtonPressedCoverageDetails: function(oEvent) {
			this._oTPC.openDialog();
		},

		onPressBack: function(evt) {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("MRPStatistics");

		},
		//   ******* Excel Download added by debashish 6.8.2018 ********
		onExport: function() {
			var getcoverageDetailsModel = sap.ui.getCore().getModel("coverageDetailsModel");
			var acolumns = this.createColumnConfig();
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				models: getcoverageDetailsModel,
				rows: {
					path: "/"
				},

				// column definitions with column name and binding info for the content
				columns: acolumns

			});
			oExport.saveFile("CoverageDetails").catch(function(oError) {
				//Handle your error
			}).then(function() {
				oExport.destroy();
			});

		},
		createColumnConfig: function() {
				var acolumns = [{
						name: "Month-Year",
						template: {
							content: {
								parts: ["Month", "Year"],
								formatter: function(Month, Year) {
									return Month + " - " + Year;
								}
							}
						}
					}, {
						name: "Material Number",
						template: {
							content: {
								path: "MaterialNumber"
							}
						}
					}, {
						name: "Plant",
						template: {
							content: {
								path: "Plant"
							}
						}
					}, {
						name: "BGG",
						template: {
							content: {
								path: "BGG"
							}
						}
					}, {
						name: "PoNo",
						template: {
							content: {
								path: "PoNo"
							}
						}
					}, {
						name: "Material Description",
						template: {
							content: {
								path: "MaterialDescription"
							}
						}
					}, {
						name: "BGG Description",
						template: {
							content: {
								path: "BGGDescription"
							}
						}
					}, {
						name: "Plant Description",
						template: {
							content: {
								path: "PlantDescription"
							}
						}
					}, {
						name: "PR Date",
						template: {
							content: {
								path: "PRDate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						}
					}, {
						name: "Vendor",
						template: {
							content: {
								path: "Vendor"
							}
						}
					}, {
						name: "Validity Start Date",
						template: {
							content: {
								path: "KStartDate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						}
					}, {
						name: "Validity End Date",
						template: {
							content: {
								path: "KEndDate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						}
					}
				];

				return acolumns;

			}
		//   ******* End of Excel Download added by debashish 6.8.2018 ********		
	});
});