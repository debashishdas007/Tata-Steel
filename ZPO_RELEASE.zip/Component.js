sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/sap/tatasteel/zporelease/model/models",
	"sap/ui/model/resource/ResourceModel"
], function(UIComponent, Device, models, ResourceModel) {
	"use strict";
	return UIComponent.extend("com.sap.tatasteel.zporelease.Component", {
		/*metadata: {
			manifest: "json"
		},*/
		metadata: {
			"version": "1.0.0",
			"rootView": {
				"viewName": "com.sap.tatasteel.zporelease.view.App",
				"type": "XML",
				"id": "app"
			},
			"includes": ["css/style.css"],
			"dependencies": {
				"libs": [
					"sap.ui.core",
					"sap.m",
					"sap.ui.layout"
				]
			},
			"config": {
				"i18nBundle": "com.sap.tatasteel.zporelease.i18n.i18n",
				"serviceConfig": {
					"name": "YMPI_PO_DETAILS1_SRV",
					"serviceUrl": "/sap/opu/odata/sap/YMPI_PO_DETAILS1_SRV/"
				},
				"icon": "",
				"favIcon": "",
				"phone": "",
				"phone@2": "",
				"tablet": "",
				"tablet@2": ""
			},
			"routing": {
				"config": {
					"routerClass": "sap.m.routing.Router",
					"viewType": "XML",
					"viewPath": "com.sap.tatasteel.zporelease.view",
					"controlId": "app",
					"controlAggregation": "pages",
					"bypassed": {
						"target": "notFound"
					}
				},
				"routes": [{
					"pattern": "",
					"name": "master",
					"target": "master"
				}, {
					"pattern": "ItDetailsSet/{objectId}",
					"name": "detail",
					"target": "detail"
				}],
				"targets": {
					"master": {
						"viewName": "Master",
						"viewId": "Master",
						"viewLevel": 1
					},
					"detail": {
						"viewName": "Detail",
						"viewId": "Detail",
						"viewLevel": 1
					},
					"object": {
						"viewName": "Object",
						"viewId": "object",
						"viewLevel": 2
					},
					"objectNotFound": {
						"viewName": "ObjectNotFound",
						"viewId": "objectNotFound"
					},
					"notFound": {
						"viewName": "NotFound",
						"viewId": "notFound"
					}
				}
			}
		},
		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			var mConfig = this.getMetadata().getConfig();
			var oAppModel = models.createODataModel({
				urlParametersForEveryRequest: [
					"sap-server",
					"sap-client",
					"sap-language"
				],
				url: mConfig.serviceConfig.serviceUrl,
				config: {
					metadataUrlParams: {
						"sap-documentation": "heading"
					},
					json: true,
					defaultBindingMode: "TwoWay",
					defaultCountMode: "Inline",
					useBatch: true
				}
			});
			this.setModel(oAppModel);
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var i18nModel = new ResourceModel({
				bundleName: "com.sap.tatasteel.zporelease.i18n.i18n"
			});
			this.setModel(i18nModel, "i18n");
			// create the views based on the url/hash
			this.getRouter().initialize();
		}
	});
});