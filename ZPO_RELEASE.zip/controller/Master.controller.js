sap.ui.define([
	"com/sap/tatasteel/zporelease/controller/BaseController", "sap/ui/core/mvc/Controller", "sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator", "com/sap/tatasteel/zporelease/model/formatter", "sap/ui/model/resource/ResourceModel",
	"sap/ui/Device",
	'sap/m/MessageBox',
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog"
], function(BaseController, Controller, MessageToast, JSONModel, Filter, FilterOperator, formatter, ResourceModel, Device, MessageBox,
	ValueHelpDialog) {
	"use strict";
	var _timeout;
	var thatDialog = null;
	var oValueHelpDialog = null;
	var aTokens = [];
	var that = this;
	var advanceSearchFilters = [];
	//var linkEvent = null;
	return BaseController.extend("com.sap.tatasteel.zporelease.controller.Master", {
		formatter: formatter,
		// onPressRelease: function() {
		// 	var oList = this.byId("list");
		// 	var listItems = oList.getItems();
		// 	var iSuccess = 0;
		// 	var iFail = 0;
		// 	var successStatusMsg = "";
		// 	var t=0;

		// 	// instantiate dialog
		// 	// if (!this._dialog) {
		// 	// 	this._dialog = sap.ui.xmlfragment("com.sap.tatasteel.zporelease.view.BusyDialog", this);
		// 	// 	this.getView().addDependent(this._dialog);
		// 	// }
		// 	// open dialog
		// 	// jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
		// 	// this._dialog.open();

		// 	// simulate end of operation
		// 	// _timeout = jQuery.sap.delayedCall(300000, this, function() {
		// 	// 	this._dialog.close();
		// 	// });

		// 	function ErrorCount(successStatusMsg,t) {
		// 		if (successStatusMsg !== "") {
		// 			if (successStatusMsg !== "Success") {
		// 				iFail++;
		// 			} 
		// 		}

		// 		if (t === listItems.length)
		// 		{
		// 		if (iFail > 0) {
		// 		sap.m.MessageBox.show(
		// 			"Some Purchase order could not be released successfully.", {
		// 				icon: sap.m.MessageBox.Icon.SUCCESS,
		// 				title: "Partial Success",
		// 				actions: [sap.m.MessageBox.Action.OK]
		// 			}
		// 		);
		// 	} else {
		// 		sap.m.MessageBox.show(
		// 			"Listed Purchase order released successfully.", {
		// 				icon: sap.m.MessageBox.Icon.SUCCESS,
		// 				title: "Success",
		// 				actions: [sap.m.MessageBox.Action.OK]
		// 			}
		// 		);
		// 	}
		// 	}
		// //	t = this;
		// 	for (var i = 0, len = listItems.length; i < len; i++) {
		// 		this.getView().getModel().callFunction(
		// 			"ReleasePO",
		// 			"GET", {
		// 				"ebeln": listItems[i].getTitle()
		// 			},
		// 			null,
		// 			function(oData, response) {
		// 				successStatusMsg = oData.ReleasePO.ReturnText;
		// 				t=i;

		// 			//	t.ErrorCount(successStatusMsg);
		// 			}.bind(ErrorCount(successStatusMsg,t)), // callback function for success
		// 			function(oError) {}, false);
		// 	}

		// 	}

		// 	//	this.getView().getElementBinding().refresh(true);
		// 	//  oList.Items.clear();
		// 	// var oViewModel = sap.ui.getCore().getModel("listModel");
		// 	// 	oViewModel.refresh(true);
		// 	// 	oViewModel.updateBindings(true);

		// 	// 	this.getView().setModel(oViewModel, "listModel");
		// 	// 	var emptyDataModel = new sap.ui.model.json.JSONModel();
		// 	// 	if (emptyDataModel) {
		// 	// 		emptyDataModel.setData(null);
		// 	// 		emptyDataModel.updateBindings(true);
		// 	// 	}
		// 	// 	oList.setModel(emptyDataModel);

		// 	//		this.onBtnSearchClick();
		// 	// 	oList.getBinding("items").refresh(true);

		// 	// var oList = this.getView().byId("list");
		// 	//

		// },
		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = sap.ui.getCore().getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			//oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			//oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			//oViewModel.setProperty("/delay", iOriginalViewBusyDelay);

		},
		// ***** Added by Debashish ****** //
		showValueHelpPlant: function() {
			oValueHelpDialog = null;
			var multiInputPlant = this.getView().byId("multiInputPlant");
			//var that = this;
			if (multiInputPlant.getTokens().length <= 0) {
				that.plantTableValue = null;
			}
			oValueHelpDialog = new ValueHelpDialog({
				supportRanges: true,
				title: "Plant",
				key: "WERKS",
				descriptionKey: "NAME1",
				tokenDisplayBehaviour: "WERKS",
				ok: function(oControlEvent) {
					aTokens = oControlEvent.getParameter("tokens");
					var sTokens = "";
					for (var i = 0; i < aTokens.length; i++) {
						var oToken = aTokens[i];
						sTokens += oToken.getText() + " ";
					}

					multiInputPlant.setTokens(aTokens);
					if (!that.plantTableValue) {
						that.plantTableValue = oValueHelpDialog.getTable().getModel().getData();
					}
					oValueHelpDialog.close();
					oValueHelpDialog = null;

				},
				cancel: function(oControlEvent) {
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				afterClose: function() {
					this.destroy();
					oValueHelpDialog = null;
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
						label: "Plant",
						template: "WERKS"
					}, {
						label: "Description",
						template: "NAME1"
					}

				]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			if (!that.plantTableValue) {
				oValueHelpDialog.setBusy(true);
				// sap.ui.core.BusyIndicator.show();
				var oRowsModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMPI_PO_DETAILS1_SRV/");
				oRowsModel.read("/PlantSet", {
					//filters: filters,
					success: function(oData, response) {
						//	MessageToast.show(evt.getSource().getId() + " Pressed");
						var value = [];
						value = oData.results;
						var oModelPlant = new sap.ui.model.json.JSONModel();
						oModelPlant.setData(value);
						oValueHelpDialog.getTable().setModel(oModelPlant);
						if (oValueHelpDialog.getTable().bindRows) {
							oValueHelpDialog.getTable().bindRows("/");
						}
						if (multiInputPlant.getTokens().length > 0) {
							oValueHelpDialog.setTokens(multiInputPlant.getTokens());
						}
						oValueHelpDialog.setBusy(false);
						oValueHelpDialog.update();

					},
					error: function(oError) { //read error}
						sap.m.MessageToast.show("Error Fetching data");
					},
					beforeOpen: function(oControlEvent) {
						sap.m.MessageToast.show("Selection changed!");
					}
				});
			} else {
				var oModelPlant2 = new sap.ui.model.json.JSONModel();
				oModelPlant2.setData(that.plantTableValue);
				oValueHelpDialog.getTable().setModel(oModelPlant2);
				if (oValueHelpDialog.getTable().bindRows) {
					oValueHelpDialog.getTable().bindRows("/");
				}
				if (multiInputPlant.getTokens()) {
					oValueHelpDialog.setTokens(multiInputPlant.getTokens());
				}
				oValueHelpDialog.open();
				oValueHelpDialog.update();
			}

			oValueHelpDialog.setRangeKeyFields([{
				label: "Plant",
				key: "WERKS"
			}]);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				searchEnabled: false,
				showGoOnFB: false,
				showClearButton: true

			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					tooltip: "Search for Plant",
					placeholder: "Search",
					search: function(event) {
						var data = event.mParameters.query;
						var oFilters = new sap.ui.model.Filter({
							and: false,
							filters: [
								new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("WERKS", sap.ui.model.FilterOperator.Contains, data)
									]
								}),
								new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("NAME1", sap.ui.model.FilterOperator.Contains, data)
									]
								})
							]
						});
						// var oElement = sap.ui.getCore().byId("idValueHelpPlant").getTable();
						var oElement = oValueHelpDialog.getTable();
						oElement.getBinding("rows").filter([oFilters]);
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();

		},

		showValueHelpPurGrp: function() {
			oValueHelpDialog = null;
			var multiInputPurGrp = this.getView().byId("multiInputPurGrp");
			//var that = this;
			if (multiInputPurGrp.getTokens().length <= 0) {
				that.purGrpTableValue = null;
			}
			oValueHelpDialog = new ValueHelpDialog({
				supportRanges: true,
				title: "Purchase Group",
				key: "EKGRP",
				descriptionKey: "EKNAM",
				tokenDisplayBehaviour: "EKGRP",
				ok: function(oControlEvent) {
					aTokens = oControlEvent.getParameter("tokens");
					var sTokens = "";
					for (var i = 0; i < aTokens.length; i++) {
						var oToken = aTokens[i];
						sTokens += oToken.getText() + " ";
					}

					multiInputPurGrp.setTokens(aTokens);
					if (!that.purGrpTableValue) {
						that.purGrpTableValue = oValueHelpDialog.getTable().getModel().getData();
					}
					oValueHelpDialog.close();
					oValueHelpDialog = null;

				},
				cancel: function(oControlEvent) {
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				afterClose: function() {
					this.destroy();
					oValueHelpDialog = null;
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
						label: "Purchase Group",
						template: "EKGRP"
					}, {
						label: "Description",
						template: "EKNAM"
					}

				]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			if (!that.purGrpTableValue) {
				oValueHelpDialog.setBusy(true);
				var oRowsModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMPI_PO_DETAILS1_SRV/");
				oRowsModel.read("/PurchasingGroupSet", {
					success: function(oData, response) {
						var value = [];
						value = oData.results;
						var oModelPurGrp = new sap.ui.model.json.JSONModel();
						oModelPurGrp.setData(value);
						oValueHelpDialog.getTable().setModel(oModelPurGrp);
						if (oValueHelpDialog.getTable().bindRows) {
							oValueHelpDialog.getTable().bindRows("/");
						}
						if (multiInputPurGrp.getTokens().length > 0) {
							oValueHelpDialog.setTokens(multiInputPurGrp.getTokens());
						}
						oValueHelpDialog.setBusy(false);
						oValueHelpDialog.update();

					},
					error: function(oError) { //read error}
						sap.m.MessageToast.show("Error Fetching data");
					},
					beforeOpen: function(oControlEvent) {
						sap.m.MessageToast.show("Selection changed!");
					}
				});
			} else {
				var oModelPurGrp2 = new sap.ui.model.json.JSONModel();
				oModelPurGrp2.setData(that.purGrpTableValue);
				oValueHelpDialog.getTable().setModel(oModelPurGrp2);
				if (oValueHelpDialog.getTable().bindRows) {
					oValueHelpDialog.getTable().bindRows("/");
				}
				if (multiInputPurGrp.getTokens()) {
					oValueHelpDialog.setTokens(multiInputPurGrp.getTokens());
				}
				oValueHelpDialog.open();
				oValueHelpDialog.update();
			}

			oValueHelpDialog.setRangeKeyFields([{
				label: "Purchase Group",
				key: "EKGRP"
			}]);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				searchEnabled: false,
				showGoOnFB: false,
				showClearButton: true

			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					tooltip: "Search for Purchase Group",
					placeholder: "Search",
					search: function(event) {
						var data = event.mParameters.query;
						var oFilters = new sap.ui.model.Filter({
							and: false,
							filters: [
								new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("EKGRP", sap.ui.model.FilterOperator.Contains, data)
									]
								}),
								new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("EKNAM", sap.ui.model.FilterOperator.Contains, data)
									]
								})
							]
						});
						var oElement = oValueHelpDialog.getTable();
						oElement.getBinding("rows").filter([oFilters]);
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();

		},

		showValueHelpVendor: function() {
			oValueHelpDialog = null;
			//var that = this;
			advanceSearchFilters = [];
			var multiInputVendor = this.getView().byId("multiInputVendor");
			oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				supportRanges: true,
				title: "Vendor",
				key: "VendorNo",
				descriptionKey: "Name",
				tokenDisplayBehaviour: "VendorNo",
				ok: function(oControlEvent) {
					aTokens = oControlEvent.getParameter("tokens");
					multiInputVendor.setTokens(aTokens);
					// if (!this.vendorTableValue) {
					// 	this.vendorTableValue = oValueHelpDialog.getTable().getModel().getData();
					// }
					oValueHelpDialog.close();
					oValueHelpDialog = null;

				},
				cancel: function(oControlEvent) {
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				afterClose: function() {
					this.destroy();
					oValueHelpDialog = null;
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
						label: "Vendor",
						template: "VendorNo" //"LIFNR"
					}, {
						label: "Description",
						template: "Name"
					}

				]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			oValueHelpDialog.setRangeKeyFields([{
				label: "Vendor",
				key: "VendorNo"
			}]);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				//filterBarExpanded: false,
				searchEnabled: true,
				showGoOnFB: true,
				showClearButton: true,
				filterGroupItems: [
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "More Fields",
						groupName: "gn1",
						name: "n1",
						label: "Vendor Name",
						control: new sap.m.Input('Name'),
						visibleInFilterBar: false
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "More Fields",
						groupName: "gn1",
						name: "n2",
						label: "Vendor",
						control: new sap.m.Input('VendorNo'),
						visibleInFilterBar: false
					})
				],

				search: function(oEvent) {
					var aSearchItems = oEvent.getParameters().selectionSet;
					var sMsg;
					if (this.getBasicSearch()) {
						sMsg = sap.ui.getCore().byId(this.getBasicSearch()).getValue();
						for (var i = 0; i < aSearchItems.length; i++) {
							sMsg = aSearchItems[i].getValue();
						}
					}

					advanceSearchFilters = [];
					for (var j = 0; j < aSearchItems.length; j++) {
						advanceSearchFilters.push(new sap.ui.model.Filter({
							path: aSearchItems[j].getId(),
							operator: sap.ui.model.FilterOperator.EQ,
							value1: aSearchItems[j].getValue()
						}));
					}
					//sap.m.MessageToast.show("Search pressed '" + sMsg + "'");
					oValueHelpDialog.setBusy(true);

					// advanceSearchFilters.push(new sap.ui.model.Filter({
					// 	path: "Name",
					// 	operator: sap.ui.model.FilterOperator.EQ,
					// 	value1: sMsg
					// }));

					var oRowsModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YUI_FILTERBAR_SRV/");

					oRowsModel.read("/VendorSet", {
						filters: advanceSearchFilters,
						success: function(oData, response) {
							//var multiInputVendor = this.getView().byId("multiInputVendor");
							var value = [];
							value = oData.results;
							var oModelPlant = new sap.ui.model.json.JSONModel();
							oModelPlant.setData(value);
							oValueHelpDialog.getTable().setModel(oModelPlant);
							if (oValueHelpDialog.getTable().bindRows) {
								oValueHelpDialog.getTable().bindRows("/");
							}
							oValueHelpDialog.setBusy(false);
							oValueHelpDialog.update();
						},
						error: function(oError) { //read error}
							sap.m.MessageToast.show("Error Fetching data");
						}
					});

				}

			});

			// if (oFilterBar.setBasicSearch) {
			// 	oFilterBar.setBasicSearch(new sap.m.SearchField({
			// 		tooltip: "Search for Vendor",
			// 		placeholder: "Search",
			// 		search: function(event) {
			// 			var data = event.mParameters.query;
			// 			var oFilters = new sap.ui.model.Filter({
			// 				and: false,
			// 				filters: [
			// 					new sap.ui.model.Filter({

			// 						filters: [
			// 							new sap.ui.model.Filter("VendorNo", sap.ui.model.FilterOperator.Contains, data)
			// 						]
			// 					}),
			// 					new sap.ui.model.Filter({

			// 						filters: [
			// 							new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, data)
			// 						]
			// 					})
			// 				]
			// 			});
			// 			// var oElement = sap.ui.getCore().byId("idValueHelpPlant").getTable();
			// 			var oElement = oValueHelpDialog.getTable();
			// 			oElement.getBinding("rows").filter([oFilters]);
			// 		}
			// 	}));
			// }
			oValueHelpDialog.setTokens(multiInputVendor.getTokens());
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();

		},

		showValueHelpCommMang: function() {
			oValueHelpDialog = null;
			var multiInputCommMang = this.getView().byId("multiInputCommMang");
			//var that = this;
			if (multiInputCommMang.getTokens().length <= 0) {
				that.CommMangTableValue = null;
			}
			oValueHelpDialog = new ValueHelpDialog({
				supportRanges: true,
				title: "Commodity Manager",
				key: "CmCode",
				descriptionKey: "CmName",
				tokenDisplayBehaviour: "CmCode",
				ok: function(oControlEvent) {
					aTokens = oControlEvent.getParameter("tokens");
					var sTokens = "";
					for (var i = 0; i < aTokens.length; i++) {
						var oToken = aTokens[i];
						sTokens += oToken.getText() + " ";
					}

					multiInputCommMang.setTokens(aTokens);
					if (!that.CommMangTableValue) {
						that.CommMangTableValue = oValueHelpDialog.getTable().getModel().getData();
					}
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				cancel: function(oControlEvent) {
					oValueHelpDialog.close();
					oValueHelpDialog = null;
				},
				afterClose: function() {
					this.destroy();
					oValueHelpDialog = null;
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
						label: "Code",
						template: "CmCode"
					}, {
						label: "Description",
						template: "CmName"
					}

				]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			if (!that.CommMangTableValue) {
				oValueHelpDialog.setBusy(true);
				var oRowsModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YMPI_PO_DETAILS1_SRV/");
				oRowsModel.read("/ComodityManagerSrchHelpSet", {
					success: function(oData, response) {
						var value = [];
						value = oData.results;
						var oModelVendor = new sap.ui.model.json.JSONModel();
						oModelVendor.setData(value);
						oValueHelpDialog.getTable().setModel(oModelVendor);
						if (oValueHelpDialog.getTable().bindRows) {
							oValueHelpDialog.getTable().bindRows("/");
						}
						if (multiInputCommMang.getTokens().length > 0) {
							oValueHelpDialog.setTokens(multiInputCommMang.getTokens());
						}
						oValueHelpDialog.setBusy(false);
						oValueHelpDialog.update();

					},
					error: function(oError) { //read error}
						sap.m.MessageToast.show("Error Fetching data");
					},
					beforeOpen: function(oControlEvent) {
						sap.m.MessageToast.show("Selection changed!");
					}
				});
			} else {
				var oModelCommMang2 = new sap.ui.model.json.JSONModel();
				oModelCommMang2.setData(that.CommMangTableValue);
				oValueHelpDialog.getTable().setModel(oModelCommMang2);
				if (oValueHelpDialog.getTable().bindRows) {
					oValueHelpDialog.getTable().bindRows("/");
				}
				if (multiInputCommMang.getTokens()) {
					oValueHelpDialog.setTokens(multiInputCommMang.getTokens());
				}
				oValueHelpDialog.open();
				oValueHelpDialog.update();
			}

			oValueHelpDialog.setRangeKeyFields([{
				label: "Code",
				key: "CmCode"
			}]);
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				searchEnabled: false,
				showGoOnFB: false,
				showClearButton: true

			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					tooltip: "Search for Commodity Manager",
					placeholder: "Search",
					search: function(event) {
						var data = event.mParameters.query;
						var oFilters = new sap.ui.model.Filter({
							and: false,
							filters: [
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("CmCode", sap.ui.model.FilterOperator.Contains, data)
									]
								}),
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("CmName", sap.ui.model.FilterOperator.Contains, data)

									]
								})
							]
						});
						var oElement = oValueHelpDialog.getTable();
						oElement.getBinding("rows").filter([oFilters]);
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();

		},

		// ***** End of Addition by Debashish ****** //

		onBtnSearchClick: function() {
			var poNumber = this.getView().byId("inpPoNo").getValue();
			var purPlant = "";
			var purGroup = "";
			var VendCode = "";
			var CommMangID = "";
			var Level = "";
			//****  Added by debashish *****
			var multiInputPlant = this.getView().byId("multiInputPlant");
			var PlantTokens = multiInputPlant.getTokens();
			var multiInputPurGrp = this.getView().byId("multiInputPurGrp");
			var PurGrpTokens = multiInputPurGrp.getTokens();
			var multiInputVendor = this.getView().byId("multiInputVendor");
			var VendorTokens = multiInputVendor.getTokens();
			var multiInputCommMang = this.getView().byId("multiInputCommMang");
			var CommMangTokens = multiInputCommMang.getTokens();
			//****  End of addition by debashish *****
			//****** Commented By Debashish *****
			// if (this.getView().byId("cbPurPlant").getSelectedItem() !== null) {
			// 	purPlant = this.getView().byId("cbPurPlant").getSelectedItem().getKey();
			// }

			// if (this.getView().byId("cbPurGroup").getSelectedItem() !== null) {
			// 	purGroup = this.getView().byId("cbPurGroup").getSelectedItem().getKey();
			// }
			// if (this.getView().byId("cbVendor").getSelectedItem() !== null) {
			// 	VendCode = this.getView().byId("cbVendor").getSelectedItem().getKey();
			// }
			// if (this.getView().byId("cbCommMang").getSelectedItem() !== null) {
			// 	CommMangID = this.getView().byId("cbCommMang").getSelectedItem().getKey();
			// }
			//***** End of Comment By Debashish  *****
			if (this.getView().byId("cbLevel").getSelectedItem() !== null) {
				Level = this.getView().byId("cbLevel").getSelectedItem().getKey();
			}

			//	var VendCode = this.getView().byId("inpVenCode").getValue().toUpperCase();
			//	var CommMangID = this.getView().byId("inpCommMang").getValue();

			//MessageToast.show(formatter.amountValue("3000052995.676786"));
			//	if (poNumber === "" && purPlant === "" && purGroup === "") {
			//		MessageToast.show("Select at least one criteria for search.");
			//	} else {
			var oList = this.byId("list");
			var oViewModel = new JSONModel();
			this.getView().setModel(oViewModel, "listModel");
			oList.setModel(sap.ui.getCore().getModel("listModel"));

			var filters = new Array();
			var filter1 = new sap.ui.model.Filter(
				"Ebeln",
				sap.ui.model.FilterOperator.EQ, poNumber
			);
			//***** Commented By Debashish  *****
			// var filter2 = new sap.ui.model.Filter(
			// 	"Werks",
			// 	sap.ui.model.FilterOperator.EQ, purPlant
			// );

			// var filter3 = new sap.ui.model.Filter(
			// 	"Ekgrp",
			// 	sap.ui.model.FilterOperator.EQ, purGroup
			// );
			// var filterVendCode = new sap.ui.model.Filter(
			// 	"Lifnr",
			// 	sap.ui.model.FilterOperator.EQ, VendCode
			// );
			// var filterCommMangID = new sap.ui.model.Filter(
			// 	"Unsez",
			// 	sap.ui.model.FilterOperator.EQ, CommMangID
			// );
			//***** End of Comment By Debashish  *****

			var filterlevel = new sap.ui.model.Filter(
				"Level",
				sap.ui.model.FilterOperator.EQ, Level
			);

			if (poNumber !== "") {
				filters.push(filter1);
			}
			//***** Commented By Debashish  *****
			// if (purPlant !== "") {
			// 	filters.push(filter2);
			// }
			// if (purGroup !== "") {
			// 	filters.push(filter3);
			// }
			//***** End of Comment By Debashish  *****
			// ***** Added By Debashish *****
			var PlantFilter = null;
			for (var m = 0; m < PlantTokens.length; m++) {

				if (PlantTokens[m].getKey().indexOf("range") === -1) {
					PlantFilter = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, PlantTokens[m].getKey());
				} else {
					if (PlantTokens[m].data().range.exclude) {
						PlantFilter = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.NE, PlantTokens[m].data().range.value1);
					} else {
						PlantFilter = new sap.ui.model.Filter("Werks", PlantTokens[m].data().range.operation, PlantTokens[m].data().range.value1,
							PlantTokens[m].data().range.value2);
					}
				}
				filters.push(PlantFilter);
				// _urlFilter.push(oFilters);
			}

			//***  Purchase Group filter**//
			var PurGrpFilter = null;
			for (var k = 0; k < PurGrpTokens.length; k++) {
				if (PurGrpTokens[k].getKey().indexOf("range") === -1) {
					PurGrpFilter = new sap.ui.model.Filter("Ekgrp", sap.ui.model.FilterOperator.EQ, PurGrpTokens[k].getKey());
				} else {
					if (PurGrpTokens[k].data().range.exclude) {
						PurGrpFilter = new sap.ui.model.Filter("Ekgrp", sap.ui.model.FilterOperator.NE, PurGrpTokens[k].data().range.value1);
					} else {
						PurGrpFilter = new sap.ui.model.Filter("Ekgrp", PurGrpTokens[k].data().range.operation, PurGrpTokens[k].data().range.value1,
							PurGrpTokens[k].data().range.value2);
					}

				}
				filters.push(PurGrpFilter);
				// _urlFilter.push(PurGrpFilter);
			}

			var VendorFilter = null;
			for (var j = 0; j < VendorTokens.length; j++) {
				if (VendorTokens[j].getKey().indexOf("range") === -1) {
					VendorFilter = new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.EQ, VendorTokens[j].getKey());
				} else {
					if (VendorTokens[j].data().range.exclude) {
						VendorFilter = new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.NE, VendorTokens[j].data().range.value1);
					} else {
						VendorFilter = new sap.ui.model.Filter("Lifnr", VendorTokens[j].data().range.operation, VendorTokens[j].data().range.value1,
							VendorTokens[j].data().range.value2);
					}

				}
				filters.push(VendorFilter);
				// _urlFilter.push(PurGrpFilter);
			}

			var CommMangFilter = null;
			for (var p = 0; p < CommMangTokens.length; p++) {
				if (CommMangTokens[p].getKey().indexOf("range") === -1) {
					CommMangFilter = new sap.ui.model.Filter("Unsez", sap.ui.model.FilterOperator.EQ, CommMangTokens[p].getKey());
				} else {
					if (CommMangTokens[p].data().range.exclude) {
						CommMangFilter = new sap.ui.model.Filter("Unsez", sap.ui.model.FilterOperator.NE, CommMangTokens[p].data().range.value1);
					} else {
						CommMangFilter = new sap.ui.model.Filter("Unsez", CommMangTokens[p].data().range.operation, CommMangTokens[p].data().range.value1,
							CommMangTokens[p].data().range.value2);
					}

				}
				filters.push(CommMangFilter);
				// _urlFilter.push(PurGrpFilter);
			}
			//***** End of Addition By Debashish ******

			// if (VendCode !== "") {
			// 	filters.push(filterVendCode);
			// }
			// if (CommMangID !== "") {
			// 	filters.push(filterCommMangID);
			// }
			if (Level !== "" && Level !== "00") {
				filters.push(filterlevel);
			}

			/*var filter2 = new sap.ui.model.Filter(
				"Ebeln",
				sap.ui.model.FilterOperator.EQ, "2100451200"
			);
			filters.push(filter2);*/
			/*filter1 = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, sap.ui.getCore().byId("inputPlant").getValue().toString()
				.trim());
			filters.push(filter1);*/

			if (!thatDialog) {
				thatDialog = sap.ui.xmlfragment("com.sap.tatasteel.zporelease.view.BusyDialog", this);
				this.getView().addDependent(thatDialog);
			}
			// this._dialog.open();
			// jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
			// var linkEvent = null;
			var oItemTemplate = new sap.m.ObjectListItem({
				title: "{Ebeln} - ({UnsezName})",
				press: [this.onSelectionChange, this],
				type: "Active",
				number: "{parts: [{path: 'FinalValue'}, {path: 'Waers'}],type: 'sap.ui.model.type.Currency',formatOptions: {showMeasure: false}}",
				numberUnit: "{Waers}",
				showMarkers: true,
				attributes: [
					new sap.m.ObjectAttribute({
						//title: "PO Short Text",
						text: "{Txz01}"
					}),
					new sap.m.ObjectAttribute({
						title: "Creation Date",
						//text: "{Aedat}"
						text: "{path: 'Aedat',type: 'sap.ui.model.type.Date'}"
					}),
					new sap.m.ObjectAttribute({
						title: "Vendor",
						text: "{Name1} : {Lifnr}"

					}),
					new sap.m.ObjectAttribute({
						title: "Pur Grp",
						text: "{PurGrpName} : {Ekgrp}"
					}),
					new sap.m.ObjectAttribute({
						title: "Plant",
						text: "{PlantName} : {Werks}"
					}),
					new sap.m.ObjectAttribute({
						title: "PR Value",
						//text: "{PrValue} {Waers}"
						text: "{parts: [{path: 'PrValue'}, {path: 'Waers'}],type: 'sap.ui.model.type.Currency',formatOptions: {showMeasure: false}}"
					}),
					new sap.m.ObjectAttribute({
						title: "Quoted Rate",
						//text: "{RfqValue} {Waers}"
						text: "{parts: [{path: 'RfqValue'}, {path: 'Waers'}],type: 'sap.ui.model.type.Currency',formatOptions: {showMeasure: false}}"
					}),
					new sap.m.ObjectAttribute({ // Added by debashish for Release button functionality
						text: "{Ebeln}",
						active: true,
						customContent: new sap.m.Link({
							text: "Release",
							href: "{Ebeln}",
							enabled: true,
							subtle: true,
							wrapping: true,
							press: function(oEvent) {
								oEvent.preventDefault();
								thatDialog.open();
								//console.log(oEvent.getSource().getBindingContext().sPath.split("(")[1].slice(0, -1));
								//=================================================
								var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPI_PO_DETAILS1_SRV/", true);
								try {
									oModel.read("/ReleasePO", {
										urlParameters: {
											"ebeln": oEvent.getSource().getBindingContext().sPath.split("(")[1].slice(0, -1)
												//"ebeln": '0000001'
										},
										//	},
										success: function(oData, response) {
											var value = [];
											value = oData.results;
											var successStatusMsg = oData.ReleasePO.ReturnText;
											var successCode = oData.ReleasePO.ReturnCode;
											if (successCode !== "0" && successCode !== "") {
												// sap.m.MessageBox.show(
												// 	"Error releasing purchase order. Error : - " + successStatusMsg, {
												// 		icon: sap.m.MessageBox.Icon.SUCCESS,
												// 		title: "Failed",
												// 		actions: [sap.m.MessageBox.Action.OK],
												// 		onClose: function(oAction) {}
												// 	}
												// );
												sap.m.MessageBox.show(successStatusMsg, {
													icon: sap.m.MessageBox.Icon.ERROR,
													title: "Failed",
													actions: [sap.m.MessageBox.Action.OK],
													onClose: function(oAction) {}
												});

												thatDialog.close();
											} else {
												// sap.m.MessageBox.show(
												// 	"Purchase order released successfully." + successStatusMsg, {
												// 		icon: sap.m.MessageBox.Icon.SUCCESS,
												// 		title: "Success",
												// 		actions: [sap.m.MessageBox.Action.OK],
												// 		onClose: function(oAction) {
												// 			// t.onNavBack();
												// 		}
												// 	}
												// );
												sap.m.MessageBox.show(successStatusMsg, {
													icon: sap.m.MessageBox.Icon.SUCCESS,
													title: "Success",
													actions: [sap.m.MessageBox.Action.OK],
													onClose: function(oAction) {
														// t.onNavBack();
													}
												});
												thatDialog.close();
											}

										},
										error: function(oData, response) {
											//that.linkEvent.getSource().setText("PO Released");
											MessageToast.show("Error releasing the purchase order");
											thatDialog.close();
										}
									});

								} catch (ex) {
									MessageToast.show("Error releasing the purchase order");
									thatDialog.close();
								}
								//=================================================

							}
						})
					}).firePress(function(ev) {
						ev.preventDefault();
					})
				]
			});

			oList.bindItems({
				path: "/ItDetailsSet",
				filters: filters,
				template: oItemTemplate
			}, true);

			/*	var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{Ebeln}"
						})
					]
				});
				var oView = this.getView();
				var oList = oView.byId("poList");
				//var path = "/ItDetailsSet";
				oList.bindItems({
					path: "/ItDetailsSet",
					filters: filters,
					template: oTemplate
				}, true);*/

			//	var oList = this.byId("list"),
			//var oViewModel = this._createViewModel(),
			// Put down master list's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the master list is
			// taken care of by the master list itself.
			//iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			/*oViewModel.setData({
					itemType: "Navigation"
				});*/

			var oViewModel = sap.ui.getCore().getModel("listModel");
			//iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			//	this._oGroupSortState = new GroupSortState(oViewModel, grouper.groupUnitNumber(this.getResourceBundle()));

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			this.setModel(oViewModel, "listModel");
			//this.getView().byId("list").setType("Navigation");
			//	oViewModel.setProperty("/itemType", "Navigation");

			//this.oViewModel.refresh(true);
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			/*oList.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});*/

			/*this.getView().addEventDelegate({
				onBeforeFirstShow: function() {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});*/

			//	}
		},
		/*onListItemPress: function(evt) {
			MessageToast.show("Pressed : " + evt.getSource().getTitle());
		},*/
		_createViewModel: function() {
			/*	var filters = new Array();
				var filter1 = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.EQ, "2100451204");
				filters.push(filter1);

				var oItemTemplate = new sap.m.ObjectListItem({
					title: "{Ebeln}"
				});
				var oList = this.byId("list");
				oList.bindItems({
					path: "/ItDetailsSet",
					filters: filters,
					template: oItemTemplate
				});*/

			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: oBundle.getText("masterTitleCount", [0]),
				noDataText: oBundle.getText("masterListNoDataText"),
				sortBy: "Ebeln",
				groupBy: "None"
			});
		},
		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function(oEvent) {
			// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
			//this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			var oItem = oEvent.getSource();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("detail", {
				objectId: oItem.getBindingContext().getProperty("Ebeln")
			});
		},
		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function(oItem) {
			//var bReplace = !Device.system.phone;
			//var oItem = oEvent.getSource();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			/*oRouter.navTo("detail", {
				objectId: oItem.getBindingContext().getProperty("Ebeln")
			}, bReplace);*/
			oRouter.navTo("detail", {
				objectId: encodeURIComponent(oItem.getBindingContext().getProperty("Ebeln"))
			});
		},
		onInit: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oViewModel = new JSONModel();
			this.getView().setModel(oViewModel, "listModel");
			oViewModel.setSizeLimit(1000);
			this.getView().byId("cbLevel").setSelectedItem('3').setSelectedKey('03');
			sap.ui.core.BusyIndicator.hide();
			//Check if variable exists
		},
		//
		onFilterInvoices: function(oEvent) {
			// build filter array
			var aFilter = [];
			var arrFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("ProductName", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("ShipperName", FilterOperator.Contains, sQuery));

				//Adding Multiple filter condition with OR condition
				arrFilter.push(new sap.ui.model.Filter(aFilter, false));
			}

			// filter binding
			var oList = this.getView().byId("invoiceList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(arrFilter);
		},
		onPress: function(oEvent) {
			var oItem = oEvent.getSource();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("sampledetail", {
				invoicePath: encodeURIComponent(oItem.getBindingContext("invoice").getPath().substr(1))
			});
		},
		onBtnClearClick: function() {
			this.getView().byId("inpPoNo").setValue("");
			//**** Commented by Debashish ****
			// this.getView().byId("cbPurPlant").setValue("");
			// this.getView().byId("cbPurPlant").setSelectedKey("");
			// this.getView().byId("cbPurGroup").setValue("");
			// this.getView().byId("cbPurGroup").setSelectedKey("");
			// this.getView().byId("inpVenCode").setValue("");
			// this.getView().byId("inpCommMang").setValue("");
			//**** End of Comment by Debashish ****
			//**** Added by Debashish ****
			this.getView().byId("multiInputPlant").removeAllTokens();
			this.getView().byId("multiInputPurGrp").removeAllTokens();
			this.getView().byId("multiInputVendor").removeAllTokens();
			this.getView().byId("multiInputCommMang").removeAllTokens();
			//**** End Of addition by Debashish ****

			this.getView().byId("cbLevel").setSelectedItem('3').setSelectedKey('03');
			var oList = this.byId("list");
			var emptyDataModel = new sap.ui.model.json.JSONModel();
			if (emptyDataModel) {
				emptyDataModel.setData(null);
				emptyDataModel.updateBindings(true);
			}
			oList.setModel(emptyDataModel);
		},

		// createTokens: function(oEvent, obj) {
		// 	var oView = this.getView();
		// 	var tokens = obj.getTokens();
		// 	var _newTokens = [];
		// 	_newTokens = new sap.m.Token({
		// 		text: oEvent.mParameters.value,
		// 		key: oEvent.mParameters.value
		// 	});

		// 	tokens.push(_newTokens);
		// 	obj.setTokens(tokens);
		// 	obj.setValue("");
		// },
		userCreatedToken: function(oEvent) {
			// var str = oEvent.mParameters.id;
			// var oView = this.getView();
			var oMultiInput = sap.ui.getCore().byId(oEvent.mParameters.id); //           oView.byId(id);
			//this.createTokens(oEvent, oMultiInput1);
			// var tokens = oMultiInput1.getTokens();
			var _newTokens = [];
			_newTokens = new sap.m.Token({
				text: oEvent.mParameters.value,
				key: oEvent.mParameters.value
			});
			// tokens.push(_newTokens);
			oMultiInput.addToken(_newTokens);
			oMultiInput.setValue("");

		},
		onListSelectionChange: function(oEvt) {
			// var oItem = oEvent.getSource();
			// var oContext = oItem.getBindingContext("DC");
			// //var sName = oContext.getProperty("Name");
			var oList = oEvt.getSource();
			//var oLabel = this.byId("otb4");
			var oInfoToolbar = this.getView().byId("otb4");

			// With the 'getSelectedContexts' function you can access the context paths
			// of all list items that have been selected, regardless of any current
			// filter on the aggregation binding.
			var aContexts = oList.getSelectedContexts(true);
			// update UI
			//var bSelected = (aContexts && aContexts.length > 0);
			//var sText = (bSelected) ? aContexts.length + " selected" : null;
			if (aContexts.length > 0) {
				oInfoToolbar.setVisible(true);
			} else {
				oInfoToolbar.setVisible(false);
			}
		},
		releaseSelectedPO: function() {
			var oList = this.byId("list");
			var aSelected = oList.getSelectedItems();
			if (aSelected.length === 0) {
				sap.m.MessageToast.show("Nothing selected");
			} else {
				if (!thatDialog) {
					thatDialog = sap.ui.xmlfragment("com.sap.tatasteel.zporelease.view.BusyDialog", this);
					this.getView().addDependent(thatDialog);
				}
				sap.m.MessageToast.show(aSelected.length + " selected");

				var __that = this;
				for (var p = 0; p < aSelected.length; p++) {
					var selEbeln = aSelected[p];
					var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPI_PO_DETAILS1_SRV/", true);
					// this.ebeln = "";
					__that.ebeln = null;
					__that.ebeln = selEbeln.getBindingContext().getObject().Ebeln;
					thatDialog.open();
					try {
						oModel.read("/ReleasePO", {
							urlParameters: {
								"ebeln": "'" + selEbeln.getBindingContext().getObject().Ebeln + "'"
									//"ebeln": "'0000001'"
							},
							//	},
							success: function(oData, response) {
								var value = [];
								value = oData.results;
								var successStatusMsg = oData.ReleasePO.ReturnText;
								var successCode = oData.ReleasePO.ReturnCode;
								if (successCode !== "0" && successCode !== "") {
									sap.m.MessageBox.show(successStatusMsg, {
										icon: sap.m.MessageBox.Icon.ERROR,
										title: "Failed",
										actions: [sap.m.MessageBox.Action.OK]
									});
									thatDialog.close();
								} else {
									sap.m.MessageBox.show(successStatusMsg, {
										icon: sap.m.MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [sap.m.MessageBox.Action.OK]
									});
									thatDialog.close();
								}

							},
							error: function(oData, response) {
								//that.linkEvent.getSource().setText("PO Released");
								MessageToast.show(oData.ReleasePO.ReturnText);
								thatDialog.close();
							}
						});

					} catch (ex) {
						MessageToast.show("Error releasing the purchase order");
						//thatDialog.close();
					}
					selEbeln = null;
				}
				//thatDialog.close();

			}
		}

	});
});