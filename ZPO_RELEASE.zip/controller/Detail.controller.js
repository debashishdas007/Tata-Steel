sap.ui.define([
	"jquery.sap.global",
	"com/sap/tatasteel/zporelease/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/sap/tatasteel/zporelease/model/formatter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	'sap/m/MessageBox'
], function(jQuery, BaseController, Controller, JSONModel, History, formatter, MessageToast, Fragment, MessageBox) {
	"use strict";
	var _timeout;
	return BaseController.extend("com.sap.tatasteel.zporelease.controller.Detail", {
		formatter: formatter,
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});
			var oRouter = this.getRouter();
			oRouter.getRoute("detail").attachPatternMatched(this._onObjectMatched, this);
			//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//oRouter.getRoute("detail").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			//this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},
		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("master", true);
			}
		},
		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			this.sObjectId = oEvent.getParameter("arguments").objectId;
			var sObjectPath = this.getModel().createKey("ItDetailsSet", {
				Ebeln: this.sObjectId
			});
			var oView = this.getView();
			oView.bindElement("/" + sObjectPath);

			var filters = new Array();
			var filter1 = new sap.ui.model.Filter(
				"Ebeln",
				sap.ui.model.FilterOperator.EQ, this.sObjectId //"2100466061" 
			);
			filters.push(filter1);

			var oItemTemplate = new sap.m.ObjectListItem({
				title: "{Ebeln}/{Ebelp}",
				//number: "{Netwr}",
				number: "{parts: [{path: 'Netwr'}, {path: 'Waers'}],type: 'sap.ui.model.type.Currency',formatOptions: {showMeasure: false}}",
				numberUnit: "{Waers}",
				attributes: [
					new sap.m.ObjectAttribute({
						text: "{Txz01}"
					}),
					new sap.m.ObjectAttribute({
						title: "Material",
						text: "{Matnr}"
					}),
					new sap.m.ObjectAttribute({
						title: "PO Quantity",
						text: "{Menge} {Meins}"
					}),
					new sap.m.ObjectAttribute({
						title: "Item rate",
						//text: "{Netpr} {Waers}"
						text: "{parts: [{path: 'Netpr'}, {path: 'Waers'}],type: 'sap.ui.model.type.Currency',formatOptions: {showMeasure: false}}"
					}),
					new sap.m.ObjectAttribute({
						title: "Rsn of Order ",
						text: "{Bsgru}"
					})
				]

			});

			var itemsList = oView.byId("itemsList");
			itemsList.bindItems({
				path: "/PoItmDtlsSet",
				filters: filters,
				template: oItemTemplate
			}, true);

			//var oData = sap.ui.getCore().getModel("masterView").getData();
			/*this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("ItDetailsSet", {
					Ebeln: this.sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));*/

			/*this.getView().bindElement({
				path: "/" + oEvent.getParameter("arguments").objectId,
				model: "ItDetailsSet"
			});*/

		},
		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
				//model: "ItDetailsSet"
			});
		},
		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("master");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.Ebeln,
				sObjectName = oObject.Ebeln,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},
		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = sap.ui.getCore().getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			//oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			//oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			//oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		onSemanticButtonPress: function(oEvent) {
			var t = this;
			//	alert(this.sObjectId);
			//	debugger;
			// this.getView().getModel().read("/ReleasePO?ebeln eq '"+this.sObjectId+"'","POST", null, true,function(oData) {
			// this.getView().getModel().			
			// 	MessageToast.show("Success");
			// }, function(data) {
			// 	MessageToast.show("Failed");
			// });
			//sap.ui.core.BusyIndicator.show();
			//sap.m.BusyDialog().open();

			// instantiate dialog
			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment("com.sap.tatasteel.zporelease.view.BusyDialog", this);
				this.getView().addDependent(this._dialog);
			}
			// open dialog
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
			this._dialog.open();

			// simulate end of operation
			_timeout = jQuery.sap.delayedCall(300000, this, function() {
				this._dialog.close();
			});

			this.getView().getModel().callFunction("ReleasePO", // function import name
				"GET", // http method
				{
					"ebeln": this.sObjectId
				}, // function import parameters
				null,
				function(oData, response) {
					var successStatusMsg = oData.ReleasePO.ReturnText;
					var successCode = oData.ReleasePO.ReturnCode;
					if (successCode !== "0" && successCode !== "") {
						// Commented by debashish on 25.6.2018
						// sap.m.MessageBox.show(
						// 	"Error releasing purchase order. Error : - " + successStatusMsg, {
						// 		icon: sap.m.MessageBox.Icon.SUCCESS,
						// 		title: "Failed",
						// 		actions: [sap.m.MessageBox.Action.OK],
						// 		onClose: function(oAction) {
						// 			t.onNavBack();
						// 			//var oRouter = sap.ui.core.UIComponent.getRouterFor(t);
						// 			//oRouter.navTo("master");
						// 		}
						// 	}
						// );
						sap.m.MessageBox.show(successStatusMsg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Failed",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(oAction) {
								t.onNavBack();
								//var oRouter = sap.ui.core.UIComponent.getRouterFor(t);
								//oRouter.navTo("master");
							}
						});
						//	MessageToast.show("Purchase order released successfully", {
						//		duration: 6000
						//	});
						this._dialog.close();
					} else {
						// Commented by debashish on 25.6.2018
						// sap.m.MessageBox.show(
						// 	"Purchase order released successfully." + successStatusMsg, {
						// 		icon: sap.m.MessageBox.Icon.SUCCESS,
						// 		title: "Success",
						// 		actions: [sap.m.MessageBox.Action.OK],
						// 		onClose: function(oAction) {
						// 			t.onNavBack();
						// 			//var oRouter = sap.ui.core.UIComponent.getRouterFor(t);
						// 			//oRouter.navTo("master");
						// 		}
						// 	}
						// );
						sap.m.MessageBox.show(successStatusMsg, {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function(oAction) {
								t.onNavBack();
								//var oRouter = sap.ui.core.UIComponent.getRouterFor(t);
								//oRouter.navTo("master");
							}
						});

						//	MessageToast.show("Purchase order released successfully", {
						//		duration: 6000
						//	});
						this._dialog.close();
					}

					//this.onNavBack();
				}.bind(this), // callback function for success
				function(oError) {
					MessageToast.show("Error releasing the purchase order");
					this._dialog.close();

				}, true /*True for Async Function call*/ ); // callback function for error

			//this._dialog.close();
			//jQuery.sap.clearDelayedCall(_timeout);
			//var sAction = oEvent.getSource().getMetadata().getName();
			//sAction = sAction.replace(oEvent.getSource().getMetadata().getLibraryName() + ".", "");

			//sap.m.MessageToast.show("Pressed: " + sAction);

		}
	});

});