sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/core/HTML"
], function(Controller, MessageToast, Filter, HTML) {
	"use strict";
	var _timeout;
	var tokenList;

	var backEndResponse = null;
	var canvas = null;
	var totalPageNumber = 1;
	var pageNumber = 1;
	var currentPageNumber = 1;
	var zoomIn = 1.0;

	return Controller.extend("com.sap.tatasteel.BillPrintingBillPrinting.controller.Main", {

		onInit: function() {

			// var imported = document.createElement("script");
			// imported.src = "//mozilla.github.io/pdf.js/build/pdf.js";
			// document.head.appendChild(imported);

			var imported = document.createElement("script");
			imported.src = "js/pdf.js";
			if (sap.ui.Device.system.desktop === true)
				imported.src = "//mozilla.github.io/pdf.js/build/pdf.js";

			document.head.appendChild(imported);

			var oModel = new sap.ui.model.json.JSONModel({
				onprev: false,
				onnext: false,
				onzoomin: false,
				onzoomout: false,
				deviceType: sap.ui.Device.system.desktop,
				totalPages: 0
			});

			this.getView().setModel(oModel);

		},

		// handleF4InvoiceNo: function() {
		// 	var oInput = this.getView().byId("idInput");
		// 	//check if the dialog already has some values
		// 	if (!this._oValueHelpDialog) {
		// 		//if dialog is undefined, set the contructor
		// 		this._oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idValueHelp", {
		// 			supportRanges: true,
		// 			supportMultiselect: true,
		// 			supportRangesOnly: true,
		// 			key: "InvoiceNo",
		// 			descriptionKey: "InvoiceNo",
		// 			//on Ok click
		// 			ok: function(oEvent) {
		// 				var aTokens = oEvent.getParameter("tokens");
		// 				//set textbox with the valueHelpDialog inputs
		// 				oInput.setTokens(aTokens);
		// 				this.close();
		// 			},
		// 			//on Cancel click
		// 			cancel: function() {
		// 				this.close();
		// 			}
		// 		});
		// 	}
		// 	//Bind the columns for table
		// 	//Dynamically create the column structure for the table
		// 	var oColModel = new sap.ui.model.json.JSONModel();
		// 	oColModel.setData({
		// 		cols: [{
		// 			label: "Invoice No",
		// 			template: "InvoiceNo" //id with which data needs to be binded
		// 		}]

		// 	});
		// 	var oTable = this._oValueHelpDialog.getTable();
		// 	oTable.setModel(oColModel, "columns");
		// 	//Creating row Model for binding it to row
		// 	var oRowModel = new sap.ui.model.json.JSONModel("model/mock.json");
		// 	oTable.setModel(oRowModel);
		// 	oTable.bindRows("/InvoiceNos");

		// 	this._oValueHelpDialog.setRangeKeyFields([{
		// 		label: "Invoice No",
		// 		key: "InvoiceNo"
		// 	}]);
		// 	//Open the dialogue on help click
		// 	this._oValueHelpDialog.open();
		// },
		//Preview button click
		onPress: function() {
			// var popupMessage = "<p><strong>2132002202</strong>: Invoice Downloaded</p> <p><strong>2170000502</strong>: You are not authorised for the Action</p>";
			var popupMessage = "";
			var beginLine = "<p>";
			var endLine = "</p>";
			var beginInvoiceSuccess = "<strong style='color:Green'>";
			var beginInvoiceError = "<strong style='color:Red'>";
			var endInvoice = "</strong>";
			var lineBody = "";
			var oInput = this.getView().byId("idInput");
			var oRadio = this.getView().byId("radioPrintType");

			tokenList = oInput.getTokens();
			var invoiceID = oInput._lastValue;

			var printTypeId = oRadio.getSelectedButton().getId().toString();
			var printType;
			// Checking Print Type case
			if (printTypeId.indexOf("rbOriginal") !== -1) {
				// Original
				printType = "Original";
			} else if (printTypeId.indexOf("rbRepeat") !== -1) {
				// Original
				printType = "Rpeat";
			} else if (printTypeId.indexOf("rbSpecial") !== -1) {
				// Original
				printType = "Special";
			} else if (printTypeId.indexOf("rbDuplicate") !== -1) {
				// Original
				printType = "Duplicate";
			} else if (printTypeId.indexOf("rbTriplicate") !== -1) {
				// Original
				printType = "Triplicate";
			} else if (printTypeId.indexOf("rbQuadruplicate") !== -1) {
				// Original
				printType = "Quadruplicate";
			} else if (printTypeId.indexOf("rbPentaduplicate") !== -1) {
				// Original
				printType = "Pendtaduplicate";
			}

			// var printType = 'X';
			// // Navigate to PDF Viewer Screen
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.navTo("pdfviewer",{
			// 	invoiceID: invoiceID,
			// 	printType: printType
			// });

			// instantiate dialog
			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment("com.sap.tatasteel.BillPrintingBillPrinting.view.BusyDialog", this);
				this.getView().addDependent(this._dialog);
			}

			// open dialog
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
			this._dialog.open();
			var sURI = "/sap/opu/odata/sap/YMSDOD_INVOICE_PRINT4_SRV";

			var context = this;
			var oModel = new sap.ui.model.odata.ODataModel(sURI, true);

			// if (tokenList.length > 0) {
			// 	for (var count = 0; count < tokenList.length; count++) {
			// 		var token = tokenList[count];

			// 		// Finding the Invoice No.
			// 		token = tokenList[count].getProperty("text").substring(1);

			// 		var pdfURL = sURI + "/InvoPdfSet(Vbeln='" + token + "',Printtype='" + printType + "')/$value";
			// 		var html = new sap.ui.core.HTML({});
			// 		// var html = context.getView().byId("pdfContainer");
			// 		html.setContent("<iframe id='iframe" + token + "' src=" + pdfURL + " width='2000' height='1200' style='display:none;'></iframe>");
			// 		html.placeAt("content");

			// 	}
			// } else if (invoiceID !== null) {
			// 	pdfURL = sURI + "/InvoPdfSet(Vbeln='" + invoiceID + "',Printtype='" + printType + "')/$value";
			// 	html = context.getView().byId("pdfContainer");
			// 	html.setContent("<iframe src=" + pdfURL + " width='2000' height='1200' style='display:none;'></iframe>");
			// }

			if (tokenList.length > 0) {

				for (var count = 0; count < tokenList.length; count++) {
					lineBody = "";
					var token = tokenList[count];

					// Finding the Invoice No.
					token = tokenList[count].getProperty("text").substring(1);

					oModel.read(
						// "/InvoPdfSet(Vbeln='2132002202',Printtype='Rpeat')/$value",
						"/InvoPdfSet(Vbeln='" + token + "',Printtype='" + printType + "')/$value",
						null, null, false,
						function(odata, response) {
							if (response === null) {

							} else {
								var pdfURL = response.requestUri;
								window.open(pdfURL);
								// // var html = context.getView().byId("pdfContainer");
								// var html = new sap.ui.core.HTML({});
								// html.setContent("<iframe  id='iframe" + token + "' src=" + pdfURL +
								// 	" width='2000' height='1200' style='display:none;'></iframe>");
								// html.placeAt("content");

								// Success message
								lineBody = beginLine + beginInvoiceSuccess + token + endInvoice + ":";
								lineBody = lineBody + "Invoice Downloaded" + endLine;
							}

						},
						function fnError(e) {
							// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
							var errorBody = e.response.body;
							var errorMessage = JSON.parse(errorBody).error.message.value;

							// Error message
							lineBody = beginLine + beginInvoiceError + token + endInvoice + ":";
							lineBody = lineBody + errorMessage + endLine;
							// On Error
							// context._showStatusDialog(context, "Error", "Message",
							// 	"Error", "Error while processing the order details: " + errorMessage);
						});
					popupMessage = popupMessage + lineBody;
				}
				// simulate end of operation
				_timeout = jQuery.sap.delayedCall(3000, context, function() {
					context._dialog.close();
				});
				context._showStatusDialog(context, "Download Summary", "Message",
					"Error", popupMessage);
			} else if (invoiceID !== null) {
				oModel.read(
					// "/InvoPdfSet(Vbeln='2132002202',Printtype='Rpeat')/$value",
					"/InvoPdfSet(Vbeln='" + invoiceID + "',Printtype='" + printType + "')/$value",
					null, null, false,
					function(odata, response) {
						if (response === null) {

						} else {
							var pdfURL = response.requestUri;
							window.open(pdfURL);
							// var html = context.getView().byId("pdfContainer");
							// html.setContent("<iframe src=" + pdfURL + " width='2000' height='1200' style='display:none;'></iframe>");

							// // simulate end of operation
							// _timeout = jQuery.sap.delayedCall(2000, context, function() {
							// 	context._dialog.close();
							// });
						}

					},
					function fnError(e) {
						// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
						var errorBody = e.response.body;
						var errorMessage = JSON.parse(errorBody).error.message.value;

						// On Error
						context._showStatusDialog(context, "Error", "Message",
							"Error", "Error while processing the order details: " + errorMessage);
					});
			}

			// simulate end of operation
			_timeout = jQuery.sap.delayedCall(2000, context, function() {
				context._dialog.close();
			});

			var controls = document.getElementsByTagName("iframe");
			for (var c = 0; c < controls.length; c++) {
				controls[c].src = ""; // Setting the SRC as blank.
			}

			// oModel.read(
			// 	// "/InvoPdfSet(Vbeln='2132002202',Printtype='Rpeat')/$value",
			// 	"/InvoPdfSet(Vbeln='"+invoiceID+"',Printtype='"+printType+"')/$value",
			// 	null, null, false,
			// 	function(odata, response) {
			// 		if (response === null) {

			// 		} else {
			// 			var pdfURL = response.requestUri;
			// 			var html = context.getView().byId("pdfContainer");
			// 			html.setContent("<iframe src=" + pdfURL + " width='2000' height='1200' style='display:none;'></iframe>");

			// 			// simulate end of operation
			// 			_timeout = jQuery.sap.delayedCall(2000, context, function() {
			// 				context._dialog.close();
			// 			});
			// 		}

			// 	},
			// 	function fnError(e) {
			// 		// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
			// 		var errorBody = e.response.body;
			// 		var errorMessage = JSON.parse(errorBody).error.message.value;

			// 		// On Error
			// 		context._showStatusDialog(context, "Error", "Message",
			// 			"Error", "Error while processing the order details: " + errorMessage);
			// 	});

		},
		onChangeInvoiceNo: function(evt) {
			var controlId = evt.getSource().getId();
			var controlValue = this.getView().byId(controlId).getValue();
			this._setValueStateOnError(evt.getSource().getId(), controlValue, "Invoice Number is a mandatory field", true);
		},
		_setValueStateOnError: function(controlID, controlValue, valueStateText, validateOption) {
			if (validateOption === true) { // WHen validation is required
				if (controlValue === "" || this.getView().byId(controlID).getTokens().length === 0) {
					this.getView().byId(controlID).setValueState(sap.ui.core.ValueState.Error); // if the field is empty after change, it will go red
					this.getView().byId(controlID).setValueStateText(valueStateText);
					return false;
				} else {
					this.getView().byId(controlID).setValueState(sap.ui.core.ValueState.None); // if the field is empty after change, it will go red
					this.getView().byId(controlID).setValueStateText("");
					return true;
				}
			} else { // When no validation required
				this.getView().byId(controlID).setValueState(sap.ui.core.ValueState.None); // if the field is empty after change, it will go red
				this.getView().byId(controlID).setValueStateText("");
				return true;
			}
		},
		_showStatusDialog: function(context, strTitle, strType, strState, strText) {
			var dialog = new sap.m.Dialog({
				title: strTitle,
				type: strType,
				state: strState,
				content: new sap.m.FormattedText({
					htmlText: strText
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function() {

						dialog.close();

						// Navigating to the Home page of the application
						var oRouter = sap.ui.core.UIComponent.getRouterFor(context);
						oRouter.navTo("header");
					}
				}),
				afterClose: function() {

					dialog.destroy();
				}
			});

			dialog.open();
		},
		onDialogClosed: function(oEvent) {
			jQuery.sap.clearDelayedCall(_timeout);

			if (oEvent.getParameter("cancelPressed")) {
				MessageToast.show("Download cancelled");
			} else {
				// MessageToast.show("Invoice Downloaded");
			}
		},

		onPreview: function() {

			var popupMessage = "";
			var beginLine = "<p>";
			var endLine = "</p>";
			var beginInvoiceSuccess = "<strong style='color:Green'>";
			var beginInvoiceError = "<strong style='color:Red'>";
			var endInvoice = "</strong>";
			var lineBody = "";
			var oInput = this.getView().byId("idInput");
			var oRadio = this.getView().byId("radioPrintType");

			tokenList = oInput.getValue();
			var invoiceID = oInput._lastValue;

			var printTypeId = oRadio.getSelectedButton().getId().toString();
			var printType;
			// Checking Print Type case
			if (printTypeId.indexOf("rbOriginal") !== -1) {
				printType = "Original";
			} else if (printTypeId.indexOf("rbRepeat") !== -1) {
				printType = "Rpeat";
			} else if (printTypeId.indexOf("rbSpecial") !== -1) {
				printType = "Special";
			} else if (printTypeId.indexOf("rbDuplicate") !== -1) {
				printType = "Duplicate";
			} else if (printTypeId.indexOf("rbTriplicate") !== -1) {
				printType = "Triplicate";
			} else if (printTypeId.indexOf("rbQuadruplicate") !== -1) {
				printType = "Quadruplicate";
			} else if (printTypeId.indexOf("rbPentaduplicate") !== -1) {
				printType = "Pendtaduplicate";
			}

			var filters = [];
			var that = this;
			var sURI = "/sap/opu/odata/sap/YMSDOD_INVOICE_PRINT4_SRV";
			var context = this;
			var oModel = new sap.ui.model.odata.ODataModel(sURI, true);

			if (tokenList.length > 0) {

				//for (var count = 0; count < tokenList.length; count++) {
				lineBody = "";
				filters = [];
				filters.push(new Filter("Vbeln", sap.ui.model.FilterOperator.EQ, tokenList));
				filters.push(new Filter("Printtype", sap.ui.model.FilterOperator.EQ, printType));

				oModel.read("/InvoPdfSet", {
					filters: filters,
					success: function(oData, response) {
						var oHtml = that.getView().byId("htmlControl");

						if (!oHtml) {
							var sId = that.createId("htmlControl");
							oHtml = new HTML(sId, {
								content: "<canvas id='the-canvas'></canvas>",
								preferDOM: false
							});
							var oLayout = that.getView().byId("staticContentLayout");
							oLayout.addContent(oHtml);
						}

						var pdfData = atob(response.data.results[0].Base64);

						// Loaded via <script> tag, create shortcut to access PDF.js exports.
						var pdfjsLib = window['pdfjs-dist/build/pdf'];

						// The workerSrc property shall be specified.

						pdfjsLib.GlobalWorkerOptions.workerSrc = 'js/worker.js';
						if (sap.ui.Device.system.desktop === true) {
							pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';
						}
						// Using DocumentInitParameters object to load binary data.
						var loadingTask = pdfjsLib.getDocument({
							data: pdfData
						});

						backEndResponse = loadingTask;
						that.rendperImgPdf(backEndResponse, 1, 1.0);
						sap.ui.core.BusyIndicator.hide();
					},
					error: function(oError) { //read error}
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show(JSON.parse(oError.response.body).error.message.value);
					}
				});

				//}

			}

		},

		rendperImgPdf: function(backEndResponse, pageNum, pdfzoom) {
			var that2 = this;
			backEndResponse.promise.then(function(pdf) {
				//console.log('PDF loaded');

				// Fetch the first page
				var pageNumber2 = pageNum;
				pdf.getPage(pageNumber2).then(function(page) {
					//console.log('Page loaded');

					totalPageNumber = pdf.numPages;
					var scale = pdfzoom;
					var viewport = page.getViewport(scale);

					// Prepare canvas using PDF page dimensions
					canvas = document.getElementById('the-canvas');

					while (canvas.hasChildNodes()) {
						canvas.removeChild(canvas.lastChild);
					}

					var context = canvas.getContext("2d");
					canvas.height = viewport.height;
					canvas.width = viewport.width;

					// Render PDF page into canvas context
					var renderContext = {
						canvasContext: context,
						viewport: viewport
					};

					var oModel = that2.getView().getModel();
					if (totalPageNumber > pageNum) {
						oModel.setData({
							onprev: (pageNum > 1 ? true : false),
							onnext: true,
							onzoomin: true,
							onzoomout: true,
							deviceType: sap.ui.Device.system.desktop,
							totalPages: totalPageNumber
						});
						that2.getView().setModel(oModel);
					} else {
						oModel.setData({
							onprev: (pageNum !== 1 ? true : false),
							onnext: false,
							onzoomin: true,
							onzoomout: true,
							deviceType: sap.ui.Device.system.desktop,
							totalPages: totalPageNumber
						});
						that2.getView().setModel(oModel);
					}

					var renderTask = page.render(renderContext);
					renderTask.then(function() {
						//console.log('Page rendered');
					});
				});
			}, function(reason) {
				// PDF loading error
				//console.error(reason);
			});
		},
		onNext: function() {
			//var that2 = this;
			if (pageNumber < totalPageNumber) {
				pageNumber++;
				this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
			}

		},
		onPrev: function() {
			if (pageNumber > 1) {
				pageNumber--;
				this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
			}
		},
		onZoomin: function() {
			zoomIn = zoomIn + 0.5;
			this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
		},
		onZoomout: function() {
			if (zoomIn >= 1) {
				zoomIn = zoomIn - 0.5;
				this.rendperImgPdf(backEndResponse, pageNumber, zoomIn);
			}
		}

	});
});