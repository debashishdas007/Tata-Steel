jQuery.sap.declare("YLIST_REPORT.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("YLIST_REPORT.Component", {
	metadata: {
		"manifest": "json"
	}
});