sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"./InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, InitPageUtil) {
	"use strict";
	var entity = " ";
	return Controller.extend("com.tatasteel.ZTSLFI_CT01.controller.Card", {
		onInit: function () {
			entity = "et_monthlyprojvsactualcollection";
			var viewModel = " ";
			//this.deleteOtherPanels("et_collection_display");
			sap.ui.core.BusyIndicator.show();
			viewModel = new sap.ui.model.json.JSONModel({
						title: "Collection(6 Months in Cr)"
					});
			this.getView().byId("et_threeinone").setModel(viewModel);
			
			this.fetchET_ThreeInOneSet("/ET_MonthlyProjVsActualCollectionSet");
					
		},
		
		fetchET_ThreeInOneSet: function (entitySet) {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read(entitySet, {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						threeInOneModel: oData.results
					});
					that.etThreeInOne(dataModel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		
		etThreeInOne: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					enabled: false,
					values: [{
						name: "2 Series",
						value: ["Projection_Diff", "Variance"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: true
				},
				chartType: {
					name: "Chart Type",
					defaultSelected: 0,
					values: [{
						name: "Column + Line",
						vizType: "combination",
						value: ["Projection_Diff", "Variance"]
					}]
				},
				dimensions: {
					Large: [{
						name: 'Month',
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Projection_Diff",
					value: "{Projection_Diff}"
				}, {
					name: "Variance",
					value: "{Variance}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var cardSubtitle = "";

			if (entity === "et_monthlyprojvsactualcollection")
				cardSubtitle = "Monthly Proj Vs Actuals";
			else if (entity === "et_dailyprojvsactualcollection")
				cardSubtitle = "Daily Proj Vs Actuals";
			else
				cardSubtitle = "Projection and Actual Difference";

			var oVizFrame = this.getView().byId("idVizFrame_threeinone");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					},
					dataShape: {
						primaryAxis: ["bar", "line"]
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: cardSubtitle
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_threeinone");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel4", "chartFixFlex4", "idVizFrame_threeinone", 1);
			
			
			// ========================
			
			// var settingsModel = {
			// 	dataset: {
			// 		name: "Dataset",
			// 		defaultSelected: 0,
			// 		values: [{
			// 			name: "Large",
			// 			value: "/betterLarge.json"
			// 		}]
			// 	},
			// 	series: {
			// 		name: "Series",
			// 		defaultSelected: 0,
			// 		values: [{
			// 			name: "1 Series",
			// 			value: ["Variance"]
			// 		}]
			// 	},
			// 	dataLabel: {
			// 		name: "Value Label",
			// 		defaultState: true
			// 	},
			// 	axisTitle: {
			// 		name: "Axis Title",
			// 		defaultState: true
			// 	},
			// 	dimensions: {
			// 		Large: [{
			// 			name: 'Month',
			// 			value: "{Month}"
			// 		}]
			// 	},
			// 	measures: [{
			// 		name: "Variance",
			// 		value: "{Variance}"
			// 	}]
			// };

			// Format.numericFormatter(ChartFormatter.getInstance());
			// var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample
			// var oModel = new JSONModel(settingsModel);
			// oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			// this.getView().setModel(oModel);

			// var cardSubtitle = "";

			// if (entity === "et_monthlyprojvsactualcollection")
			// 	cardSubtitle = "Monthly Proj Vs Actuals";
			// else if (entity === "et_dailyprojvsactualcollection")
			// 	cardSubtitle = "Daily Proj Vs Actuals";
			// else
			// 	cardSubtitle = "Projection and Actual Difference";

			// var oVizFrame = this.getView().byId("idVizFrame_threeinone_2");
			
			
			// oVizFrame.setVizProperties({
			// 	plotArea: {
			// 		dataLabel: {
			// 			formatString: formatPattern.SHORTFLOAT_MFD2,
			// 			visible: true
			// 		}
			// 	},
			// 	valueAxis: {
			// 		label: {
			// 			formatString: formatPattern.SHORTFLOAT
			// 		},
			// 		title: {
			// 			visible: false
			// 		}
			// 	},
			// 	categoryAxis: {
			// 		title: {
			// 			visible: false
			// 		}
			// 	},
			// 	title: {
			// 		visible: true,
			// 		text: "Payment by Month"
			// 	}
			// });

			// oVizFrame.setModel(dataModel);

			// var oPopOver = this.getView().byId("idPopOver_threeinone_2");
			// oPopOver.connect(oVizFrame.getVizUid());
			// oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			// InitPageUtil.initPageSettings(this.getView(), "settingsPanel5", "chartFixFlex5", "idVizFrame_threeinone_2");
			

		},
		
		
		
		
		
		
		
		
		
	});
});