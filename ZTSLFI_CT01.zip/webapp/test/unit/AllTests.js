sap.ui.define([
	"com/tatasteel/ZTSLFI_CT01/test/unit/controller/Card.controller"
], function () {
	"use strict";
});