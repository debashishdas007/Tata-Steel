sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";
	var oRouter = null;
	return Controller.extend("com.tatasteel.ZTSL_HR_OCM_APPROVE.controller.CircularPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.tatasteel.ZTSL_HR_OCM_APPROVE.view.CircularPage
		 */
		onInit: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("circularPage").attachPatternMatched(this._onObjectMatched, this);
		},

		goBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("TargetApprove", true);
			}
		},

		_onObjectMatched: function (oEvent) {
			var filters = [];
			filters.push(new sap.ui.model.Filter({
				path: "OcmId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").OcmId
			}));
			sap.ui.core.BusyIndicator.show();
			var that = this;
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YHRO_OCM_APP_SRV/");
			oModel.read("/Et_previewCircularSet", {
				filters: filters,
				success: function (oData, response) {
					var value = [];
					value = oData.results;
					var data = [];
					var signature = "";

					if (value.length > 0) {
						var msgArray = [];
						data.msgtrip1 = "AO/HRS/" + value[0].LetterNo + "/" + value[0].LetterYear;
						data.msgtrip2 = value[0].LetterSubject;

						data.bottomName = value[0].EmpName;
						data.bottomDesignation = value[0].Designation;
						signature = value[0].EmpName;
						//data.msgtrip3 = value[0].EmpName+ " || " +value[0].Designation + " || Updated By:"+value[0].UpdatedBy+"  || Updated Date:" + value[0].UpdatedDt;
						data.msgtrip3 = "Updated By:" + value[0].UpdatedBy + "  || Updated Date:" + value[0].UpdatedDt;
						msgArray.push(data);

						// that.getView().byId("BlockLayout").setModel(new sap.ui.model.json.JSONModel(msgArray));
						// that.getView().byId("BlockLayout").bindElement("/0");
						that.getView().setModel(new sap.ui.model.json.JSONModel(msgArray));
						that.getView().bindElement("/0");

					}

					var _grid = that.getView().byId("imageGrid");
					_grid.removeAllContent();

					if (value.length > 1) {
						value.shift();
						if (value.length == 1)
							_grid.setDefaultSpan("L12 M12 S2");
						else if (value.length == 2)
							_grid.setDefaultSpan("L6 M6 S2");
						else if (value.length == 3)
							_grid.setDefaultSpan("L4 M4 S2");
						else
							_grid.setDefaultSpan("L3 M3 S2");
					}

					for (var i = 0; i < value.length; i++) {
						_grid.addContent(
							new sap.m.VBox({
								alignItems: "Center",
								items: [
									new sap.m.Image({
										src: value[i].PhotoUrl
									}).addStyleClass("profileImage"),
									new sap.m.Text({
										text: value[i].Name
									}).addStyleClass("primaryText"),
									new sap.m.Text({
										text: value[i].Desg
									}).addStyleClass("secondaryText"),
									new sap.m.Text({
										text: value[i].Pno
									}),
									new sap.m.Text({
										text: value[i].Level
									})
								]
							}).addStyleClass("profileTile")
						);

					}

					var longText = [];
					data = [];
					data.longText = value[value.length - 1].LetterText;
					data.signature = signature;
					longText.push(data);
					that.getView().byId("BlockLayout").setModel(new sap.ui.model.json.JSONModel(longText));
					that.getView().byId("BlockLayout").bindElement("/0");
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
					// var parser = new DOMParser();
					// var xmlDoc = parser.parseFromString(oError.responseText, "text/xml");
					// sap.m.MessageToast.show(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
				}
			});
		},

	});

});