sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/m/Label",
	"sap/m/Dialog",
	"sap/m/TextArea",
	"sap/m/Button",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageStrip"
], function (jQuery, Controller, Fragment, MessagePopover, MessagePopoverItem, Label, Dialog, TextArea, Button, JSONModel, MessageStrip) {
	"use strict";
	var dialog = "";
	var oRouter = null;
	var buttonType = "";

	return Controller.extend("com.tatasteel.ZTSL_HR_OCM_APPROVE.controller.Approve", {
		onInit: function () {
			this.onPress();
		},
		onPress: function (oControlEvent) {
			//console.log(oControlEvent);
			//console.log(oControlEvent.getSource().getBindingContext("statusJobs").getObject());
			var filters = [];
			var dateFrom = this.getView().byId("dateFrom").getValue().trim();
			var dateTo = this.getView().byId("dateTo").getValue().trim();

			var oFilters = new sap.ui.model.Filter("FromDate", sap.ui.model.FilterOperator.EQ, dateFrom);
			filters.push(oFilters);
			oFilters = new sap.ui.model.Filter("ToDate", sap.ui.model.FilterOperator.EQ, dateTo);
			filters.push(oFilters);

			// if (dateFrom !== "" && dateTo !== "") {
			// 	var oFilters = new sap.ui.model.Filter("FromDate", sap.ui.model.FilterOperator.EQ, dateFrom);
			// 	filters.push(oFilters);
			// 	oFilters = new sap.ui.model.Filter("ToDate", sap.ui.model.FilterOperator.EQ, dateTo);
			// 	filters.push(oFilters);
			// 	this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.None);
			// 	this.getView().byId("dateTo").setValueState(sap.ui.core.ValueState.None);
			// } else {
			// 	if (dateFrom === "") {
			// 		this.getView().byId("dateFrom").setValueState(sap.ui.core.ValueState.Error);
			// 	}
			// 	if (dateTo === "") {
			// 		this.getView().byId("dateTo").setValueState(sap.ui.core.ValueState.Error);
			// 	}
			// 	return false;
			// }

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YHRO_OCM_APP_SRV/");
			var oTable = this.getView().byId("approveTable");
			oTable.setBusy(true);
			var that = this;
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oModel.read("/Et_OcmFinalApprovalSet", {
				filters: filters,
				success: function (oData, response) {
					var value = [];
					value = oData.results;
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel1.setData({
						Et_OcmFinalApprovalSet: value
					});

					//if (value[0].OcmId !== "") {
					//column list item creation
					var oTemplate = new sap.m.ColumnListItem({
						cells: [
							new sap.m.ObjectIdentifier({
								text: "{OcmId}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{OcmDesc}"
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								text: "{FinalAprvrPernr}"
							}).addStyleClass("txtColor"),

							new sap.m.ObjectIdentifier({
								text: "{RequesterName}"
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: {
									path: "EffDate",
									type: "sap.ui.model.type.Date",
									formatOptions: {
										source: {
											pattern: "yyyyMMdd"
										},
										pattern: "dd.MM.yyyy"
									}
								}
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: "{OcmType}"
							}).addStyleClass("txtColor"),
							new sap.m.Text({
								text: ""
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								title: "Open",
								//icon: "sap-icon://circle-task-2",
								titleActive: true,
								titlePress: function (oEvent) {
									that.goOnePageProfile(oEvent, "OnePageProfile");
								}
							}).addStyleClass("txtColor"),
							new sap.m.ObjectIdentifier({
								title: "Preview",
								text: "{OcmId}",
								//icon: "sap-icon://circle-task-2",
								titleActive: true,
								titlePress: function (oEvent) {
									that.onCircularPreview(oEvent, "circularpreview", that);
								}
							}).addStyleClass("circularText"),
							// new sap.m.Text({
							// 	text: "----"
							// }).addStyleClass("txtColor"),
							new sap.m.Text({
								text: "{FromDate}"
							}).addStyleClass("txtColor"),

							new sap.m.Text({
								text: "{ToDate}"
							}).addStyleClass("txtColor"),

							new sap.m.Text({
								text: "{RaisedDate}"
							}).addStyleClass("txtColor")
						]
					});
					oTable.setModel(oModel1);
					oTable.bindAggregation("items", {
						path: "/Et_OcmFinalApprovalSet",
						template: oTemplate
					});

					that.getView().byId("footerToolBar").setVisible(true);
					//}
					oTable.setBusy(false);
				},
				error: function (oError) { //read error}
					oTable.setBusy(false);
					var parser = new DOMParser();
					var xmlDoc = parser.parseFromString(oError.responseText, "text/xml");
					sap.m.MessageToast.show(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
				}
			});

		},
		goOnePageProfile: function (event, OnePageProfile) {
			//oRouter.navTo("onePageProfile");
			var FromDate = (event.getSource().getBindingContext().getProperty("FromDate").split(".")[2] + event.getSource().getBindingContext()
				.getProperty("FromDate").split(".")[1] +
				event.getSource().getBindingContext().getProperty("FromDate").split(".")[0]).toString();
			var Todate = (event.getSource().getBindingContext().getProperty("ToDate").split(".")[2] + event.getSource().getBindingContext().getProperty(
					"ToDate").split(".")[1] +
				event.getSource().getBindingContext().getProperty("ToDate").split(".")[0]).toString();
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("onePageProfile", {
				OcmId: event.getSource().getBindingContext().getProperty("OcmId"),
				FinalAprvrPernr: event.getSource().getBindingContext().getProperty("FinalAprvrPernr"),
				//FromDate: "20190201", //FromDate,
				//ToDate: "20190201", //Todate,
				EffDate: event.getSource().getBindingContext().getProperty("EffDate")
			});
		},
		pOneForm: function () {
			oRouter.navTo("Details");
		},

		onCircularPreview: function (event, circularpreview, that) {
			oRouter.navTo("circularPage", {
				OcmId: event.getSource().getText()
					//FinalAprvrPernr: event.getSource().getBindingContext().getProperty("FinalAprvrPernr")
			});
			//this.openQuickView(event, this.oEmployeeModel);
			// event.getSource().getText();
			// event.getSource().getParent().getCells()[0].getText()
		},

		onSubmitDialog: function (event) {
			var that = this;
			buttonType = event;
			if (dialog != "") {
				dialog.open();
				return false;
			}
			//dialog = new Dialog("remarksDialog", {
			dialog = new Dialog({
				title: "Remarks",
				type: "Message",
				content: [
					new Label({
						text: "Please Submit Your Remarks",
						labelFor: "submitDialogTextarea"
					}),
					new TextArea("submitDialogTextarea", {
						liveChange: function (oEvent) {
							var sText = oEvent.getParameter("value");
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: "100%",
						placeholder: "Add Remarks (required)"
					})
				],
				beginButton: new Button({
					text: "Submit",
					enabled: false,
					type: event.getSource().getType(),
					press: function () {
						if (event.getSource().getType() === "Accept")
							that.onApprove();
						if (event.getSource().getType() === "Reject")
							that.onReturn();

						//dialog.close();
					}
				}),
				endButton: new Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				})
			});
			dialog.open();
		},

		onApprove: function (event) {
			buttonType = "";
			this.getView().byId("oVerticalContent").removeAllContent();
			var oTable = this.getView().byId("approveTable");
			var that = this;
			//dialog.open();
			if (dialog === "" || dialog.getContent().length == 0) {
				sap.m.MessageToast.show("Please Give Remarks");
				dialog.destroy();
				dialog = "";
				return false;
			}
			var remarksTextArea = dialog.getContent()[1].getValue();
			var selectedItems = oTable.getSelectedItems();
			var itemArray = [];
			if (selectedItems.length === 0) {
				sap.m.MessageToast.show("Please select at least One");
				return false;
			}

			var tmp = "";
			var tmpArray = [];
			for (var j = 0; j < selectedItems.length; j++) {
				if (tmp !== selectedItems[j].getCells()[0].getText()) {
					tmpArray.push(selectedItems[j]);
					tmp = selectedItems[j].getCells()[0].getText();
				}
			}
			selectedItems = [];
			selectedItems = tmpArray;

			dialog.destroy();
			dialog = "";

			for (var i = 0; i < selectedItems.length; i++) {
				var data = {
					"FinalAprvrPernr": selectedItems[i].getCells()[2].getText(),
					"FromDate": (selectedItems[i].getCells()[9].getText().split(".")[2] + selectedItems[i].getCells()[9].getText().split(".")[1] +
						selectedItems[i].getCells()[9].getText().split(".")[0]).toString(),
					"ToDate": (selectedItems[i].getCells()[10].getText().split(".")[2] + selectedItems[i].getCells()[10].getText().split(".")[1] +
						selectedItems[i].getCells()[10].getText().split(".")[0]).toString(),
					"ProcessingMode": "",
					"OcmId": selectedItems[i].getCells()[0].getText(),
					"OcmDesc": selectedItems[i].getCells()[1].getText(),
					"RaisedDate": selectedItems[i].getCells()[11].getText(),
					"EffDate": (selectedItems[i].getCells()[4].getText().split(".")[2] + selectedItems[i].getCells()[4].getText().split(".")[1] +
						selectedItems[i].getCells()[4].getText().split(".")[0]).toString(),
					"NumPers": "",
					"OcmType": selectedItems[i].getCells()[5].getText(),
					"AdvDesc": "",
					"RequesterName": selectedItems[i].getCells()[3].getText(),
					"ActionTag": "",
					"Remarks": remarksTextArea,
					"Circular": "",
					"Tag": "A"
				};
				itemArray.push(data);
			}
			oTable.setBusy(true);
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YHRO_OCM_APP_SRV/");
			var aDeferredGroup = oModel.getDeferredGroups().concat("updateCreate");
			oModel.setDeferredGroups(aDeferredGroup);
			oModel.setUseBatch(true);
			var mParameters = {
				groupId: "updateCreate"
			};
			for (var j = 0; j < itemArray.length; j++) {
				var oEntry = itemArray[j];
				oModel.create("/Et_OcmFinalApprovalSet", oEntry, mParameters);
			}
			oModel.submitChanges({
				success: function (oData, response) {
					//To do
					oTable.setBusy(false);
					var arrayResponse = response.data.__batchResponses[0].__changeResponses;
					for (var k = 0; k < arrayResponse.length; k++) {
						if (arrayResponse[k].data.Tag == "E") {
							var oVC = that.byId("oVerticalContent");
							var oMsgStrip = new MessageStrip({
								// text: "Error in OCM ID: " + arrayResponse[k].data.OcmId + " | Reason : "+ arrayResponse[k].data.Text,
								text: "Error: " + arrayResponse[k].data.Text + " for OCM ID:  " + arrayResponse[k].data.OcmId,
								showCloseButton: true,
								showIcon: true,
								type: "Error"
							}).attachClose(function (oEvent) {
								console.log(oEvent);
								oEvent.destroy();
							});
							oVC.addContent(oMsgStrip);
						} else {
							sap.m.MessageToast.show("Approved Successfully");
							// var oVC = that.byId("oVerticalContent");
							// var oMsgStrip = new MessageStrip({
							// 	text: "Approved Successfully of OCM ID: " + arrayResponse[k].data.OcmId,
							// 	showCloseButton: true,
							// 	showIcon: true,
							// 	type: "Success"
							// });
							// oVC.addContent(oMsgStrip);
						}
					}

					that.onPress();
				},
				error: function (e) {
					oTable.setBusy(false);
					//To do
				}
			});

		},

		onReturn: function (event) {
			buttonType = "";
			this.getView().byId("oVerticalContent").removeAllContent();
			var oTable = this.getView().byId("approveTable");
			var that = this;
			//dialog.open();
			if (dialog === "" || dialog.getContent().length == 0) {
				sap.m.MessageToast.show("Please Give Remarks");
				dialog.destroy();
				dialog = "";
				return false;
			}
			var remarksTextArea = dialog.getContent()[1].getValue();
			dialog.destroy();
			dialog = "";

			var selectedItems = oTable.getSelectedItems();
			var itemArray = [];
			if (selectedItems.length === 0) {
				sap.m.MessageToast.show("Please select at least One");
				return false;
			}

			var tmp = "";
			var tmpArray = [];
			for (var j = 0; j < selectedItems.length; j++) {
				if (tmp !== selectedItems[j].getCells()[0].getText()) {
					tmpArray.push(selectedItems[j]);
					tmp = selectedItems[j].getCells()[0].getText();
				}
			}
			selectedItems = [];
			selectedItems = tmpArray;

			for (var i = 0; i < selectedItems.length; i++) {
				var data = {
					"FinalAprvrPernr": selectedItems[i].getCells()[2].getText(),
					"FromDate": (selectedItems[i].getCells()[9].getText().split(".")[2] + selectedItems[i].getCells()[9].getText().split(".")[1] +
						selectedItems[i].getCells()[9].getText().split(".")[0]).toString(),
					"ToDate": (selectedItems[i].getCells()[10].getText().split(".")[2] + selectedItems[i].getCells()[10].getText().split(".")[1] +
						selectedItems[i].getCells()[10].getText().split(".")[0]).toString(),
					"ProcessingMode": "",
					"OcmId": selectedItems[i].getCells()[0].getText(),
					"OcmDesc": selectedItems[i].getCells()[1].getText(),
					"RaisedDate": selectedItems[i].getCells()[11].getText(),
					"EffDate": (selectedItems[i].getCells()[4].getText().split(".")[2] + selectedItems[i].getCells()[4].getText().split(".")[1] +
						selectedItems[i].getCells()[4].getText().split(".")[0]).toString(),
					"NumPers": "",
					"OcmType": selectedItems[i].getCells()[5].getText(),
					"AdvDesc": "",
					"RequesterName": selectedItems[i].getCells()[3].getText(),
					"ActionTag": "",
					"Remarks": remarksTextArea,
					"Circular": "",
					"Tag": "R"
				};
				itemArray.push(data);
			}
			oTable.setBusy(true);
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YHRO_OCM_APP_SRV/");
			var aDeferredGroup = oModel.getDeferredGroups().concat("updateCreate");
			oModel.setDeferredGroups(aDeferredGroup);
			oModel.setUseBatch(true);
			var mParameters = {
				groupId: "updateCreate"
			};
			for (var j = 0; j < itemArray.length; j++) {
				var oEntry = itemArray[j];
				oModel.create("/Et_OcmFinalApprovalSet", oEntry, mParameters);
			}
			oModel.submitChanges({
				success: function (oData, response) {
					//To do
					oTable.setBusy(false);
					var arrayResponse = response.data.__batchResponses[0].__changeResponses;
					for (var k = 0; k < arrayResponse.length; k++) {
						if (arrayResponse[k].data.Tag == "E") {
							var oVC = that.byId("oVerticalContent");
							var oMsgStrip = new MessageStrip({
								// text: "Error in OCM ID: " + arrayResponse[k].data.OcmId + " | Reason : "+ arrayResponse[k].data.Text,
								text: "Error: " + arrayResponse[k].data.Text + " for OCM ID:  " + arrayResponse[k].data.OcmId,
								showCloseButton: true,
								showIcon: true,
								type: "Error"
							}).attachClose(function (oEvent) {
								oEvent.destroy();
							});
							oVC.addContent(oMsgStrip);
						} else {
							sap.m.MessageToast.show("Returned Successfully");
							// var oVC = that.byId("oVerticalContent");
							// var oMsgStrip = new MessageStrip({
							// 	text: "Approved Successfully of OCM ID: " + arrayResponse[k].data.OcmId,
							// 	showCloseButton: true,
							// 	showIcon: true,
							// 	type: "Success"
							// });
							// oVC.addContent(oMsgStrip);
						}
					}

					that.onPress();
				},
				error: function (e) {
					oTable.setBusy(false);
					//To do
				}
			});

		},

		itemSelected: function (event) {
			var table = this.getView().byId("approveTable");
			var tableItems = table.getItems();
			for (var j = 0; j < tableItems.length; j++) {
					if (event.getParameters().listItem.getCells()[0].getText() === table.getItems()[j].getCells()[0].getText()) {
						if(event.getParameters().selected === true ){
							table.setSelectedItem(table.getItems()[j], true );
						}
						if(event.getParameters().selected === false){
							table.setSelectedItem(table.getItems()[j], false );
						}
					} 
			}

		}

	});
});