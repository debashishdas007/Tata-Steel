sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";
	var oRouter = null;

	var employeeDetails = [];
	var careerProgression = [];
	var performanceRating = [];
	var safetyRecords = [];
	var ethicsRecords = [];

	return Controller.extend("com.tatasteel.ZTSL_HR_OCM_APPROVE.controller.OnePageProfile", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.tatasteel.ZTSL_HR_OCM_APPROVE.view.OnePageProfile
		 */
		onInit: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//var data = oRouter.getRoute("onePageProfile").attachPatternMatched(event, this);
			oRouter.getRoute("onePageProfile").attachPatternMatched(this._onObjectMatched, this);
		},

		// onBeforeRendering: function () {
		// 	oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 	//var data = oRouter.getRoute("onePageProfile").attachPatternMatched(event, this);
		// 	oRouter.getRoute("onePageProfile").attachPatternMatched(this._onObjectMatched, this);
		// },

		// onAfterRendering: function () {
		// 	oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 	oRouter.getRoute("onePageProfile").attachPatternMatched(this._onObjectMatched, this);
		// },

		_onObjectMatched: function (oEvent) {
			var filters = [];
			filters.push(new sap.ui.model.Filter({
				path: "OcmId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").OcmId
			}));
			filters.push(new sap.ui.model.Filter({
				path: "RequesterId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").FinalAprvrPernr
			}));
			filters.push(new sap.ui.model.Filter({
				path: "FromDate",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").FromDate
			}));
			filters.push(new sap.ui.model.Filter({
				path: "ToDate",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").ToDate
			}));
			filters.push(new sap.ui.model.Filter({
				path: "EffDate",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").EffDate
			}));
			sap.ui.core.BusyIndicator.show();
			var that = this;
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YHRO_OCM_APP_SRV/");
			oModel.read("/Et_EmployeeDetailsSet", {
				filters: filters,
				success: function (oData, response) {
					var value = [];
					value = oData.results;
					employeeDetails =  [];
					careerProgression = [];
					performanceRating = [];
					safetyRecords = [];
					ethicsRecords = [];
					
					//var empTableTd = jQuery(".sapUiFormElementLbl");
					// console.log(oRect);
					//empTableTd.attr("colspan", 2);
					

					for (var i = 0; i < value.length; i++) {
						switch (value[i].Tag) {
						case "D": // Employee Deatials
							var data1 = [];
							data1.LeveltextOld = value[i].LeveltextOld; // Current Level
							data1.LeveltextNew = value[i].LeveltextNew; // Position Moving TO
							data1.PostextOld = value[i].PostextOld; // From Designation
							data1.PostextNew = value[i].PostextNew; // To Designation
							data1.DeptNew = value[i].DeptNew; // From Department
							data1.DeptOld = value[i].DeptOld; // To Department 
							data1.ExecheadOld = value[i].ExecheadOld; // From Executive Head
							data1.ExecheadNew = value[i].ExecheadNew; // To Executive Head
							data1.Cadre = value[i].Cadre; // Cadre
							data1.PeriodPosition = value[i].PeriodPosition; //No. of years in current position
							data1.PeriodLevel = value[i].PeriodLevel; // No. of years in current level
							data1.Age = value[i].Age; // Age
							data1.totalExperience = " "; // Total Experience
							employeeDetails.push(data1);

							break;
						case "C": // Career Progression Table
							var data2 = [];
							data2.EffDate = value[i].EffDate; // Effective Date
							data2.ActionType = value[i].ActionType; // Action Type
							data2.ActionReason = value[i].ActionReason; // Action Reason
							data2.EmpLevel = value[i].EmpLevel; // Level
							data2.Designation = value[i].Designation; // Designation
							data2.Department = value[i].Department; // Department
							data2.Company = value[i].Company; // Company
							careerProgression.push(data2);

							break;

						case "A": // Performance Rating Table
							var data3 = [];
							data3.AppraisalYear = value[i].AppraisalYear; // Appraisal Year
							data3.Rating = value[i].Rating; // Performance Rating
							data3.Remark = value[i].Remark; // Remarks
							performanceRating.push(data3);
							break;

						case "S": // Safety Records Table   
							var data4 = [];
							data4.EffDate = value[i].EffDate; // Date
							data4.ViolationNo = value[i].ViolationNo; // Violation No.
							data4.ViolationType = value[i].ViolationType; // Violation Type
							data4.ViolationReason = value[i].ViolationReason; // Violation Reason
							data4.SafetyComment = value[i].SafetyComment; // Comments
							safetyRecords.push(data4);

							break;

						case "E": // Ethics Records Table
							var data5 = [];
							data5.EthicsType = value[i].EthicsType; // Type
							data5.SettledDate = value[i].SettledDate; // Date Settled
							ethicsRecords.push(data5);
							break;

						default:

							break;
						}

					}

					if (employeeDetails.length !== 0) {
						var employee = that.getView().byId("employeeDetails");
						employee.getModel().refresh(true);
						var oModel1 = new sap.ui.model.json.JSONModel(employeeDetails);
						employee.setModel(oModel1);
						employee.bindElement("/0");

					}

					if (careerProgression.length !== 0) {
						var careerTable = that.getView().byId("careerTable");
						careerTable.getModel().refresh(true);
						//careerTable.removeAllColumns();
						var oModel2 = new sap.ui.model.json.JSONModel();
						oModel2.setData({
							CareerSet: careerProgression
						});
						var oTemplate = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									text: {
										path: "EffDate",
										type: "sap.ui.model.type.Date",
										formatOptions: {
											source: {
												pattern: "yyyyMMdd"
											},
											pattern: "dd.MM.yyyy"
										}
									}
								}), new sap.m.Text({
									text: "{ActionType}"
								}), new sap.m.Text({
									text: "{ActionReason}"
								}), new sap.m.Text({
									text: "{EmpLevel}"
								}),
								new sap.m.ObjectIdentifier({
									text: "{Designation}"
								}), new sap.m.ObjectIdentifier({
									text: "{Department}"
								}),
								new sap.m.ObjectIdentifier({
									text: "{Company}"
								}),
							]
						});
						careerTable.setModel(oModel2);

						careerTable.bindAggregation("items", {
							path: "/CareerSet",
							template: oTemplate
						});
					}

					if (performanceRating.length !== 0) {
						var performanceTable = that.getView().byId("performanceTable");
						performanceTable.getModel().refresh(true);
						//performanceTable.removeAllColumns();
						var oModel3 = new sap.ui.model.json.JSONModel();
						oModel3.setData({
							PerformanceSet: performanceRating
						});

						var oTemplate2 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									text: "{AppraisalYear}"
								}), new sap.m.Text({
									text: "{Rating}"
								}), new sap.m.Text({
									text: "{Remark}"
								})
							]
						});
						performanceTable.setModel(oModel3);
						performanceTable.bindAggregation("items", {
							path: "/PerformanceSet",
							template: oTemplate2
						});
					}

					if (safetyRecords.length !== 0) {
						var safetyTable = that.getView().byId("safetyTable");
						safetyTable.getModel().refresh(true);
						//safetyTable.removeAllColumns();
						var oModel4 = new sap.ui.model.json.JSONModel();
						oModel4.setData({
							SafetySet: safetyRecords
						});

						var oTemplate3 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									text: "{EffDate}"
								}), new sap.m.Text({
									text: "{ViolationNo}"
								}),
								new sap.m.Text({
									text: "{ViolationType}"
								}), new sap.m.Text({
									text: "{ViolationReason}"
								}), new sap.m.Text({
									text: "{SafetyComment}"
								})
							]
						});
						safetyTable.setModel(oModel4);
						safetyTable.bindAggregation("items", {
							path: "/SafetySet",
							template: oTemplate3
						});
					}

					if (ethicsRecords.length !== 0) {
						var ethicsTable = that.getView().byId("ethicsTable");
						ethicsTable.getModel().refresh(true);
						ethicsTable.removeAllItems();
						var oModel5 = new sap.ui.model.json.JSONModel();
						oModel5.setData({
							EthicsSet: ethicsRecords
						});

						var oTemplate4 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									text: "{EthicsType}"
								}), new sap.m.Text({
									text: "{SettledDate}"
								})
							]
						});
						ethicsTable.setModel(oModel5);
						ethicsTable.bindAggregation("items", {
							path: "/EthicsSet",
							template: oTemplate4
						});
					}
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
					// var parser = new DOMParser();
					// var xmlDoc = parser.parseFromString(oError.responseText, "text/xml");
					// sap.m.MessageToast.show(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);
				}
			});
		},

		goBack: function () {

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("TargetApprove", true);
			}
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.tatasteel.ZTSL_HR_OCM_APPROVE.view.OnePageProfile
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.tatasteel.ZTSL_HR_OCM_APPROVE.view.OnePageProfile
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.tatasteel.ZTSL_HR_OCM_APPROVE.view.OnePageProfile
		 */
		//	onExit: function() {
		//
		//	}

	});

});