sap.ui.define([
	"com/tatasteel/ZTSL_HR_OCM_APPROVE/test/unit/controller/Approve.controller"
], function () {
	"use strict";
});