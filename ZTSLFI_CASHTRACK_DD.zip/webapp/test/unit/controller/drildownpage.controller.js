/*global QUnit*/

sap.ui.define([
	"com/tatasteel/ZTSLFI_CASHTRACK_DD/controller/drildownpage.controller"
], function (oController) {
	"use strict";

	QUnit.module("drildownpage Controller");

	QUnit.test("I should test the drildownpage controller", function (assert) {
		var oAppController = new oController();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});