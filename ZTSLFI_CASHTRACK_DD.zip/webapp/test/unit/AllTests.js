sap.ui.define([
	"com/tatasteel/ZTSLFI_CASHTRACK_DD/test/unit/controller/drildownpage.controller"
], function () {
	"use strict";
});