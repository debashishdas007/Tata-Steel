sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("RECEIVER_SIGNATURE.RECEIVER_SIGNATURE.controller.Home", {
		onInit: function () {

		}
	});
});