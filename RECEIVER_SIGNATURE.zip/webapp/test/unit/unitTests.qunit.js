/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"RECEIVER_SIGNATURE/RECEIVER_SIGNATURE/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});