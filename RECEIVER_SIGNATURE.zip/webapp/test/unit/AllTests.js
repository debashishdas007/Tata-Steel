sap.ui.define([
	"RECEIVER_SIGNATURE/RECEIVER_SIGNATURE/test/unit/controller/Home.controller"
], function () {
	"use strict";
});