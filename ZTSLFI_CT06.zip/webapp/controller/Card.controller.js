sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"./InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, Export, ExportTypeCSV, InitPageUtil) {
	"use strict";
	var entity = " ";
	var globalData = " ";
	return Controller.extend("com.tatasteel.ZTSLFI_CT06.controller.Card", {
		onInit: function () {
			entity = "et_totalactualcollection";
			var viewModel = " ";

			sap.ui.core.BusyIndicator.show();
			this.fetchET_TotalActualCollection();
		},

		fetchET_TotalActualCollection: function () {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read("/ET_TotalActualCollectionSet", {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						totalActualCollectionModel: oData.results
					});
					globalData = dataModel;
					that.et_totalActualCollection(dataModel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		et_totalActualCollection: function (dataModel) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					values: [{
						name: "1 Series",
						value: ["Monthly_Collection"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: false
				},
				dimensions: {
					Large: [{
						name: "Month",
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Monthly Collection",
					value: "{Monthly_Collection}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var oVizFrame = this.getView().byId("idVizFrame_totalActualCollection");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.STANDARDINTEGER,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Monthly Collection by month"
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_totalActualCollection");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			//InitPageUtil.initPageSettings(this.getView());
			InitPageUtil.initPageSettings(this.getView(), "settingsPanel5", "chartFixFlex5", "idVizFrame_totalActualCollection", " ",this);
		},
		
		excelDownload: function () {
			//alert('shifhsdf');
			//console.log(globalData);

			var aCols;
			aCols = this.createColumnConfig();
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				models: globalData,
				rows: {
					path: "/totalActualCollectionModel"
				},
				// column definitions with column name and binding info for the content
				columns: aCols

			});
			oExport.saveFile("card06").catch(function (oError) {
				//Handle your error
				//console.log(oError);
			}).then(function () {
				oExport.destroy();
			});

		},
		createColumnConfig: function () {
			return [{
				name: "Month",
				template: {
					content: {
						path: "Month"
					}
				}
			}, {
				name: "Monthly Collection",
				template: {
					content: {
						path: "Monthly_Collection"
					}
				}
			}];
		}

	});
});