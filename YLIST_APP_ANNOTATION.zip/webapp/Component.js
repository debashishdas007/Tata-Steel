jQuery.sap.declare("LSTAylist_app_annotation.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("LSTAylist_app_annotation.Component", {
	metadata: {
		"manifest": "json"
	}
});