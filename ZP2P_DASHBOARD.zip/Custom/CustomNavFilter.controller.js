(function() {
	"use strict";

	sap.ui.controller("YMFACV_P2P_DASHBOARD_SRV.Custom.CustomNavFilter", {

		onCustomParams: function(sCustomParams) {
			if (sCustomParams === "getParameters") {
				return this.getParameters;
			} else if (sCustomParams === "flag") {
				return this.param2;
			}
		},
		getParameters: function(oNavigateParams) {
			var aCustomSelectionVariant = [];
			var oCustomSelectionVariant = {
				path: "TaxTarifCode",
				operator: "EQ",
				value1: 5,
				value2: null,
				sign: "I"
			};
			aCustomSelectionVariant.push(oCustomSelectionVariant);
			return aCustomSelectionVariant;
		},

		param2: function(oNavigateParams) {
			oNavigateParams.Flag = 'True';
			return oNavigateParams;
		}

	});
})();