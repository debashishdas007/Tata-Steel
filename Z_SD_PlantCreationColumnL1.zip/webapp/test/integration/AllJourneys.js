/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"com/sap/Z_SD_PlantCreationColumnL1/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/sap/Z_SD_PlantCreationColumnL1/test/integration/pages/PlantCreationColumnL1",
	"com/sap/Z_SD_PlantCreationColumnL1/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.sap.Z_SD_PlantCreationColumnL1.view.",
		autoWait: true
	});
});