sap.ui.define([
	"com/sap/Z_SD_PlantCreationColumnL1/test/unit/controller/PlantCreationColumnL1.controller"
], function () {
	"use strict";
});