sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

  var ImgContent1,ImgContent2,ImgContent3,ImgContent4,ImgContent5,ImgContent6;
  
  var Img1,Img2,Img3,Img4,Img5,Img6;
  
	return Controller.extend("com.sap.Z_SD_PlantCreationColumnL1.controller.PlantCreationColumnL1", {
		onInit: function () {

		},

		onSavepress: function () {

			var PlantType;
			
			var PlantKey = this.getView().byId("PlantType").getSelectedKey();

			if (PlantKey === "Others")

			{
				PlantType = this.getView().byId("otherPlant").getValue();
	    	}else{
		    	PlantType = this.getView().byId("PlantType").getValue();
			
	    	}
			
			
			var ReferencePlant = this.getView().byId("ReferencePlant").getValue();
			var BusinessArea = this.getView().byId("BusinessArea").getValue();
			var BusinessPlace = this.getView().byId("BusinessPlace").getValue();
			var ProfitCenter = this.getView().byId("ProfitCenter").getValue();
			var PlantName = this.getView().byId("PlantName").getValue();
			var Address = this.getView().byId("Address").getValue();
			var PlantRegion = this.getView().byId("PlantRegion").getValue();
			var StateCode = this.getView().byId("StateCode").getValue();
			// var SaleTaxDetail = this.getView().byId("SaleTaxDetail").getValue();
			// var VatDetail = this.getView().byId("VatDetail").getValue();
			var exportval = this.getView().byId("export").getSelectedKey();
			var vendorCode = this.getView().byId("vendorCode").getValue();
			var LRSetting = this.getView().byId("LRSetting").getSelectedKey();
			var LRVal = this.getView().byId("LRVal").getValue();
			// var RG23D = this.getView().byId("RG23D").getSelectedKey();
			// var J1IIN = this.getView().byId("J1IIN").getSelectedKey();
			var CostCentersList = this.getView().byId("CostCentersList").getValue();
			var SalesArea = this.getView().byId("SalesArea").getValue();
			var CityName = this.getView().byId("CityName").getValue();
			var CostedMatVal = this.getView().byId("CostedMatVal").getValue();
			var CostedPlantTag = this.getView().byId("CostedPlantTag").getSelectedKey();
			var SalesOfficeCtrl = this.getView().byId("SalesOfficeCtrl").getValue();
			var ZDRTag = this.getView().byId("ZDRTag").getSelectedKey();
			var GSTNo = this.getView().byId("GSTNo").getValue();
			var PANNo = this.getView().byId("PanOfContactPerson").getValue();
			// var ExcRange = this.getView().byId("ExcRange").getValue();
			// var ExcDiv = this.getView().byId("ExcDiv").getValue();
			// var CSTNo = this.getView().byId("CSTNo").getValue();
			// var LstVatTinNo = this.getView().byId("LstVatTinNo").getValue();
			var RequesterId = this.getView().byId("RequesterId").getValue();
			var MSId = this.getView().byId("MSId").getValue();
			var formNo = this.getView().byId("form_no").getValue();
			
			
			
			var PersonName = this.getView().byId("PersonName").getValue();
			var EmailOfPerson = this.getView().byId("EmailOfPerson").getValue();
			var BriefDescription = this.getView().byId("BriefDescription").getValue();
			var Natureofpremises = this.getView().byId("Natureofpremises").getValue();
			if (Natureofpremises === "Owned") {
					 	
					 	this.getView().byId("ContactNoOfPerson").setValue("");
					 	this.getView().byId("PersonName").setValue("");
					 	this.getView().byId("EmailOfPerson").setValue("");
					 	this.getView().byId("PanOfContactPerson").setValue("");
					 	
			}
			
			var ContactNoOfPerson = this.getView().byId("ContactNoOfPerson").getValue();
			var Remarks = this.getView().byId("Remarks").getValue();
			var GLCustomercode = this.getView().byId("GLCustomercode").getValue();
			var GLVendorcode = this.getView().byId("GLVendorcode").getValue();
			
			
			
			// var tag;
			

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YV01O_SD_PLANT_CREATE_SRV/");
			var aDeferredGroup = oModel.getDeferredGroups().concat("batchUpdate");
			oModel.setDeferredGroups(aDeferredGroup);
			// var ModelLength = omodelUpdate.oData.ET_BIS_DETAILSet.length;
			oModel.setUseBatch(true);
			var mParameters = {
				groupId: "batchUpdate"
			};

			var NewData = {};

			NewData = {
				// "BillDate": oSelectedItem[i].getBindingContext().getProperty("BillDate"),

				"PlantType": PlantType,
				"PlantRef": ReferencePlant,
				"BusinessArea": BusinessArea,
				"BusinessPlace": BusinessPlace,
				"ProfitCentre": ProfitCenter,
				"PlantName": PlantName,
				"Address": Address,
				"PlantRegion": PlantRegion,
				"StateCode": StateCode,
				"ExportTag": exportval,
				"VendorCode": vendorCode,
				"LrTag": LRSetting,
				"LrVal": LRVal,
				"CostCntrMap": CostCentersList,
				"SalesArea": SalesArea,
				"CityName": CityName,
				"MatCosted": CostedMatVal,
				"PlantCostTag": CostedPlantTag,
				"CtrlSalesOffic": SalesOfficeCtrl,
				"ZdrTag": ZDRTag,
				"GstNo": GSTNo,
				"PanNo": PANNo,
				"MsgId": RequesterId,
				"MsId": MSId,
				"FormNo":formNo,
				"PersonName":PersonName,
				"Email":EmailOfPerson,
				"BrifDesc":BriefDescription,
				"NaturePremises":Natureofpremises,
				"ContactNo":ContactNoOfPerson,
				"Remarks":Remarks,
				"GlCustomerCode":GLCustomercode,
				"GlVendorCode":GLVendorcode,
				"AgreementImg":Img1,
				"PersonIdImg":Img2,
				"AddPersonImg":Img3,
				"CompanyIdImg":Img4,
				"AddBusinessImg":Img5,
				"GstImg":Img6
					// "IdId":
					// "Status":
					// "ItsId":
					// Comment1
					// Comment2
					// "Tag":tag

			};
			
			

			// oModel.create("/ET_L1_PlantCreationFormSet", NewData, mParameters);
			
			var that = this;

			// oModel.submitChanges({
			// 	success: function (response) {
					
			// 		that.getView().byId("FormLevelId").setVisible(true);
			// 	 	that.getView().byId("form_no").setVisible(true);
					
			// 		 var FormNo =	response.FormNo.toString();
			// 	 	// this.getView().byId("QueryNo").setValue(QueryNo);
			// 	 	that.getView().byId("form_no").setValue(FormNo);
				 	
			// 		sap.m.MessageToast.show("Form has been grnerated successfully!");

			// 	},
			// 	error: function (oError) { //read error}

			// 		sap.m.MessageToast.show("Error in cancellation of E-Doc");
			// 	}
			// });
			
			
			
			oModel.create("/ET_L1_PlantCreationFormSet", NewData, {
				success: function (response) {
				//	console.log("success");
				
				 //var status =	response.Status.toString();
				
				 	
				 
				 	// sap.m.MessageToast.show("Quary has already been requested for action!");
			
				 	that.getView().byId("FormLevelId").setVisible(true);
				 	that.getView().byId("form_no").setVisible(true);
				 	
				 	var FormNo =	response.FormNo.toString();
				 	var Tag =	response.Tag.toString();
				 	// this.getView().byId("QueryNo").setValue(QueryNo);
				 	that.getView().byId("form_no").setValue(FormNo);
				 	
				 	if(Tag == "G"){
				
			        	sap.m.MessageToast.show("Form generated successfully!");
		        	}else{
			         	sap.m.MessageToast.show("Form Updated successfully!");
		          	}
				 	
			
				//	var responseMsg = JSON.parse(response.ReturnMsg.replace(",]", "]"));
				
				},
				error: function (response) {
			     	sap.m.MessageToast.show("Error in Form generation!");
			     //	this.showAlertMessage("Error in cancellation of request");
				}
			});
			
			

		},

		OnSelectionLRSetting: function () {

			var LRSetting = this.getView().byId("LRSetting").getSelectedKey();

			if (LRSetting === "Y")

			{
				this.getView().byId("LRVal").setVisible(true);
			} else {
				this.getView().byId("LRVal").setVisible(false);
			}

		},
		
		OnSelectionPlantType: function (){

			var PlantType = this.getView().byId("PlantType").getSelectedKey();

			if (PlantType === "Others")

			{
				this.getView().byId("otherPlant").setVisible(true);
			} else {
				this.getView().byId("otherPlant").setVisible(false);
			}
		},
		
		OnselectNaturePremises: function (){
			var Natureofpremises = this.getView().byId("Natureofpremises").getSelectedKey();
			
			if (Natureofpremises === "Leased" || Natureofpremises === "Rented") {
				
			this.getView().byId("PersonNameL").setVisible(true);
			this.getView().byId("PersonName").setVisible(true);
			this.getView().byId("mailOfPersonL").setVisible(true);
			this.getView().byId("EmailOfPerson").setVisible(true);	
			this.getView().byId("ContactNoOfPersonL").setVisible(true);
			this.getView().byId("ContactNoOfPerson").setVisible(true);
			this.getView().byId("PanOfContactPersonL").setVisible(true);
			this.getView().byId("PanOfContactPerson").setVisible(true);
			this.getView().byId("mailOfPersonL").setVisible(true);
			this.getView().byId("EmailOfPerson").setVisible(true);
			
			
		}else{
			
			this.getView().byId("PersonNameL").setVisible(false);
			this.getView().byId("PersonName").setVisible(false);
			this.getView().byId("mailOfPersonL").setVisible(false);
			this.getView().byId("EmailOfPerson").setVisible(false);
			this.getView().byId("ContactNoOfPersonL").setVisible(false);
			this.getView().byId("ContactNoOfPerson").setVisible(false);
			this.getView().byId("PanOfContactPersonL").setVisible(false);
			this.getView().byId("PanOfContactPerson").setVisible(false);
			this.getView().byId("mailOfPersonL").setVisible(false);
			this.getView().byId("EmailOfPerson").setVisible(false);
			
			
		}
		
		},
		
		
		
		onDisplay: function () {
       
       var formNo = this.getView().byId("form_no").getValue();
       
       
        var filters = new Array();
       
       if(formNo !== ""){
			var oFilterFormNo = new sap.ui.model.Filter("FormNo", sap.ui.model.FilterOperator.EQ,formNo);
				filters.push(oFilterFormNo);
			}
       
       
       
       
      
      //var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YV01O_SD_PLANT_CREATE_SRV/");
      //var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YV01O_SD_PLANT_CREATE_SRV/");
      
      //var NewData = {};
      
      //	NewData = {
      //		"FormNo":formNo
      		
      		
      //	}
			
			// oModel.read("/ET_L1_PLANTCREAT_GET_ENTITY", {
			// 	filters: filters,
			// 	success: function(oData, response) {
					
			// 			var value = [];
			// 		value = oData.results;
			// 		var oModelQueryDetailL2 = new sap.ui.model.json.JSONModel();
			// 		oModelQueryDetailL2.setData({
			// 			ET_L3_QuaryActionSet: value
			// 		});
					
				
					
					
					
					
					
					
					
			// 	}
			// });
			
			
      
       	var that = this;                 
       	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YV01O_SD_PLANT_CREATE_SRV/");
	
			oModel.read('/ET_L1_PlantCreationFormSet', {
				filters: filters,
				success: function(oData, response) {
					
						var value = [];
					value = oData.results;
					var oModelQueryDetailL2 = new sap.ui.model.json.JSONModel();
					oModelQueryDetailL2.setData({
						ET_L1_PlantCreationFormSet: value
					});
					
					
					var Address = value[0].Address.toString();
					that.getView().byId("Address").setValue(Address);
					
					var PlantType = value[0].PlantType.toString();
					that.getView().byId("PlantType").setValue(PlantType);
					
					var PlantRef = value[0].PlantRef.toString();
					that.getView().byId("ReferencePlant").setValue(PlantRef);
					
					var BusinessArea = value[0].BusinessArea.toString();
					that.getView().byId("BusinessArea").setValue(BusinessArea);
					
					var BusinessPlace = value[0].BusinessPlace.toString();
					 that.getView().byId("BusinessPlace").setValue(BusinessPlace);
					 
					var ProfitCentre = value[0].ProfitCentre.toString();
					that.getView().byId("ProfitCenter").setValue(ProfitCentre);
					
					var PlantName = value[0].PlantName.toString();
					that.getView().byId("PlantName").setValue(PlantName);
					
					var PlantRegion = value[0].PlantRegion.toString();
					that.getView().byId("PlantRegion").setValue(PlantRegion);
					
					var StateCode = value[0].StateCode.toString();
					that.getView().byId("StateCode").setValue(StateCode);
					
					var ExportTag = value[0].ExportTag.toString();
					that.getView().byId("export").setSelectedKey(ExportTag);
					
					
					var VendorCode = value[0].VendorCode.toString();
					 that.getView().byId("vendorCode").setValue(VendorCode);
					
					
					var LrTag = value[0].LrTag.toString();
					that.getView().byId("LRSetting").setSelectedKey(LrTag);
					
					var LrVal = value[0].LrVal.toString();
					that.getView().byId("LRVal").setValue(LrVal);
					
					var CostCntrMap = value[0].CostCntrMap.toString();
					 that.getView().byId("CostCentersList").setValue(CostCntrMap);
					 
					var SalesArea = value[0].SalesArea.toString();
					that.getView().byId("SalesArea").setValue(SalesArea);
					
					var CityName = value[0].CityName.toString();
					that.getView().byId("CityName").setValue(CityName);
					
					var MatCosted = value[0].MatCosted.toString();
					that.getView().byId("CostedMatVal").setValue(MatCosted);
					
					var PlantCostTag = value[0].PlantCostTag.toString();
					that.getView().byId("CostedPlantTag").setSelectedKey(PlantCostTag);
					
					var CtrlSalesOffic = value[0].CtrlSalesOffic.toString();
					that.getView().byId("SalesOfficeCtrl").setValue(CtrlSalesOffic);
					
					
					var ZdrTag = value[0].ZdrTag.toString();
					 that.getView().byId("ZDRTag").setSelectedKey(ZdrTag);
					 
					var GstNo = value[0].GstNo.toString();
					 that.getView().byId("GSTNo").setValue(GstNo);
					 
					var PanNo = value[0].PanNo.toString();
					that.getView().byId("PanOfContactPerson").setValue(PanNo);
					
					var MsgId = value[0].MsgId.toString();
					that.getView().byId("RequesterId").setValue(MsgId);
					
					var MsId = value[0].MsId.toString();
					that.getView().byId("MSId").setValue(MsId);
					
					var FormNo = value[0].FormNo.toString();
					that.getView().byId("form_no").setValue(FormNo);
					
					
					var PersonName = value[0].PersonName.toString();
					that.getView().byId("PersonName").setValue(PersonName);
					
					var Email = value[0].Email.toString();
					that.getView().byId("EmailOfPerson").setValue(Email);
					
					var BrifDesc = value[0].BrifDesc.toString();
					that.getView().byId("BriefDescription").setValue(BrifDesc);
					
					var NaturePremises = value[0].NaturePremises.toString();
					 that.getView().byId("Natureofpremises").setSelectedKey(NaturePremises);
					 
					 if (NaturePremises === "Owned") {
					 	
					 	// that.getView().byId("ContactNoOfPerson").setValue("");
					 	// that.getView().byId("PersonName").setValue("");
					 	// that.getView().byId("EmailOfPerson").setValue("");
					 	// that.getView().byId("PanOfContactPerson").setValue("");
					 	 that.OnselectNaturePremises();
					 	
					 	}else{
					 	 that.OnselectNaturePremises();
					 	
					 }
					 
					 
					
					var ContactNo = value[0].ContactNo.toString();
					that.getView().byId("ContactNoOfPerson").setValue(ContactNo);
					
					var Remarks = value[0].Remarks.toString();
					that.getView().byId("Remarks").setValue(Remarks);
					
					var GlCustomerCode = value[0].GlCustomerCode.toString();
					that.getView().byId("GLCustomercode").setValue(GlCustomerCode);
					
					var GlVendorCode = value[0].GlVendorCode.toString();
					that.getView().byId("GLVendorcode").setValue(GlVendorCode);
					
					var myImage1 = value[0].AgreementImg;
					var imagecontent1 = atob(myImage1);
					that.getView().byId("myImage1").setSrc(imagecontent1);
					
					var myImage2 = value[0].PersonIdImg;
					var imagecontent2 = atob(myImage2);
					that.getView().byId("myImage2").setSrc(imagecontent2);
					
					var myImage3 = value[0].AddPersonImg;
					var imagecontent3 = atob(myImage3);
					that.getView().byId("myImage3").setSrc(imagecontent3);
					
					var myImage4 = value[0].CompanyIdImg;
					var imagecontent4 = atob(myImage4);
					that.getView().byId("myImage4").setSrc(imagecontent4);
					
					var myImage5 = value[0].AddBusinessImg;
					var imagecontent5 = atob(myImage5);
					that.getView().byId("myImage5").setSrc(imagecontent5);
					
					var myImage6 = value[0].GstImg;
					var imagecontent6 = atob(myImage6);
					that.getView().byId("myImage6").setSrc(imagecontent6);
					
					that.getView().byId("panel1").setExpanded(true);
					
					
					
			
	     
					
					
					
					
					
					
					
					
					// var oTemplate = new sap.m.ColumnListItem({
					// 	cells: [new sap.m.Text({
					// 		text: "{QueryN}"
					// 	}), 
					// 	// new sap.m.Text({
					// 	// 	text: {
					// 	// 		path: "BillDate",
					// 	// 		type: "sap.ui.model.type.Date",
					// 	// 		formatOptions: {
					// 	// 			pattern: "dd.MM.yyyy"
					// 	// 		}
					// 	// 	}
					// 	// }),
						
					// 	new sap.m.Text({
					// 		text: "{QueryD}"
					// 	}),
					// 	new sap.m.Text({
					// 		text: "{MsgId}"
					// 	}),
					// 	new sap.m.Text({
					// 		text: "{MsId}"
					// 	}), new sap.m.Text({
					// 		text: "{IdId}"
					// 	}), new sap.m.Text({
					// 		text: "{Status}"
					// 	})
						
					// 	]
						
					// });
					
					
					// oTable.setModel(oModelQueryDetailL2);
					// oTable.bindAggregation("items", {
					// 	path: "/ET_L3_QuaryActionSet",
					// 	template: oTemplate
					// });
				}
			});
       
       
		

		},
		
		
		handleValueChange1: function (oEvent) {
			var oFileUploader = this.getView().byId("imageuploader1");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				 ImgContent1 = e.currentTarget.result;
				that.getView().byId("myImage1").setSrc(ImgContent1);
			     Img1 =	btoa(encodeURI(ImgContent1));
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading image 1.");
			};
			reader.readAsDataURL(file);

		},
		handleValueChange2: function (oEvent) {
			var oFileUploader = this.getView().byId("imageuploader2");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				 ImgContent2 = e.currentTarget.result;
				that.getView().byId("myImage2").setSrc(ImgContent2);
				Img2 =	btoa(encodeURI(ImgContent2));
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading image 2.");
			};
			reader.readAsDataURL(file);

		},
		
		handleValueChange3: function (oEvent) {
			var oFileUploader = this.getView().byId("imageuploader3");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				 ImgContent3 = e.currentTarget.result;
				that.getView().byId("myImage3").setSrc(ImgContent3);
				Img3 =	btoa(encodeURI(ImgContent3));
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading image 3.");
			};
			reader.readAsDataURL(file);

		},
		
		handleValueChange4: function (oEvent) {
			var oFileUploader = this.getView().byId("imageuploader4");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				 ImgContent4 = e.currentTarget.result;
				that.getView().byId("myImage4").setSrc(ImgContent4);
				Img4 =	btoa(encodeURI(ImgContent4));
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading image 4.");
			};
			reader.readAsDataURL(file);

		},
		
		handleValueChange5: function (oEvent) {
			var oFileUploader = this.getView().byId("imageuploader5");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				 ImgContent5 = e.currentTarget.result;
				that.getView().byId("myImage5").setSrc(ImgContent5);
				Img5 =	btoa(encodeURI(ImgContent5));
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading image 5.");
			};
			reader.readAsDataURL(file);

		},
		
		handleValueChange6: function (oEvent) {
			var oFileUploader = this.getView().byId("imageuploader6");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;
			var reader = new FileReader();
			reader.onload = function (e) {
				 ImgContent6 = e.currentTarget.result;
				that.getView().byId("myImage6").setSrc(ImgContent6);
				Img6 =	btoa(encodeURI(ImgContent6));
				
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error in uploading image 6.");
			};
			reader.readAsDataURL(file);

		}
		
		
		
		
		
		
		
		
		// onUpload: function(evt) {
		// 	// sap.ui.core.BusyIndicator.show(0);
		// 	var that = this;
		// 	var oFileUploader = this.getView().byId("imageuploader1");
		// 	// var source1 = this.getView().byId("imageuploader1").getSource();
		// 	if (oFileUploader.mProperties.value === '') {
		// 		sap.ui.core.BusyIndicator.hide(0);
		// 		sap.m.MessageToast.show("Please choose a image first");
		// 		return false;
		// 	}
		// 	var domRef = oFileUploader.getFocusDomRef();
		// 	var file = domRef.files[0];
		// 	var that = this;
		// 	this.fileName = file.name;
		// 	this.fileType = file.type;
		// 	var reader = new FileReader();
		// 	reader.onload = function(e) {
		// 		//	debugger;
		// 		var ImgContent = e.currentTarget.result;
		// 		//replace("data:image/jpeg;base64,","");

		// 		that.postImageToBackend(ImgContent);

		// 	};
		// 	reader.readAsDataURL(file);
			
		// 	// that.getView().byId("myImage1").setSrc(source1);

		// }
		
		// onUpload: function(evt) {
		// 	// sap.ui.core.BusyIndicator.show(0);
		// 	var formNo = this.getView().byId("form_no").getValue();
		// 	var oFileUploader = this.getView().byId('imageuploader1');
		// 	var oFileUploader1 = this.getView().byId('imageuploader2'); //
		// 	if (oFileUploader.mProperties.value === '') {
		// 		sap.ui.core.BusyIndicator.hide(0);
		// 		sap.m.MessageToast.show("Please choose a image first");
		// 		return false;
		// 	}
		// 	var domRef = oFileUploader.getFocusDomRef();
	
			
		// 	var file = domRef.files[0];
			
		// 	var that = this;
		// 	this.fileName = file.name;
		// 	this.fileType = file.type;

		// 	var reader = new FileReader();
		// 	reader.onload = function(e) {
		// 		//	debugger;
		// 		var ImgContent = e.currentTarget.result;
		// 		//replace("data:image/jpeg;base64,","");

		// 		// that.postImageToBackend(ImgContent);
				
		// 		var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YV01O_SD_PLANT_CREATE_SRV/");

	
		// 	var imgUploadContent = {
		// 		"FormNo": formNo,
		// 		"AgreementImg": ImgContent
		// 	};
		// 	oModel.create("/ET_L1_PlantCreationFormSet", imgUploadContent, {
		// 		success: function() {
		// 			sap.m.MessageToast.show("image saved successfully");
		// 			// that.onSearch(event);

		// 		},
		// 		error: function(oerr) {
		// 			sap.m.MessageToast.show(oerr);
		// 		}
		// 	});
			
			

		// 	};
		// 	reader.readAsDataURL(file);

		// }
		
		// postImageToBackend: function(Content) {
		// 	var that = this;
		// 	var oDataModel = this.getView().getModel();
		// 	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YV01O_SD_PLANT_CREATE_SRV/");

		// 	// var equipment = this.getView().byId("equip").getSelectedKey();
		// 	// var type = this.getView().byId("type").getSelectedKey();
		// 	// var division = this.getView().byId("division").getSelectedKey();
		// 	// var dept = this.getView().byId("dept").getSelectedKey();
		// 	var formNo = this.getView().byId("form_no").getValue();

			

		// 	var imgUploadContent = {
		// 		"FormNo": formNo,
		// 		"AgreementImg": btoa(encodeURI(Content))
		// 	};
		// 	oModel.create("/ET_L1_PlantCreationFormSet", imgUploadContent, {
		// 		success: function() {
		// 			sap.m.MessageToast.show("image saved successfully");
		// 			// that.onSearch(event);

		// 		},
		// 		error: function(oerr) {
		// 			sap.m.MessageToast.show(oerr);
		// 		}
		// 	});
		// },
		
		
		
		
		
	

	});
});