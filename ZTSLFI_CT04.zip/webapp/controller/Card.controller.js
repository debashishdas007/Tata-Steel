sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"./InitPage"
], function (jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format, Export, ExportTypeCSV,InitPageUtil) {
	"use strict";
	var entity = " ";
	var globalData = " ";
	return Controller.extend("com.tatasteel.ZTSLFI_CT04.controller.Card", {
		onInit: function () {
			entity = "et_paymentsmnthvsactualdiff";
			var viewModel = " ";

			// viewModel = new sap.ui.model.json.JSONModel({
			// 	title: "Payments (6 Months in Cr)",
			// 	subtitle: "Monthly Proj Vs Actuals"
			// });

			this.fetchET_ThreeInOneSet("/ET_PaymentsMnthVsActualDiffSet");
			this.fetchET_ThreeInOneSet2("/ET_PaymentsMnthVsActualDiffSet");

		},

		fetchET_ThreeInOneSet: function (entitySet) {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read(entitySet, {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						threeInOneModel: oData.results
					});
					globalData = dataModel;
					that.etThreeInOne(dataModel, that);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		etThreeInOne: function (dataModel, that) {
			var settingsModel = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					enabled: false,
					values: [{
						name: "1 Series",
						value: ["Projection_Diff"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: true
				},
				dimensions: {
					Large: [{
						name: 'Month',
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Projection_Diff",
					value: "{Projection_Diff}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var cardSubtitle = "";

			if (entity === "et_monthlyprojvsactualcollection")
				cardSubtitle = "Monthly Proj Vs Actuals";
			else if (entity === "et_dailyprojvsactualcollection")
				cardSubtitle = "Daily Proj Vs Actuals";
			else
				cardSubtitle = "Projection and Actual Difference";

			var oVizFrame = this.getView().byId("idVizFrame_threeinone");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.STANDARDINTEGER,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: cardSubtitle
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_threeinone");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel4", "chartFixFlex4", "idVizFrame_threeinone"," ", that);

		},

		fetchET_ThreeInOneSet2: function (entitySet) {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPSO_FI_CASHOPRN_OVP_SRV/");
			var that = this;
			oModel.read(entitySet, {
				success: function (oData, response) {
					var dataModel = new sap.ui.model.json.JSONModel();
					dataModel.setData({
						threeInOneModel: oData.results
					});
					globalData = dataModel;
					that.etThreeInOne2(dataModel, that);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) { //read error}
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		etThreeInOne2: function (dataModel, that) {

			// ========================

			var settingsModel2 = {
				dataset: {
					name: "Dataset",
					defaultSelected: 0,
					values: [{
						name: "Large",
						value: "/betterLarge.json"
					}]
				},
				series: {
					name: "Series",
					defaultSelected: 0,
					enabled: false,
					values: [{
						name: "1 Series",
						value: ["Variance"]
					}]
				},
				dataLabel: {
					name: "Value Label",
					defaultState: true
				},
				axisTitle: {
					name: "Axis Title",
					defaultState: true
				},
				dimensions: {
					Large: [{
						name: 'Month',
						value: "{Month}"
					}]
				},
				measures: [{
					name: "Variance",
					value: "{Variance}"
				}]
			};

			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern; // set explored app's demo model on this sample
			var oModel = new JSONModel(settingsModel2);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel);

			var cardSubtitle = "";

			if (entity === "et_monthlyprojvsactualcollection")
				cardSubtitle = "Monthly Proj Vs Actuals";
			else if (entity === "et_dailyprojvsactualcollection")
				cardSubtitle = "Daily Proj Vs Actuals";
			else
				cardSubtitle = "Projection and Actual Difference";

			var oVizFrame = this.getView().byId("idVizFrame_threeinone2");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.STANDARDINTEGER,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: cardSubtitle
				}
			});

			oVizFrame.setModel(dataModel);

			var oPopOver = this.getView().byId("idPopOver_threeinone2");
			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(formatPattern.STANDARDFLOAT);

			InitPageUtil.initPageSettings(this.getView(), "settingsPanel2", "chartFixFlex2", "idVizFrame_threeinone2", " ", that);

		},
		
		excelDownload: function () {
			// alert('shifhsdf');
			//console.log(globalData);

			var aCols;
			aCols = this.createColumnConfig();
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				models: globalData,
				rows: {
					path: "/threeInOneModel"
				},
				// column definitions with column name and binding info for the content
				columns: aCols

			});
			oExport.saveFile("card04").catch(function (oError) {
				//Handle your error
				//console.log(oError);
			}).then(function () {
				oExport.destroy();
			});

		},
		createColumnConfig: function () {
			return [{
				name: "Month",
				template: {
					content: {
						path: "Month"
					}
				}
			}, {
				name: "Variance",
				template: {
					content: {
						path: "Variance"
					}
				}
			}, {
				name: "Projection Difference",
				template: {
					content: {
						path: "Projection_Diff"
					}
				}
			}];
		}

	});
});