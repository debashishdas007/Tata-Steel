sap.ui.define([
	"com/tatasteel/ZTSLFI_CT04/test/unit/controller/Card.controller"
], function () {
	"use strict";
});