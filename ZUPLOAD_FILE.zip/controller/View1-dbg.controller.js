sap.ui.define([
	"jquery.sap.global",
	"sap/m/MessageToast",
	"sap/ui/core/mvc/Controller"
], function (jQuery, MessageToast, Controller) {
	"use strict";
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YODATA_TESTING_SRV/");
	return Controller.extend("com.tatasteel.UploadFile.controller.View1", {
		onInit: function () {},

		handleUploadComplete: function (oEvent) {
			var parser = "";
			var xmlDoc = "";
			var progressIndicator = this.getView().byId("progressIndicator");
			if (oEvent.getParameter("status") == "201" || oEvent.getParameter("status") == "200") {
				parser = new DOMParser();
				xmlDoc = parser.parseFromString(oEvent.getParameters().headers["sap-message"], "text/xml");
				MessageToast.show(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);

				progressIndicator = this.getView().byId("progressIndicator");
				progressIndicator.setPercentValue(100);
				progressIndicator.setDisplayValue("100%");
			}

			if (oEvent.getParameter("status") == "400" || oEvent.getParameter("status") == "401" || oEvent.getParameter("status") == "500") {
				parser = new DOMParser();
				xmlDoc = parser.parseFromString(oEvent.getParameter("responseRaw"), "text/xml");
				MessageToast.show(xmlDoc.getElementsByTagName("message")[0].childNodes[0].nodeValue);

				progressIndicator.setPercentValue(0);
				progressIndicator.setDisplayValue("0%");
			}

		},

		handleUploadPress: function () {

			oModel.refresh();
			oModel.refreshSecurityToken();

			var oFileUploader = this.byId("fileUploader");
			if (!oFileUploader.getValue()) {
				MessageToast.show("Choose a file first");
				return;
			}

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "slug",
				value: oFileUploader.getValue()
			}));
			// oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
			// 	name: "po",
			// 	value: "12234"
			// }));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: oModel.getSecurityToken()
			}));
			oFileUploader.setSendXHR(true);

			var progressIndicator = this.getView().byId("progressIndicator");
			progressIndicator.setPercentValue(50);
			progressIndicator.setDisplayValue("50%");

			oFileUploader.upload();
			oFileUploader.clear();
			oFileUploader.destroyHeaderParameters();
			oFileUploader.destroyParameters();
			//oFileUploader.destroyXhrSettings();
		},

		// handleValueChange: function (oEvent) {
		// 	MessageToast.show("Press 'Upload File' to upload file '" +
		// 		oEvent.getParameter("newValue") + "'");
		// },

		handleTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},

		handleDownloadPress: function (oEvent) {
			// oModel.read(
			// 		"/Photos(file='test')/$value",
			// 		null, null, false,
			// 		function(odata, response) {
			// 			if (response === null) {

			// 			} else {
			// 				var pdfURL = response.requestUri;
			// 					// var html = context.getView().byId("pdfContainer");
			// 					var html = new sap.ui.core.HTML({});
			// 					html.setContent("<iframe src=" + pdfURL +" width='2000' height='1200' style='display:none;'></iframe>");
			// 					html.placeAt("content");
			// 			}
			// 		},
			// 		function fnError(e) {
			// 			var errorBody = e.response.body;
			// 			var errorMessage = JSON.parse(errorBody).error.message.value;

			// 			// On Error
			// 			context._showStatusDialog(context, "Error", "Message",
			// 				"Error", "Error while processing the order details: " + errorMessage);
			// 		});
			// oModel.read("/Photos(file='test')/$value", {
			//             success: function(oData, response) {
			//                 var file = response.requestUri;
			//                 window.open(file);
			//             },
			//             error: function(response) {}
			//         });
			var sURI = "/sap/opu/odata/sap/YODATA_TESTING_SRV";
			var oModel2 = new sap.ui.model.odata.ODataModel(sURI, true);
			oModel2.read(
				// "/InvoPdfSet(Vbeln='2132002202',Printtype='Rpeat')/$value",
				"/Photos(file='test')/$value",
				null, null, false,
				function (odata, response) {
					if (response === null) {

					} else {
						var pdfURL = response.requestUri;
						window.open(pdfURL);
						// var html = new sap.ui.core.HTML({});
						// html.setContent("<iframe src=" + pdfURL + " width='2000' height='1200' style='display:none;'></iframe>");
						// html.placeAt("page");
					}

				},
				function fnError(e) {
					// com.sap.tatasteel.z_createdo.util.Utils.dialogErrorMessage(e.response);
					var errorBody = e.response.body;
					var errorMessage = JSON.parse(errorBody).error.message.value;

					// On Error
					context._showStatusDialog(context, "Error", "Message",
						"Error", "Error while processing the order details: " + errorMessage);
				});
		}

	});
});