sap.ui.define([
	"demo/objectdemo/test/unit/controller/App.controller"
], function () {
	"use strict";
});