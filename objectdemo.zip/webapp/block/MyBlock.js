sap.ui.define([
  "sap/uxap/BlockBase"
], function(BlockBase) {
  "use strict";

  return BlockBase.extend("demo.objectdemo.MyBlock", {
    metadata: {
      views: { // ObjectPageLayout assumes the following modes to be available: "Collapsed" and "Expanded".
        "Collapsed": {
          viewName: "demo.objectdemo.view.blockone",
          type: "XML",
          async: true
        }
        // ...
      }
    }
  });
});