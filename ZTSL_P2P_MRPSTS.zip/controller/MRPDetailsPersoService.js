sap.ui.define(["jquery.sap.global"],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var MRPDetailsPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "MRPStatisticsApp-oTableMRPDetails-Month",
					order: 0,
					text: "{i18n>Month}",
					visible: true
				}
				// }, {
				// 	id: "MRPStatisticsApp-oTableMRPDetails-Year",
				// 	order: 1,
				// 	text: "{i18n>Year}",
				// 	visible: true
				// }
				, {
					id: "MRPStatisticsApp-oTableMRPDetails-Location",
					order: 2,
					text: "{i18n>Location}",
					visible: true
				}, {
					id: "MRPStatisticsApp-oTableMRPDetails-Plant",
					order: 3,
					text: "{i18n>Plant}",
					visible: true
				}, {
					id: "MRPStatisticsApp-oTableMRPDetails-MatGrp",
					order: 4,
					text: "{i18n>MatGrp}",
					visible: true
				},
				{
					id: "MRPStatisticsApp-oTableMRPDetails-MRPEfficiency",
					order: 5,
					text: "{i18n>MRPEfficiency}",
					visible: true
				},
				{
					id: "MRPStatisticsApp-oTableMRPDetails-ConCoverage",
					order: 6,
					text: "{i18n>ConCoverage}",
					visible: true
				},
				{
					id: "MRPStatisticsApp-oTableMRPDetails-stockOut",
					order: 7,
					text: "{i18n>stockOut}",
					visible: true
				},
				{
					id: "MRPStatisticsApp-oTableMRPDetails-DelvCompliance",
					order: 8,
					text: "{i18n>DelvCompliance}",
					visible: true
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "demoApp-productsTable-productCol",
						order: 0,
						text: "Product",
						visible: true
					}, {
						id: "demoApp-productsTable-supplierCol",
						order: 1,
						text: "Supplier",
						visible: false
					}, {
						id: "demoApp-productsTable-dimensionsCol",
						order: 4,
						text: "Dimensions",
						visible: false
					}, {
						id: "demoApp-productsTable-weightCol",
						order: 2,
						text: "Weight",
						visible: true
					}, {
						id: "demoApp-productsTable-priceCol",
						order: 3,
						text: "Price",
						visible: true
					}]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			}

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			// getCaption : function (oColumn) {
			// 	if (oColumn.getHeader() && oColumn.getHeader().getText) {
			// 		if (oColumn.getHeader().getText() === "Weight") {
			// 			return "Weight (Important!)";
			// 		}
			// 	}
			// 	return null;
			// },

			// getGroup : function(oColumn) {
			// 	if ( oColumn.getId().indexOf('productCol') != -1 ||
			// 			oColumn.getId().indexOf('supplierCol') != -1) {
			// 		return "Primary Group";
			// 	}
			// 	return "Secondary Group";
			// }
		};

		return MRPDetailsPersoService;

	}, /* bExport= */ true);