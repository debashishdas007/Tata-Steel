sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/m/TablePersoController", "./StockOutDetailsPersoService", "sap/m/MessageBox",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV"
], function(Controller, TablePersoController, StockOutDetailsPersoService, MessageBox, Export, ExportTypeCSV) {
	"use strict";

	return Controller.extend("com.sap.tsl.mrpStatisticsMRPStatistics.controller.DelCompDetails", {
		onInit: function() {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("DelCompDetails").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_P2P_MRPSTATISTICS_SRV/");
			var filters = new Array();
			var oParameters = oEvent.getParameters();
			//get the filters passed from StockPODetails page//
			filters = JSON.parse(oParameters.arguments.filterPath);
			sap.ui.core.BusyIndicator.show(0);
			var oTable = this.getView().byId("tblDelCompDetails");
			var that = this;
			var oLblPlantBGGDetails = that.getView().byId("oLblPlantBGGDetails");
			oLblPlantBGGDetails.setText(" for Plant " + filters[0].oValue1.toString() + " Material Group " + filters[1].oValue1.toString());
			oModel.read("/ET_VendorwiseSet", {
				filters: filters,
				success: function(oData, response) {
					oTable.setVisible(true);

					var value = [];
					value = oData.results;
					var oModelDelcompDetails = new sap.ui.model.json.JSONModel();
					oModelDelcompDetails.setData({
						ET_VendorwiseSet: value
					});

					//  Added by debashish on 06.08.2018
					var delcompDetailsData = oModelDelcompDetails.oData.ET_VendorwiseSet;
					var delcompDetailsModel = new sap.ui.model.json.JSONModel(delcompDetailsData);
					sap.ui.getCore().setModel(delcompDetailsModel, "delcompDetailsModel");
					//  End of Addition by debashish on 06.08.2018
					//column list item creation
					var oTemplate = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({
							text: "{Vendor}"

						}), new sap.m.Text({
							text: "{BGG}"
						}), new sap.m.Text({
							text: "{MonthValue}"
						})]
					});
					oTable.setModel(oModelDelcompDetails);
					sap.ui.getCore().setModel(oModelDelcompDetails, "oModelDelcompDetails");
					// 					var ActualPriceJSON = {};
					// 					ActualPriceJSON.Month = oModelDelcompDetails.getProperty("/ET_VendorwiseSet")[1].Month;
					// that. getView().setModel(oModel, "ActualPriceJSON");
					oTable.bindAggregation("items", {
						path: "/ET_VendorwiseSet",
						template: oTemplate
					});
					var FY = "";
					if (parseInt(filters[2].oValue1, 10) > 3) {
						FY = filters[3].oValue1.toString() + " - " + (parseInt(filters[3].oValue1, 10) + 1).toString();
					} else {
						FY = (parseInt(filters[3].oValue1, 10) - 1).toString() + " - " + filters[3].oValue1.toString();
					}
					var oTableHeader = that.getView().byId("oTablHeader");
					oTableHeader.setText("Delivery compliance details for " + oModelDelcompDetails.getProperty("/ET_VendorwiseSet")[1].Month + " " +
						FY);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(oError) { //read error}
					//sap.m.MessageToast.show("Error Fetching data");
					var bCompacterror = !!that.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.information(
						oError.message, {
							styleClass: bCompacterror ? "sapUiSizeCompact" : ""
						}
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		// init and activate controller

		onPersoButtonPressedStockOutDetails: function(oEvent) {
			this._oTPC.openDialog();
		},

		onPressBack: function(evt) {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("MRPStatistics");

		},
		//   ******* Excel Download added by debashish 6.8.2018 ********
		onExport: function() {
			var delcompDetailsModel = sap.ui.getCore().getModel("delcompDetailsModel");
			var acolumns = this.createColumnConfig();
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				models: delcompDetailsModel,
				rows: {
					path: "/"
				},

				// column definitions with column name and binding info for the content
				columns: acolumns

			});
			oExport.saveFile("DelcompDetails").catch(function(oError) {
				//Handle your error
			}).then(function() {
				oExport.destroy();
			});

		},
		createColumnConfig: function() {
				var acolumns = [{
					name: "Vendor",
					template: {
						content: {
							path: "Vendor"
						}
					}
				}, {
					name: "BGG",
					template: {
						content: {
							path: "BGG"
						}
					}
				}, {
					name: "Percentage Delivery Compliance",
					template: {
						content: {
							path: "MonthValue"
						}
					}
				}];

				return acolumns;

			}
			//   ******* End of Excel Download added by debashish 6.8.2018 ********	
	});
});