sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/m/TablePersoController", "./PRDetailsPersoService", "sap/m/MessageBox",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV"
], function(Controller, TablePersoController, PRDetailsPersoService, MessageBox, Export, ExportTypeCSV) {
	"use strict";

	return Controller.extend("com.sap.tsl.mrpStatisticsMRPStatistics.controller.PRDetails", {
		onInit: function() {

			this._oTPC = new TablePersoController({
				table: this.getView().byId("tblPRDetails"),
				//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
				componentName: "MRPStatisticsApp",
				persoService: PRDetailsPersoService
			}).activate();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("PRDetails").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_P2P_MRPSTATISTICS_SRV/");
			var filters = new Array();
			var oParameters = oEvent.getParameters();
			//get the filters passed from StockPODetails page//
			filters = JSON.parse(oParameters.arguments.filterPath);
			sap.ui.core.BusyIndicator.show(0);
			var oTable = this.getView().byId("tblPRDetails");
			var that = this;
			var oLblPlantBGGDetails = that.getView().byId("oLblPlantBGGDetails");
			oLblPlantBGGDetails.setText(" for Plant " + filters[0].oValue1.toString() + " Material Group " + filters[1].oValue1.toString());
			oModel.read("/ET_MRPDetailsSet", {
				filters: filters,
				success: function(oData, response) {
					oTable.setVisible(true);

					var value = [];
					value = oData.results;
					var oModelPRDetails = new sap.ui.model.json.JSONModel();
					oModelPRDetails.setData({
						ET_MRPDetailsSet: value
					});

					//  Added by debashish on 06.08.2018
					var prDetailsData = oModelPRDetails.oData.ET_MRPDetailsSet;
					var prDetailsModel = new sap.ui.model.json.JSONModel(prDetailsData);
					sap.ui.getCore().setModel(prDetailsModel, "prDetailsModel");
					//  End of Addition by debashish on 06.08.2018

					var oLblNoOfRows = that.getView().byId("oLblNoOfRows");
					oLblNoOfRows.setText("Total records: " + value.length);
					//column list item creation
					var oTemplate = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({
							text: "{Month}-{Year}"
								// }), new sap.m.Text({
								// 	text: "{Year}"
						}), new sap.m.Text({
							text: "{MaterialNumber}"
						}), new sap.m.Text({
							text: "{Plant}"
						}), new sap.m.Text({
							text: "{BGG}"
						}), new sap.m.Text({
							text: "{PRNo}"
						}), new sap.m.Text({
							text: "{PoNo}"
						}), new sap.m.Text({
							text: "{MaterialDescription}"
						}).bindProperty("text", {
							parts: [{
									path: "MaterialDescription"

								}

							],
							formatter: function(MaterialDescription) {

								this.addStyleClass("descriptionclass");

								return MaterialDescription;

							}
						}), new sap.m.Text({
							text: "{BGGDescription}"
						}).bindProperty("text", {
							parts: [{
									path: "BGGDescription"

								}

							],
							formatter: function(BGGDescription) {

								this.addStyleClass("descriptionclass");

								return BGGDescription;

							}
						}), new sap.m.Text({
							text: "{PlantDescription}"
						}).bindProperty("text", {
							parts: [{
									path: "PlantDescription"

								}

							],
							formatter: function(PlantDescription) {

								this.addStyleClass("descriptionclass");

								return PlantDescription;

							}
						}), new sap.m.Text({
							text: {
								path: "PRDate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						}), new sap.m.Text({
							text: {
								path: "DODate",
								type: "sap.ui.model.type.Date",
								formatOptions: {
									pattern: "dd.MM.yyyy"
								}
							}
						})]
					});
					oTable.setModel(oModelPRDetails);
					sap.ui.getCore().setModel(oModelPRDetails, "oModelPRDetails");

					oTable.bindAggregation("items", {
						path: "/ET_MRPDetailsSet",
						template: oTemplate
					});
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(oError) { //read error}
					//sap.m.MessageToast.show("Error Fetching data");
					var bCompacterror = !!that.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.information(
						oError.message, {
							styleClass: bCompacterror ? "sapUiSizeCompact" : ""
						}
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		// init and activate controller

		onPersoButtonPressedPRDetails: function(oEvent) {
			this._oTPC.openDialog();
		},

		onPressBack: function(evt) {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("MRPStatistics");

		},
		//   ******* Excel Download added by debashish 6.8.2018 ********
		onExport: function() {
			var aBoundProperties, aCols, oProperties, oRowBinding, oSettings, oTable, oController;

			oController = this;
			var getprDetailsModel = sap.ui.getCore().getModel("prDetailsModel");

			var acolumns = this.createColumnConfig();

			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				models: getprDetailsModel,
				rows: {
					path: "/"
				},

				// column definitions with column name and binding info for the content
				columns: acolumns

			});
			oExport.saveFile("PRDetails").catch(function(oError) {
				//Handle your error
			}).then(function() {
				oExport.destroy();
			});

		},
		createColumnConfig: function() {
				var acolumns = [{
					name: "Month-Year",
					template: {
						content: {
							parts: ["Month", "Year"],
							formatter: function(Month, Year) {
								return Month + " - " + Year;
							}
						}
					}
				}, {
					name: "Material Number",
					template: {
						content: {
							path: "MaterialNumber"
						}
					}
				}, {
					name: "Plant",
					template: {
						content: {
							path: "Plant"
						}
					}
				}, {
					name: "BGG",
					template: {
						content: {
							path: "BGG"
						}
					}
				}, {
					name: "PRNo",
					template: {
						content: {
							path: "PRNo"
						}
					}
				}, {
					name: "PoNo",
					template: {
						content: {
							path: "PoNo"
						}
					}
				}, {
					name: "Material Description",
					template: {
						content: {
							path: "MaterialDescription"
						}
					}
				}, {
					name: "BGG Description",
					template: {
						content: {
							path: "BGGDescription"
						}
					}
				}, {
					name: "Plant Description",
					template: {
						content: {
							path: "PlantDescription"
						}
					}
				}, {
					name: "PR Date",
					template: {
						content: {
							path: "PRDate",
							type: "sap.ui.model.type.Date",
							formatOptions: {
								pattern: "dd.MM.yyyy"
							}
						}
					}
				}, {
					name: "DO Date",
					template: {
						content: {
							path: "DODate",
							type: "sap.ui.model.type.Date",
							formatOptions: {
								pattern: "dd.MM.yyyy"
							}
						}
					}
				}];

				return acolumns;

			}
		//   ******* End of Excel Download added by debashish 6.8.2018 ********
	});
});