sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/m/MessageBox", "sap/m/TablePersoController", "./MRPDetailsPersoService"
], function(Controller, MessageBox, TablePersoController, MRPDetailsPersoService) {
	"use strict";

	return Controller.extend("com.sap.tsl.mrpStatisticsMRPStatistics.controller.MRPStatistics", {

		onInit: function() {
			this._oTPC = new TablePersoController({
				table: this.getView().byId("oTableMRPDetails"),
				//specify the first part of persistence ids e.g. "demoApp-productsTable-dimensionsCol"
				componentName: "MRPStatisticsApp",
				persoService: MRPDetailsPersoService
			}).activate();

		},
		onPersoButtonPressed: function(oEvent) {
			this._oTPC.openDialog();
		},

		//	Value help for Material Group //
		showValueHelpMatGrp: function() {
			var multiInputMatGrp = this.getView().byId("multiInputMatGrp");
			this.getView().byId("multiInputMatGrp").setValueState(sap.ui.core.ValueState.None);

			if (!this._oValueHelpDialogMatGrp) {
				this._oValueHelpDialogMatGrp = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idValueHelpMatGrp", {
					supportRanges: true,
					title: "Material Group",
					key: "MatGrps",
					descriptionKey: "Description",
					ok: function(oEvent) {
						var aTokens = oEvent.getParameter("tokens");

						multiInputMatGrp.setTokens(aTokens);
						var tokens = multiInputMatGrp.getTokens();
						jQuery.each(tokens, function(idx, token) {
							token.setEditable(false);
						});
						this.close();
					},
					cancel: function() {
						this.close();
					}

				});

			}

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "Material Group",
					template: "MatGrps"

				}, {
					label: "Description",
					template: "Description"
				}]
			});
			var oTable = this._oValueHelpDialogMatGrp.getTable();
			oTable.setModel(oColModel, "columns");
			var oModelMatGrp = new sap.ui.model.json.JSONModel();
			var oRowModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_P2P_MRPSTATISTICS_SRV/");
			oRowModel.read("/ET_MaterialGrpSet", {
				//filters: filters,
				success: function(oData, response) {
					//	MessageToast.show(evt.getSource().getId() + " Pressed");
					var value = [];
					value = oData.results;

					oModelMatGrp.setData({
						ET_MaterialGrpSet: value
					});

					oTable.setModel(oModelMatGrp);
					sap.ui.getCore().setModel(oModelMatGrp, "oModelMatGrp");
					oTable.bindRows("/ET_MaterialGrpSet");
				},
				error: function(oError) { //read error}
					sap.m.MessageToast.show("Error Fetching data");
				}
			});

			this._oValueHelpDialogMatGrp.setRangeKeyFields([{
				label: "Material Group",
				key: "MatGrps"
			}]);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				searchEnabled: false,
				showGoOnFB: false

			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					tooltip: "Search for Material Group",
					//	liveChange: this._oValueHelpDialog.getFilterBar().filterTable(),
					//showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function(event) {
						var data = event.mParameters.query;
						var oFilters = new sap.ui.model.Filter({
							and: false,
							filters: [
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("MatGrps", sap.ui.model.FilterOperator.Contains, data)

									]
								}),
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, data)

									]
								})
							]
						});
						var oElement = sap.ui.getCore().byId("idValueHelpMatGrp").getTable();
						oElement.getBinding("rows").filter([oFilters]);

					}
				}));
			}

			this._oValueHelpDialogMatGrp.setModel(oModelMatGrp);
			this._oValueHelpDialogMatGrp.setFilterBar(oFilterBar);
			this._oValueHelpDialogMatGrp.open();

		},

		showValueHelpMatPurGrp: function() {
			var multiInputPurGrp = this.getView().byId("multiInputPurGrp");
			this.getView().byId("multiInputPurGrp").setValueState(sap.ui.core.ValueState.None);

			if (!this._oValueHelpDialogPurGrp) {
				this._oValueHelpDialogPurGrp = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idValueHelpPurGrp", {
					supportRanges: false,
					title: "Purchase Group",
					key: "PurGrp",
					descriptionKey: "Name",
					ok: function(oEvent) {
						var aTokens = oEvent.getParameter("tokens");

						multiInputPurGrp.setTokens(aTokens);
						var tokens = multiInputPurGrp.getTokens();
						jQuery.each(tokens, function(idx, token) {
							token.setEditable(false);
						});
						this.close();
					},
					cancel: function() {
						this.close();
					}

				});

			}

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "Purchase Group",
					template: "PurGrp"

				}, {
					label: "Description",
					template: "Name"
				}]
			});
			var oTable = this._oValueHelpDialogPurGrp.getTable();
			oTable.setModel(oColModel, "columns");
			var oModelPurGrp = new sap.ui.model.json.JSONModel();
			var oRowModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_P2P_MRPSTATISTICS_SRV/");
			oRowModel.read("/ET_PurGrpSet", {
				//filters: filters,
				success: function(oData, response) {
					//	MessageToast.show(evt.getSource().getId() + " Pressed");
					var value = [];
					value = oData.results;

					oModelPurGrp.setData({
						ET_PurGrpSet: value
					});

					oTable.setModel(oModelPurGrp);
					sap.ui.getCore().setModel(oModelPurGrp, "oModelPurGrp");
					oTable.bindRows("/ET_PurGrpSet");
				},
				error: function(oError) { //read error}
					sap.m.MessageToast.show("Error Fetching data");
				}
			});

			this._oValueHelpDialogPurGrp.setRangeKeyFields([{
				label: "Purchase Group",
				key: "PurGrp"
			}]);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				searchEnabled: false,
				showGoOnFB: false

			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					tooltip: "Search for Material Group",
					//	liveChange: this._oValueHelpDialog.getFilterBar().filterTable(),
					//showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function(event) {
						var data = event.mParameters.query;
						var oFilters = new sap.ui.model.Filter({
							and: false,
							filters: [
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("PurGrp", sap.ui.model.FilterOperator.Contains, data)

									]
								}),
								new sap.ui.model.Filter({

									filters: [
										new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, data)

									]
								})
							]
						});
						var oElement = sap.ui.getCore().byId("idValueHelpPurGrp").getTable();
						oElement.getBinding("rows").filter([oFilters]);

					}
				}));
			}

			this._oValueHelpDialogPurGrp.setModel(oModelPurGrp);
			this._oValueHelpDialogPurGrp.setFilterBar(oFilterBar);
			this._oValueHelpDialogPurGrp.open();

		},

		onSearch: function(evt) {
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMPIO_P2P_MRPSTATISTICS_SRV/");
			var multiInputPlant = this.getView().byId("multiInputPlant");
			var inputPeriodMonth = this.getView().byId("inputPeriodMonth");
			var inputPeriodYear = this.getView().byId("inputPeriodYear");
			var multiInputMatGrp = this.getView().byId("multiInputMatGrp");
			var multiInputPurGrp = this.getView().byId("multiInputPurGrp");
			//	var multiInputMatType = this.getView().byId("multiInputMatType");

			if (multiInputPlant.getValue().length === 0 || inputPeriodMonth.getValue().length === 0 || inputPeriodYear.getValue().length === 0 ||
				(multiInputPurGrp.getValue().length === 0 && multiInputMatGrp.getTokens().length === 0)) {
				if (multiInputPlant.getValue().length === 0) {
					this.getView().byId("multiInputPlant").setValueState(sap.ui.core.ValueState.Error);
					return;
				} else {
					this.getView().byId("multiInputPlant").setValueState(sap.ui.core.ValueState.None);
				}
				if (inputPeriodMonth.getValue().length === 0) {
					this.getView().byId("inputPeriodMonth").setValueState(sap.ui.core.ValueState.Error);
					return;
				} else {
					this.getView().byId("inputPeriodMonth").setValueState(sap.ui.core.ValueState.None);
				}
				if (inputPeriodYear.getValue().length === 0) {
					this.getView().byId("inputPeriodYear").setValueState(sap.ui.core.ValueState.Error);
					return;
				} else {
					this.getView().byId("inputPeriodYear").setValueState(sap.ui.core.ValueState.None);
				}
				if (multiInputPurGrp.getValue().length === 0 && multiInputPurGrp.getTokens().length === 0) {
					this.getView().byId("multiInputPurGrp").setValueState(sap.ui.core.ValueState.Error);
					return;
				} else {
					this.getView().byId("multiInputPurGrp").setValueState(sap.ui.core.ValueState.None);
				}

			} else {
				this.getView().byId("multiInputPlant").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("inputPeriodMonth").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("inputPeriodYear").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("multiInputPurGrp").setValueState(sap.ui.core.ValueState.None);
			}

			var PlantValue = multiInputPlant.getValue();
			var monthValue = inputPeriodMonth.getValue();
			var yearValue = inputPeriodYear.getValue();
			var matGrpTokens = multiInputMatGrp.getTokens();
			var matGrpValue = multiInputMatGrp.getValue();
			var purGrpTokens = multiInputPurGrp.getTokens();
			var purGrpValue = multiInputPurGrp.getValue();
			//	var MatTypeTokens = multiInputMatType.getTokens();

			var filters = new Array();

			//**Pass plant in filter **//
			if (PlantValue !== "") {
				var filterPlant = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, PlantValue);
				filters.push(filterPlant);
			}

			//*** Month filter  ***//

			if (monthValue !== "") {
				var filterMonth = new sap.ui.model.Filter("Month", sap.ui.model.FilterOperator.EQ, monthValue);
				filters.push(filterMonth);
			}

			//*** Year filter**//

			if (yearValue !== "") {
				var filterYear = new sap.ui.model.Filter("Year", sap.ui.model.FilterOperator.EQ, yearValue);
				filters.push(filterYear);
			}

			//***  Material Group filter**//
			for (var i = 0; i < matGrpTokens.length; i++) {
				var filterMatGrp = new sap.ui.model.Filter();
				if (matGrpTokens[i].getKey().indexOf("range") === -1) {
					filterMatGrp = new sap.ui.model.Filter("BGG", sap.ui.model.FilterOperator.EQ, matGrpTokens[i].getKey());
				} else {
					if (matGrpTokens[i].data().range.exclude) {
						filterMatGrp = new sap.ui.model.Filter("BGG", sap.ui.model.FilterOperator.NE, matGrpTokens[i].data().range.value1);
					} else {
						filterMatGrp = new sap.ui.model.Filter("BGG", matGrpTokens[i].data().range.operation, matGrpTokens[i].data().range.value1,
							matGrpTokens[i].data().range.value2);
					}

				}
				filters.push(filterMatGrp);
			}

			//**if Material Group is input as plain text **//
			if (matGrpValue !== "") {
				var filterMatgrp = new sap.ui.model.Filter("BGG", sap.ui.model.FilterOperator.EQ, matGrpValue);
				filters.push(filterMatgrp);
			}

			//***  Purchase Group filter**//
			for (var j = 0; j < purGrpTokens.length; j++) {
				var filterPurGrp = new sap.ui.model.Filter("PurchaseGroup", sap.ui.model.FilterOperator.EQ, purGrpTokens[j].getKey());
				filters.push(filterPurGrp);
			}

			//**if Material Group is input as plain text **//
			if (purGrpValue !== "") {
				var filterPurgrp = new sap.ui.model.Filter("PurchaseGroup", sap.ui.model.FilterOperator.EQ, purGrpValue);
				filters.push(filterPurgrp);
			}

			sap.ui.core.BusyIndicator.show(0);
			var oTable = this.getView().byId("oTableMRPDetails");
			var that = this;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
			oModel.read("/ET_MRPStatisticsSet", {
				filters: filters,
				success: function(oData, response) {
					oTable.setVisible(true);

					var value = [];
					value = oData.results;
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel1.setData({
						ET_MRPStatisticsSet: value
					});
				var	oLblNoOfRows = that.getView().byId("oLblNoOfRows");
				oLblNoOfRows.setText("Total records: " + value.length);
					//column list item creation
					var oTemplate = new sap.m.ColumnListItem({
						cells: [new sap.m.Text({
							text: "{Month}-{Year}"
						// }), new sap.m.Text({
						// 	text: "{Year}"
						}), new sap.m.Text({
							text: "{Location}"
						}), new sap.m.Text({
							text: "{Plant}"
						}), new sap.m.Text({
							text: "{BGG}"
						}), new sap.m.ObjectIdentifier({
							title: "{MRPEfficiencyPercentage}",

							//icon: "sap-icon://circle-task-2",
							titleActive: true,

							titlePress: function(oEvent) {

								that.onBackPressed(oEvent, "PRDetails");

							}
						}).bindProperty("title", {
							parts: [{
									path: "MRPEfficiencyPercentage"

								}

							],
							formatter: function(MRPEfficiencyPercentage) {
								if (MRPEfficiencyPercentage >= 0 && MRPEfficiencyPercentage <= 50) {
									// <!-- approach 2 step B : Add Css style class to element -->
									this.addStyleClass("red");

								} else if (MRPEfficiencyPercentage > 50 && MRPEfficiencyPercentage <= 75) {
									this.addStyleClass("yellow");
								} else if (MRPEfficiencyPercentage > 75) {
									this.addStyleClass("green");

								}
								return MRPEfficiencyPercentage;
							}

						}), new sap.m.ObjectIdentifier({
							title: "{ConCoveragePerCentage}",
							//icon: "sap-icon://circle-task-2",
							titleActive: true,
							titlePress: function(oEvent) {

								that.onBackPressed(oEvent, "CoverageDetails");

							}
						}).bindProperty("title", {
							parts: [{
									path: "ConCoveragePerCentage"
								}

							],
							formatter: function(ConCoveragePerCentage) {
								if (ConCoveragePerCentage >= 0 && ConCoveragePerCentage <= 50) {
									// <!-- approach 2 step B : Add Css style class to element -->
									this.addStyleClass("red");

								} else if (ConCoveragePerCentage > 50 && ConCoveragePerCentage <= 75) {
									this.addStyleClass("yellow");

								} else if (ConCoveragePerCentage > 75) {
									this.addStyleClass("green");
								}
								return ConCoveragePerCentage;

							}

						}), new sap.m.ObjectIdentifier({
							title: "{StockOutPercentage}",
							//icon: "sap-icon://circle-task-2",
							titleActive: true,
							titlePress: function(oEvent) {

								that.onBackPressed(oEvent, "StockOutDetails");

							}
						}).bindProperty("title", {
							parts: [{
									path: "StockOutPercentage"
								}

							],
							formatter: function(StockOutPercentage) {
								if (StockOutPercentage >= 0 && StockOutPercentage <= 50) {
									// <!-- approach 2 step B : Add Css style class to element -->
									this.addStyleClass("red");

								} else if (StockOutPercentage > 50 && StockOutPercentage <= 75) {
									this.addStyleClass("yellow");

								} else if (StockOutPercentage > 75) {
									this.addStyleClass("green");
								}
								return StockOutPercentage;

							}

						}), new sap.m.ObjectIdentifier({
							title: "{DeliveryCompliancePercentage}",
							//icon: "sap-icon://circle-task-2",
							titleActive: true,
							titlePress: function(oEvent) {

								that.onBackPressed(oEvent, "DelCompDetails");

							}
						}).bindProperty("title", {
							parts: [{
									path: "DeliveryCompliancePercentage"
								}

							],
							formatter: function(DeliveryCompliancePercentage) {
								if (DeliveryCompliancePercentage >= 0 && DeliveryCompliancePercentage <= 50) {
									// <!-- approach 2 step B : Add Css style class to element -->
									this.addStyleClass("red");

								} else if (DeliveryCompliancePercentage > 50 && DeliveryCompliancePercentage <= 75) {
									this.addStyleClass("yellow");

								} else if (DeliveryCompliancePercentage > 75) {
									this.addStyleClass("green");
								}
								return DeliveryCompliancePercentage;

							}

						})]
					});

					oTable.setModel(oModel1);
					sap.ui.getCore().setModel(oModel1, "oModelMRPDetails");

					oTable.bindAggregation("items", {
						path: "/ET_MRPStatisticsSet",
						template: oTemplate
					});
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(oError) { //read error}
					//sap.m.MessageToast.show("Error Fetching data");
					var bCompacterror = !!that.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.information(
						oError.message, {
							styleClass: bCompacterror ? "sapUiSizeCompact" : ""
						}
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		onBackPressed: function(oEvent, oStrNavDestination) {

			var filterNav = new Array();
			var plant = oEvent.getSource().getBindingContext().getProperty("Plant");
			var BGG = oEvent.getSource().getBindingContext().getProperty("BGG");
			var month = oEvent.getSource().getBindingContext().getProperty("Month");
			var year = oEvent.getSource().getBindingContext().getProperty("Year");
			var multiInputPurGrp = this.getView().byId("multiInputPurGrp");
			var purGrpTokens = multiInputPurGrp.getTokens();
			var purGrpValue = multiInputPurGrp.getValue();
			var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, plant);
			filterNav.push(plantFilter);
			var BGGNavFilter = new sap.ui.model.Filter("BGG", sap.ui.model.FilterOperator.EQ, BGG);
			filterNav.push(BGGNavFilter);
			var monthNavFilter = new sap.ui.model.Filter("Month", sap.ui.model.FilterOperator.EQ, month);
			filterNav.push(monthNavFilter);
			var yearNavFilter = new sap.ui.model.Filter("Year", sap.ui.model.FilterOperator.EQ, year);
			filterNav.push(yearNavFilter);
			if (oStrNavDestination === "DelCompDetails") {
				//***  Purchase Group filter**//
				for (var j = 0; j < purGrpTokens.length; j++) {
					var filterPurGrp = new sap.ui.model.Filter("PurchaseGroup", sap.ui.model.FilterOperator.EQ, purGrpTokens[j].getKey());
					filterNav.push(filterPurGrp);
				}

				//**if Material Group is input as plain text **//
				if (purGrpValue !== "") {
					var filterPurgrp = new sap.ui.model.Filter("PurchaseGroup", sap.ui.model.FilterOperator.EQ, purGrpValue);
					filterNav.push(filterPurgrp);
				}

			}

			//define router
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo(oStrNavDestination, {

				filterPath: JSON.stringify(filterNav)
			});
		}

	});
});